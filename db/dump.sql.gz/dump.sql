--
-- PostgreSQL database dump
--

\restrict eHKRKWtl9FaVB7wSkiMcAhNp6JIsWfboLN3bwGrEXOIxcf7ulVUX4aEVd3HLz9D

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: claim_reason_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."claim_reason_enum" AS ENUM (
    'missing_item',
    'wrong_item',
    'production_failure',
    'other'
);


--
-- Name: order_claim_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."order_claim_type_enum" AS ENUM (
    'refund',
    'replace'
);


--
-- Name: order_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."order_status_enum" AS ENUM (
    'pending',
    'completed',
    'draft',
    'archived',
    'canceled',
    'requires_action'
);


--
-- Name: return_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."return_status_enum" AS ENUM (
    'open',
    'requested',
    'received',
    'partially_received',
    'canceled'
);


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: account_holder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."account_holder" (
    "id" "text" NOT NULL,
    "provider_id" "text" NOT NULL,
    "external_id" "text" NOT NULL,
    "email" "text",
    "data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."api_key" (
    "id" "text" NOT NULL,
    "token" "text" NOT NULL,
    "salt" "text" NOT NULL,
    "redacted" "text" NOT NULL,
    "title" "text" NOT NULL,
    "type" "text" NOT NULL,
    "last_used_at" timestamp with time zone,
    "created_by" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_by" "text",
    "revoked_at" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "api_key_type_check" CHECK (("type" = ANY (ARRAY['publishable'::"text", 'secret'::"text"])))
);


--
-- Name: application_method_buy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."application_method_buy_rules" (
    "application_method_id" "text" NOT NULL,
    "promotion_rule_id" "text" NOT NULL
);


--
-- Name: application_method_target_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."application_method_target_rules" (
    "application_method_id" "text" NOT NULL,
    "promotion_rule_id" "text" NOT NULL
);


--
-- Name: auth_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_identity" (
    "id" "text" NOT NULL,
    "app_metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: banner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."banner" (
    "id" "text" NOT NULL,
    "slot" "text" DEFAULT 'hero'::"text" NOT NULL,
    "title" "text" NOT NULL,
    "link" "text",
    "image_url" "text" NOT NULL,
    "image_url_mobile" "text",
    "position" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: blog_post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."blog_post" (
    "id" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "title" "text" NOT NULL,
    "excerpt" "text",
    "content" "text",
    "thumbnail" "text",
    "author_name" "text",
    "tags" "text"[],
    "is_published" boolean DEFAULT false NOT NULL,
    "published_at" timestamp with time zone,
    "views" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: capture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."capture" (
    "id" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "payment_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "created_by" "text",
    "metadata" "jsonb"
);


--
-- Name: cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart" (
    "id" "text" NOT NULL,
    "region_id" "text",
    "customer_id" "text",
    "sales_channel_id" "text",
    "email" "text",
    "currency_code" "text" NOT NULL,
    "shipping_address_id" "text",
    "billing_address_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "completed_at" timestamp with time zone,
    "locale" "text"
);


--
-- Name: cart_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_address" (
    "id" "text" NOT NULL,
    "customer_id" "text",
    "company" "text",
    "first_name" "text",
    "last_name" "text",
    "address_1" "text",
    "address_2" "text",
    "city" "text",
    "country_code" "text",
    "province" "text",
    "postal_code" "text",
    "phone" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: cart_line_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_line_item" (
    "id" "text" NOT NULL,
    "cart_id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "subtitle" "text",
    "thumbnail" "text",
    "quantity" integer NOT NULL,
    "variant_id" "text",
    "product_id" "text",
    "product_title" "text",
    "product_description" "text",
    "product_subtitle" "text",
    "product_type" "text",
    "product_collection" "text",
    "product_handle" "text",
    "variant_sku" "text",
    "variant_barcode" "text",
    "variant_title" "text",
    "variant_option_values" "jsonb",
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "is_discountable" boolean DEFAULT true NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" "jsonb",
    "unit_price" numeric NOT NULL,
    "raw_unit_price" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "product_type_id" "text",
    "is_custom_price" boolean DEFAULT false NOT NULL,
    "is_giftcard" boolean DEFAULT false NOT NULL,
    CONSTRAINT "cart_line_item_unit_price_check" CHECK (("unit_price" >= (0)::numeric))
);


--
-- Name: cart_line_item_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_line_item_adjustment" (
    "id" "text" NOT NULL,
    "description" "text",
    "promotion_id" "text",
    "code" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "provider_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "item_id" "text",
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    CONSTRAINT "cart_line_item_adjustment_check" CHECK (("amount" >= (0)::numeric))
);


--
-- Name: cart_line_item_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_line_item_tax_line" (
    "id" "text" NOT NULL,
    "description" "text",
    "tax_rate_id" "text",
    "code" "text" NOT NULL,
    "rate" real NOT NULL,
    "provider_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "item_id" "text"
);


--
-- Name: cart_payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_payment_collection" (
    "cart_id" character varying(255) NOT NULL,
    "payment_collection_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: cart_promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_promotion" (
    "cart_id" character varying(255) NOT NULL,
    "promotion_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: cart_shipping_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_shipping_method" (
    "id" "text" NOT NULL,
    "cart_id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "jsonb",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "shipping_option_id" "text",
    "data" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "cart_shipping_method_check" CHECK (("amount" >= (0)::numeric))
);


--
-- Name: cart_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_shipping_method_adjustment" (
    "id" "text" NOT NULL,
    "description" "text",
    "promotion_id" "text",
    "code" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "provider_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "shipping_method_id" "text"
);


--
-- Name: cart_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cart_shipping_method_tax_line" (
    "id" "text" NOT NULL,
    "description" "text",
    "tax_rate_id" "text",
    "code" "text" NOT NULL,
    "rate" real NOT NULL,
    "provider_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "shipping_method_id" "text"
);


--
-- Name: credit_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."credit_line" (
    "id" "text" NOT NULL,
    "cart_id" "text" NOT NULL,
    "reference" "text",
    "reference_id" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: currency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."currency" (
    "code" "text" NOT NULL,
    "symbol" "text" NOT NULL,
    "symbol_native" "text" NOT NULL,
    "decimal_digits" integer DEFAULT 0 NOT NULL,
    "rounding" numeric DEFAULT 0 NOT NULL,
    "raw_rounding" "jsonb" NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customer" (
    "id" "text" NOT NULL,
    "company_name" "text",
    "first_name" "text",
    "last_name" "text",
    "email" "text",
    "phone" "text",
    "has_account" boolean DEFAULT false NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "created_by" "text"
);


--
-- Name: customer_account_holder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customer_account_holder" (
    "customer_id" character varying(255) NOT NULL,
    "account_holder_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: customer_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customer_address" (
    "id" "text" NOT NULL,
    "customer_id" "text" NOT NULL,
    "address_name" "text",
    "is_default_shipping" boolean DEFAULT false NOT NULL,
    "is_default_billing" boolean DEFAULT false NOT NULL,
    "company" "text",
    "first_name" "text",
    "last_name" "text",
    "address_1" "text",
    "address_2" "text",
    "city" "text",
    "country_code" "text",
    "province" "text",
    "postal_code" "text",
    "phone" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: customer_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customer_group" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "metadata" "jsonb",
    "created_by" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: customer_group_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."customer_group_customer" (
    "id" "text" NOT NULL,
    "customer_id" "text" NOT NULL,
    "customer_group_id" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "text",
    "deleted_at" timestamp with time zone
);


--
-- Name: fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment" (
    "id" "text" NOT NULL,
    "location_id" "text" NOT NULL,
    "packed_at" timestamp with time zone,
    "shipped_at" timestamp with time zone,
    "delivered_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "data" "jsonb",
    "provider_id" "text",
    "shipping_option_id" "text",
    "metadata" "jsonb",
    "delivery_address_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "marked_shipped_by" "text",
    "created_by" "text",
    "requires_shipping" boolean DEFAULT true NOT NULL
);


--
-- Name: fulfillment_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment_address" (
    "id" "text" NOT NULL,
    "company" "text",
    "first_name" "text",
    "last_name" "text",
    "address_1" "text",
    "address_2" "text",
    "city" "text",
    "country_code" "text",
    "province" "text",
    "postal_code" "text",
    "phone" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: fulfillment_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment_item" (
    "id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "sku" "text" NOT NULL,
    "barcode" "text" NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" "jsonb" NOT NULL,
    "line_item_id" "text",
    "inventory_item_id" "text",
    "fulfillment_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: fulfillment_label; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment_label" (
    "id" "text" NOT NULL,
    "tracking_number" "text" NOT NULL,
    "tracking_url" "text" NOT NULL,
    "label_url" "text" NOT NULL,
    "fulfillment_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: fulfillment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment_provider" (
    "id" "text" NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: fulfillment_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."fulfillment_set" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "type" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: geo_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."geo_zone" (
    "id" "text" NOT NULL,
    "type" "text" DEFAULT 'country'::"text" NOT NULL,
    "country_code" "text" NOT NULL,
    "province_code" "text",
    "city" "text",
    "service_zone_id" "text" NOT NULL,
    "postal_expression" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "geo_zone_type_check" CHECK (("type" = ANY (ARRAY['country'::"text", 'province'::"text", 'city'::"text", 'zip'::"text"])))
);


--
-- Name: image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."image" (
    "id" "text" NOT NULL,
    "url" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "rank" integer DEFAULT 0 NOT NULL,
    "product_id" "text" NOT NULL
);


--
-- Name: inventory_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."inventory_item" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "sku" "text",
    "origin_country" "text",
    "hs_code" "text",
    "mid_code" "text",
    "material" "text",
    "weight" integer,
    "length" integer,
    "height" integer,
    "width" integer,
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "description" "text",
    "title" "text",
    "thumbnail" "text",
    "metadata" "jsonb"
);


--
-- Name: inventory_level; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."inventory_level" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "inventory_item_id" "text" NOT NULL,
    "location_id" "text" NOT NULL,
    "stocked_quantity" numeric DEFAULT 0 NOT NULL,
    "reserved_quantity" numeric DEFAULT 0 NOT NULL,
    "incoming_quantity" numeric DEFAULT 0 NOT NULL,
    "metadata" "jsonb",
    "raw_stocked_quantity" "jsonb",
    "raw_reserved_quantity" "jsonb",
    "raw_incoming_quantity" "jsonb"
);


--
-- Name: invite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."invite" (
    "id" "text" NOT NULL,
    "email" "text" NOT NULL,
    "accepted" boolean DEFAULT false NOT NULL,
    "token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: invite_rbac_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."invite_rbac_role" (
    "invite_id" character varying(255) NOT NULL,
    "rbac_role_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: link_module_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."link_module_migrations" (
    "id" integer NOT NULL,
    "table_name" character varying(255) NOT NULL,
    "link_descriptor" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."link_module_migrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."link_module_migrations_id_seq" OWNED BY "public"."link_module_migrations"."id";


--
-- Name: location_fulfillment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."location_fulfillment_provider" (
    "stock_location_id" character varying(255) NOT NULL,
    "fulfillment_provider_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: location_fulfillment_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."location_fulfillment_set" (
    "stock_location_id" character varying(255) NOT NULL,
    "fulfillment_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."menu_item" (
    "id" "text" NOT NULL,
    "menu_key" "text" NOT NULL,
    "parent_id" "text",
    "label" "text" NOT NULL,
    "href" "text",
    "position" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: mikro_orm_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."mikro_orm_migrations" (
    "id" integer NOT NULL,
    "name" character varying(255),
    "executed_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."mikro_orm_migrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."mikro_orm_migrations_id_seq" OWNED BY "public"."mikro_orm_migrations"."id";


--
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."notification" (
    "id" "text" NOT NULL,
    "to" "text" NOT NULL,
    "channel" "text" NOT NULL,
    "template" "text",
    "data" "jsonb",
    "trigger_type" "text",
    "resource_id" "text",
    "resource_type" "text",
    "receiver_id" "text",
    "original_notification_id" "text",
    "idempotency_key" "text",
    "external_id" "text",
    "provider_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "from" "text",
    "provider_data" "jsonb",
    CONSTRAINT "notification_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'success'::"text", 'failure'::"text"])))
);


--
-- Name: notification_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."notification_provider" (
    "id" "text" NOT NULL,
    "handle" "text" NOT NULL,
    "name" "text" NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "channels" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order" (
    "id" "text" NOT NULL,
    "region_id" "text",
    "display_id" integer,
    "customer_id" "text",
    "version" integer DEFAULT 1 NOT NULL,
    "sales_channel_id" "text",
    "status" "public"."order_status_enum" DEFAULT 'pending'::"public"."order_status_enum" NOT NULL,
    "is_draft_order" boolean DEFAULT false NOT NULL,
    "email" "text",
    "currency_code" "text" NOT NULL,
    "shipping_address_id" "text",
    "billing_address_id" "text",
    "no_notification" boolean,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "custom_display_id" "text",
    "locale" "text"
);


--
-- Name: order_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_address" (
    "id" "text" NOT NULL,
    "customer_id" "text",
    "company" "text",
    "first_name" "text",
    "last_name" "text",
    "address_1" "text",
    "address_2" "text",
    "city" "text",
    "country_code" "text",
    "province" "text",
    "postal_code" "text",
    "phone" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_cart" (
    "order_id" character varying(255) NOT NULL,
    "cart_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_change; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_change" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "version" integer NOT NULL,
    "description" "text",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "internal_note" "text",
    "created_by" "text",
    "requested_by" "text",
    "requested_at" timestamp with time zone,
    "confirmed_by" "text",
    "confirmed_at" timestamp with time zone,
    "declined_by" "text",
    "declined_reason" "text",
    "metadata" "jsonb",
    "declined_at" timestamp with time zone,
    "canceled_by" "text",
    "canceled_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "change_type" "text",
    "deleted_at" timestamp with time zone,
    "return_id" "text",
    "claim_id" "text",
    "exchange_id" "text",
    "carry_over_promotions" boolean,
    CONSTRAINT "order_change_status_check" CHECK (("status" = ANY (ARRAY['confirmed'::"text", 'declined'::"text", 'requested'::"text", 'pending'::"text", 'canceled'::"text"])))
);


--
-- Name: order_change_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_change_action" (
    "id" "text" NOT NULL,
    "order_id" "text",
    "version" integer,
    "ordering" bigint NOT NULL,
    "order_change_id" "text",
    "reference" "text",
    "reference_id" "text",
    "action" "text" NOT NULL,
    "details" "jsonb",
    "amount" numeric,
    "raw_amount" "jsonb",
    "internal_note" "text",
    "applied" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "return_id" "text",
    "claim_id" "text",
    "exchange_id" "text"
);


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_change_action_ordering_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."order_change_action_ordering_seq" OWNED BY "public"."order_change_action"."ordering";


--
-- Name: order_claim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_claim" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "return_id" "text",
    "order_version" integer NOT NULL,
    "display_id" integer NOT NULL,
    "type" "public"."order_claim_type_enum" NOT NULL,
    "no_notification" boolean,
    "refund_amount" numeric,
    "raw_refund_amount" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "created_by" "text"
);


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_claim_display_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."order_claim_display_id_seq" OWNED BY "public"."order_claim"."display_id";


--
-- Name: order_claim_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_claim_item" (
    "id" "text" NOT NULL,
    "claim_id" "text" NOT NULL,
    "item_id" "text" NOT NULL,
    "is_additional_item" boolean DEFAULT false NOT NULL,
    "reason" "public"."claim_reason_enum",
    "quantity" numeric NOT NULL,
    "raw_quantity" "jsonb" NOT NULL,
    "note" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_claim_item_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_claim_item_image" (
    "id" "text" NOT NULL,
    "claim_item_id" "text" NOT NULL,
    "url" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_credit_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_credit_line" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "reference" "text",
    "reference_id" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "version" integer DEFAULT 1 NOT NULL
);


--
-- Name: order_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_display_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."order_display_id_seq" OWNED BY "public"."order"."display_id";


--
-- Name: order_exchange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_exchange" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "return_id" "text",
    "order_version" integer NOT NULL,
    "display_id" integer NOT NULL,
    "no_notification" boolean,
    "allow_backorder" boolean DEFAULT false NOT NULL,
    "difference_due" numeric,
    "raw_difference_due" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "created_by" "text"
);


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_exchange_display_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."order_exchange_display_id_seq" OWNED BY "public"."order_exchange"."display_id";


--
-- Name: order_exchange_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_exchange_item" (
    "id" "text" NOT NULL,
    "exchange_id" "text" NOT NULL,
    "item_id" "text" NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" "jsonb" NOT NULL,
    "note" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_fulfillment" (
    "order_id" character varying(255) NOT NULL,
    "fulfillment_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_item" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "version" integer NOT NULL,
    "item_id" "text" NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" "jsonb" NOT NULL,
    "fulfilled_quantity" numeric NOT NULL,
    "raw_fulfilled_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "shipped_quantity" numeric NOT NULL,
    "raw_shipped_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "return_requested_quantity" numeric NOT NULL,
    "raw_return_requested_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "return_received_quantity" numeric NOT NULL,
    "raw_return_received_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "return_dismissed_quantity" numeric NOT NULL,
    "raw_return_dismissed_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "written_off_quantity" numeric NOT NULL,
    "raw_written_off_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "delivered_quantity" numeric DEFAULT 0 NOT NULL,
    "raw_delivered_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "unit_price" numeric,
    "raw_unit_price" "jsonb",
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" "jsonb"
);


--
-- Name: order_line_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_line_item" (
    "id" "text" NOT NULL,
    "totals_id" "text",
    "title" "text" NOT NULL,
    "subtitle" "text",
    "thumbnail" "text",
    "variant_id" "text",
    "product_id" "text",
    "product_title" "text",
    "product_description" "text",
    "product_subtitle" "text",
    "product_type" "text",
    "product_collection" "text",
    "product_handle" "text",
    "variant_sku" "text",
    "variant_barcode" "text",
    "variant_title" "text",
    "variant_option_values" "jsonb",
    "requires_shipping" boolean DEFAULT true NOT NULL,
    "is_discountable" boolean DEFAULT true NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "compare_at_unit_price" numeric,
    "raw_compare_at_unit_price" "jsonb",
    "unit_price" numeric NOT NULL,
    "raw_unit_price" "jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_custom_price" boolean DEFAULT false NOT NULL,
    "product_type_id" "text",
    "is_giftcard" boolean DEFAULT false NOT NULL
);


--
-- Name: order_line_item_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_line_item_adjustment" (
    "id" "text" NOT NULL,
    "description" "text",
    "promotion_id" "text",
    "code" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "provider_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "item_id" "text" NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "version" integer DEFAULT 1 NOT NULL
);


--
-- Name: order_line_item_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_line_item_tax_line" (
    "id" "text" NOT NULL,
    "description" "text",
    "tax_rate_id" "text",
    "code" "text" NOT NULL,
    "rate" numeric NOT NULL,
    "raw_rate" "jsonb" NOT NULL,
    "provider_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "item_id" "text" NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_payment_collection" (
    "order_id" character varying(255) NOT NULL,
    "payment_collection_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_promotion" (
    "order_id" character varying(255) NOT NULL,
    "promotion_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_shipping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_shipping" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "version" integer NOT NULL,
    "shipping_method_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "return_id" "text",
    "claim_id" "text",
    "exchange_id" "text"
);


--
-- Name: order_shipping_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_shipping_method" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "jsonb",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "shipping_option_id" "text",
    "data" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_custom_amount" boolean DEFAULT false NOT NULL
);


--
-- Name: order_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_shipping_method_adjustment" (
    "id" "text" NOT NULL,
    "description" "text",
    "promotion_id" "text",
    "code" "text",
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "provider_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "shipping_method_id" "text" NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_shipping_method_tax_line" (
    "id" "text" NOT NULL,
    "description" "text",
    "tax_rate_id" "text",
    "code" "text" NOT NULL,
    "rate" numeric NOT NULL,
    "raw_rate" "jsonb" NOT NULL,
    "provider_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "shipping_method_id" "text" NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_summary" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "version" integer DEFAULT 1 NOT NULL,
    "totals" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: order_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."order_transaction" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "version" integer DEFAULT 1 NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "currency_code" "text" NOT NULL,
    "reference" "text",
    "reference_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "return_id" "text",
    "claim_id" "text",
    "exchange_id" "text"
);


--
-- Name: page; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."page" (
    "id" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text",
    "meta_description" "text",
    "is_published" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."payment" (
    "id" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "currency_code" "text" NOT NULL,
    "provider_id" "text" NOT NULL,
    "data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "captured_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "payment_collection_id" "text" NOT NULL,
    "payment_session_id" "text" NOT NULL,
    "metadata" "jsonb"
);


--
-- Name: payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."payment_collection" (
    "id" "text" NOT NULL,
    "currency_code" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "authorized_amount" numeric,
    "raw_authorized_amount" "jsonb",
    "captured_amount" numeric,
    "raw_captured_amount" "jsonb",
    "refunded_amount" numeric,
    "raw_refunded_amount" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "completed_at" timestamp with time zone,
    "status" "text" DEFAULT 'not_paid'::"text" NOT NULL,
    "metadata" "jsonb",
    CONSTRAINT "payment_collection_status_check" CHECK (("status" = ANY (ARRAY['not_paid'::"text", 'awaiting'::"text", 'authorized'::"text", 'partially_authorized'::"text", 'canceled'::"text", 'failed'::"text", 'partially_captured'::"text", 'completed'::"text"])))
);


--
-- Name: payment_collection_payment_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."payment_collection_payment_providers" (
    "payment_collection_id" "text" NOT NULL,
    "payment_provider_id" "text" NOT NULL
);


--
-- Name: payment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."payment_provider" (
    "id" "text" NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: payment_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."payment_session" (
    "id" "text" NOT NULL,
    "currency_code" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "provider_id" "text" NOT NULL,
    "data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "context" "jsonb",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "authorized_at" timestamp with time zone,
    "payment_collection_id" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "payment_session_status_check" CHECK (("status" = ANY (ARRAY['authorized'::"text", 'captured'::"text", 'pending'::"text", 'requires_more'::"text", 'error'::"text", 'canceled'::"text"])))
);


--
-- Name: price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price" (
    "id" "text" NOT NULL,
    "title" "text",
    "price_set_id" "text" NOT NULL,
    "currency_code" "text" NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "rules_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "price_list_id" "text",
    "amount" numeric NOT NULL,
    "min_quantity" numeric,
    "max_quantity" numeric,
    "raw_min_quantity" "jsonb",
    "raw_max_quantity" "jsonb"
);


--
-- Name: price_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_list" (
    "id" "text" NOT NULL,
    "status" "text" DEFAULT 'draft'::"text" NOT NULL,
    "starts_at" timestamp with time zone,
    "ends_at" timestamp with time zone,
    "rules_count" integer DEFAULT 0,
    "title" "text" NOT NULL,
    "description" "text" NOT NULL,
    "type" "text" DEFAULT 'sale'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "price_list_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'draft'::"text"]))),
    CONSTRAINT "price_list_type_check" CHECK (("type" = ANY (ARRAY['sale'::"text", 'override'::"text"])))
);


--
-- Name: price_list_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_list_rule" (
    "id" "text" NOT NULL,
    "price_list_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "value" "jsonb",
    "attribute" "text" DEFAULT ''::"text" NOT NULL
);


--
-- Name: price_preference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_preference" (
    "id" "text" NOT NULL,
    "attribute" "text" NOT NULL,
    "value" "text",
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: price_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_rule" (
    "id" "text" NOT NULL,
    "value" "text" NOT NULL,
    "priority" integer DEFAULT 0 NOT NULL,
    "price_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "attribute" "text" DEFAULT ''::"text" NOT NULL,
    "operator" "text" DEFAULT 'eq'::"text" NOT NULL,
    CONSTRAINT "price_rule_operator_check" CHECK (("operator" = ANY (ARRAY['gte'::"text", 'lte'::"text", 'gt'::"text", 'lt'::"text", 'eq'::"text"])))
);


--
-- Name: price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_set" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product" (
    "id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "handle" "text" NOT NULL,
    "subtitle" "text",
    "description" "text",
    "is_giftcard" boolean DEFAULT false NOT NULL,
    "status" "text" DEFAULT 'draft'::"text" NOT NULL,
    "thumbnail" "text",
    "weight" "text",
    "length" "text",
    "height" "text",
    "width" "text",
    "origin_country" "text",
    "hs_code" "text",
    "mid_code" "text",
    "material" "text",
    "collection_id" "text",
    "type_id" "text",
    "discountable" boolean DEFAULT true NOT NULL,
    "external_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "metadata" "jsonb",
    CONSTRAINT "product_status_check" CHECK (("status" = ANY (ARRAY['draft'::"text", 'proposed'::"text", 'published'::"text", 'rejected'::"text"])))
);


--
-- Name: product_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_category" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text" DEFAULT ''::"text" NOT NULL,
    "handle" "text" NOT NULL,
    "mpath" "text" NOT NULL,
    "is_active" boolean DEFAULT false NOT NULL,
    "is_internal" boolean DEFAULT false NOT NULL,
    "rank" integer DEFAULT 0 NOT NULL,
    "parent_category_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "metadata" "jsonb"
);


--
-- Name: product_category_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_category_product" (
    "product_id" "text" NOT NULL,
    "product_category_id" "text" NOT NULL
);


--
-- Name: product_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_collection" (
    "id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "handle" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_option" (
    "id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "product_id" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_option_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_option_value" (
    "id" "text" NOT NULL,
    "value" "text" NOT NULL,
    "option_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_sales_channel" (
    "product_id" character varying(255) NOT NULL,
    "sales_channel_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_shipping_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_shipping_profile" (
    "product_id" character varying(255) NOT NULL,
    "shipping_profile_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_tag" (
    "id" "text" NOT NULL,
    "value" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_tags" (
    "product_id" "text" NOT NULL,
    "product_tag_id" "text" NOT NULL
);


--
-- Name: product_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_type" (
    "id" "text" NOT NULL,
    "value" "text" NOT NULL,
    "metadata" "json",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_variant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_variant" (
    "id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "sku" "text",
    "barcode" "text",
    "ean" "text",
    "upc" "text",
    "allow_backorder" boolean DEFAULT false NOT NULL,
    "manage_inventory" boolean DEFAULT true NOT NULL,
    "hs_code" "text",
    "origin_country" "text",
    "mid_code" "text",
    "material" "text",
    "weight" integer,
    "length" integer,
    "height" integer,
    "width" integer,
    "metadata" "jsonb",
    "variant_rank" integer DEFAULT 0,
    "product_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "thumbnail" "text"
);


--
-- Name: product_variant_inventory_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_variant_inventory_item" (
    "variant_id" character varying(255) NOT NULL,
    "inventory_item_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "required_quantity" integer DEFAULT 1 NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_variant_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_variant_option" (
    "variant_id" "text" NOT NULL,
    "option_value_id" "text" NOT NULL
);


--
-- Name: product_variant_price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_variant_price_set" (
    "variant_id" character varying(255) NOT NULL,
    "price_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: product_variant_product_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."product_variant_product_image" (
    "id" "text" NOT NULL,
    "variant_id" "text" NOT NULL,
    "image_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion" (
    "id" "text" NOT NULL,
    "code" "text" NOT NULL,
    "campaign_id" "text",
    "is_automatic" boolean DEFAULT false NOT NULL,
    "type" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "status" "text" DEFAULT 'draft'::"text" NOT NULL,
    "is_tax_inclusive" boolean DEFAULT false NOT NULL,
    "limit" integer,
    "used" integer DEFAULT 0 NOT NULL,
    "metadata" "jsonb",
    CONSTRAINT "promotion_status_check" CHECK (("status" = ANY (ARRAY['draft'::"text", 'active'::"text", 'inactive'::"text"]))),
    CONSTRAINT "promotion_type_check" CHECK (("type" = ANY (ARRAY['standard'::"text", 'buyget'::"text"])))
);


--
-- Name: promotion_application_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_application_method" (
    "id" "text" NOT NULL,
    "value" numeric,
    "raw_value" "jsonb",
    "max_quantity" integer,
    "apply_to_quantity" integer,
    "buy_rules_min_quantity" integer,
    "type" "text" NOT NULL,
    "target_type" "text" NOT NULL,
    "allocation" "text",
    "promotion_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "currency_code" "text",
    CONSTRAINT "promotion_application_method_allocation_check" CHECK (("allocation" = ANY (ARRAY['each'::"text", 'across'::"text", 'once'::"text"]))),
    CONSTRAINT "promotion_application_method_target_type_check" CHECK (("target_type" = ANY (ARRAY['order'::"text", 'shipping_methods'::"text", 'items'::"text"]))),
    CONSTRAINT "promotion_application_method_type_check" CHECK (("type" = ANY (ARRAY['fixed'::"text", 'percentage'::"text"])))
);


--
-- Name: promotion_campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_campaign" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "campaign_identifier" "text" NOT NULL,
    "starts_at" timestamp with time zone,
    "ends_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: promotion_campaign_budget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_campaign_budget" (
    "id" "text" NOT NULL,
    "type" "text" NOT NULL,
    "campaign_id" "text" NOT NULL,
    "limit" numeric,
    "raw_limit" "jsonb",
    "used" numeric DEFAULT 0 NOT NULL,
    "raw_used" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "currency_code" "text",
    "attribute" "text",
    CONSTRAINT "promotion_campaign_budget_type_check" CHECK (("type" = ANY (ARRAY['spend'::"text", 'usage'::"text", 'use_by_attribute'::"text", 'spend_by_attribute'::"text"])))
);


--
-- Name: promotion_campaign_budget_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_campaign_budget_usage" (
    "id" "text" NOT NULL,
    "attribute_value" "text" NOT NULL,
    "used" numeric DEFAULT 0 NOT NULL,
    "budget_id" "text" NOT NULL,
    "raw_used" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: promotion_promotion_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_promotion_rule" (
    "promotion_id" "text" NOT NULL,
    "promotion_rule_id" "text" NOT NULL
);


--
-- Name: promotion_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_rule" (
    "id" "text" NOT NULL,
    "description" "text",
    "attribute" "text" NOT NULL,
    "operator" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "promotion_rule_operator_check" CHECK (("operator" = ANY (ARRAY['gte'::"text", 'lte'::"text", 'gt'::"text", 'lt'::"text", 'eq'::"text", 'ne'::"text", 'in'::"text"])))
);


--
-- Name: promotion_rule_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."promotion_rule_value" (
    "id" "text" NOT NULL,
    "promotion_rule_id" "text" NOT NULL,
    "value" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: provider_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."provider_identity" (
    "id" "text" NOT NULL,
    "entity_id" "text" NOT NULL,
    "provider" "text" NOT NULL,
    "auth_identity_id" "text" NOT NULL,
    "user_metadata" "jsonb",
    "provider_metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: publishable_api_key_sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."publishable_api_key_sales_channel" (
    "publishable_key_id" character varying(255) NOT NULL,
    "sales_channel_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: refund; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."refund" (
    "id" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "raw_amount" "jsonb" NOT NULL,
    "payment_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "created_by" "text",
    "metadata" "jsonb",
    "refund_reason_id" "text",
    "note" "text"
);


--
-- Name: refund_reason; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."refund_reason" (
    "id" "text" NOT NULL,
    "label" "text" NOT NULL,
    "description" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "code" "text" NOT NULL
);


--
-- Name: region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."region" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "currency_code" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "automatic_taxes" boolean DEFAULT true NOT NULL
);


--
-- Name: region_country; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."region_country" (
    "iso_2" "text" NOT NULL,
    "iso_3" "text" NOT NULL,
    "num_code" "text" NOT NULL,
    "name" "text" NOT NULL,
    "display_name" "text" NOT NULL,
    "region_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: region_payment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."region_payment_provider" (
    "region_id" character varying(255) NOT NULL,
    "payment_provider_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: reservation_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."reservation_item" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "line_item_id" "text",
    "location_id" "text" NOT NULL,
    "quantity" numeric NOT NULL,
    "external_id" "text",
    "description" "text",
    "created_by" "text",
    "metadata" "jsonb",
    "inventory_item_id" "text" NOT NULL,
    "allow_backorder" boolean DEFAULT false,
    "raw_quantity" "jsonb"
);


--
-- Name: return; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."return" (
    "id" "text" NOT NULL,
    "order_id" "text" NOT NULL,
    "claim_id" "text",
    "exchange_id" "text",
    "order_version" integer NOT NULL,
    "display_id" integer NOT NULL,
    "status" "public"."return_status_enum" DEFAULT 'open'::"public"."return_status_enum" NOT NULL,
    "no_notification" boolean,
    "refund_amount" numeric,
    "raw_refund_amount" "jsonb",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "received_at" timestamp with time zone,
    "canceled_at" timestamp with time zone,
    "location_id" "text",
    "requested_at" timestamp with time zone,
    "created_by" "text"
);


--
-- Name: return_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."return_display_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: return_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."return_display_id_seq" OWNED BY "public"."return"."display_id";


--
-- Name: return_fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."return_fulfillment" (
    "return_id" character varying(255) NOT NULL,
    "fulfillment_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: return_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."return_item" (
    "id" "text" NOT NULL,
    "return_id" "text" NOT NULL,
    "reason_id" "text",
    "item_id" "text" NOT NULL,
    "quantity" numeric NOT NULL,
    "raw_quantity" "jsonb" NOT NULL,
    "received_quantity" numeric DEFAULT 0 NOT NULL,
    "raw_received_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL,
    "note" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "damaged_quantity" numeric DEFAULT 0 NOT NULL,
    "raw_damaged_quantity" "jsonb" DEFAULT '{"value": "0", "precision": 20}'::"jsonb" NOT NULL
);


--
-- Name: return_reason; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."return_reason" (
    "id" character varying NOT NULL,
    "value" character varying NOT NULL,
    "label" character varying NOT NULL,
    "description" character varying,
    "metadata" "jsonb",
    "parent_return_reason_id" character varying,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."sales_channel" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "is_disabled" boolean DEFAULT false NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: sales_channel_stock_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."sales_channel_stock_location" (
    "sales_channel_id" character varying(255) NOT NULL,
    "stock_location_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: script_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."script_migrations" (
    "id" integer NOT NULL,
    "script_name" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "finished_at" timestamp with time zone
);


--
-- Name: script_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."script_migrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: script_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."script_migrations_id_seq" OWNED BY "public"."script_migrations"."id";


--
-- Name: service_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."service_zone" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "metadata" "jsonb",
    "fulfillment_set_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: shipping_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shipping_option" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "price_type" "text" DEFAULT 'flat'::"text" NOT NULL,
    "service_zone_id" "text" NOT NULL,
    "shipping_profile_id" "text",
    "provider_id" "text",
    "data" "jsonb",
    "metadata" "jsonb",
    "shipping_option_type_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "shipping_option_price_type_check" CHECK (("price_type" = ANY (ARRAY['calculated'::"text", 'flat'::"text"])))
);


--
-- Name: shipping_option_price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shipping_option_price_set" (
    "shipping_option_id" character varying(255) NOT NULL,
    "price_set_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: shipping_option_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shipping_option_rule" (
    "id" "text" NOT NULL,
    "attribute" "text" NOT NULL,
    "operator" "text" NOT NULL,
    "value" "jsonb",
    "shipping_option_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    CONSTRAINT "shipping_option_rule_operator_check" CHECK (("operator" = ANY (ARRAY['in'::"text", 'eq'::"text", 'ne'::"text", 'gt'::"text", 'gte'::"text", 'lt'::"text", 'lte'::"text", 'nin'::"text"])))
);


--
-- Name: shipping_option_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shipping_option_type" (
    "id" "text" NOT NULL,
    "label" "text" NOT NULL,
    "description" "text",
    "code" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: shipping_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."shipping_profile" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "type" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: site_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."site_config" (
    "id" "text" NOT NULL,
    "key" "text" NOT NULL,
    "value" "text",
    "label" "text",
    "description" "text",
    "group" "text",
    "is_public" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: stock_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."stock_location" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "name" "text" NOT NULL,
    "address_id" "text",
    "metadata" "jsonb"
);


--
-- Name: stock_location_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."stock_location_address" (
    "id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "address_1" "text" NOT NULL,
    "address_2" "text",
    "company" "text",
    "city" "text",
    "country_code" "text" NOT NULL,
    "phone" "text",
    "province" "text",
    "postal_code" "text",
    "metadata" "jsonb"
);


--
-- Name: store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."store" (
    "id" "text" NOT NULL,
    "name" "text" DEFAULT 'Medusa Store'::"text" NOT NULL,
    "default_sales_channel_id" "text",
    "default_region_id" "text",
    "default_location_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: store_currency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."store_currency" (
    "id" "text" NOT NULL,
    "currency_code" "text" NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    "store_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: store_locale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."store_locale" (
    "id" "text" NOT NULL,
    "locale_code" "text" NOT NULL,
    "store_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: tax_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."tax_provider" (
    "id" "text" NOT NULL,
    "is_enabled" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: tax_rate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."tax_rate" (
    "id" "text" NOT NULL,
    "rate" real,
    "code" "text" NOT NULL,
    "name" "text" NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    "is_combinable" boolean DEFAULT false NOT NULL,
    "tax_region_id" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "text",
    "deleted_at" timestamp with time zone
);


--
-- Name: tax_rate_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."tax_rate_rule" (
    "id" "text" NOT NULL,
    "tax_rate_id" "text" NOT NULL,
    "reference_id" "text" NOT NULL,
    "reference" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "text",
    "deleted_at" timestamp with time zone
);


--
-- Name: tax_region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."tax_region" (
    "id" "text" NOT NULL,
    "provider_id" "text",
    "country_code" "text" NOT NULL,
    "province_code" "text",
    "parent_id" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "text",
    "deleted_at" timestamp with time zone,
    CONSTRAINT "CK_tax_region_country_top_level" CHECK ((("parent_id" IS NULL) OR ("province_code" IS NOT NULL))),
    CONSTRAINT "CK_tax_region_provider_top_level" CHECK ((("parent_id" IS NULL) OR ("provider_id" IS NULL)))
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."user" (
    "id" "text" NOT NULL,
    "first_name" "text",
    "last_name" "text",
    "email" "text" NOT NULL,
    "avatar_url" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: user_preference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."user_preference" (
    "id" "text" NOT NULL,
    "user_id" "text" NOT NULL,
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: user_rbac_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."user_rbac_role" (
    "user_id" character varying(255) NOT NULL,
    "rbac_role_id" character varying(255) NOT NULL,
    "id" character varying(255) NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: view_configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."view_configuration" (
    "id" "text" NOT NULL,
    "entity" "text" NOT NULL,
    "name" "text",
    "user_id" "text",
    "is_system_default" boolean DEFAULT false NOT NULL,
    "configuration" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone
);


--
-- Name: workflow_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."workflow_execution" (
    "id" character varying NOT NULL,
    "workflow_id" character varying NOT NULL,
    "transaction_id" character varying NOT NULL,
    "execution" "jsonb",
    "context" "jsonb",
    "state" character varying NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp without time zone,
    "retention_time" integer,
    "run_id" "text" DEFAULT '01KPVEF3A97KZKAV4HRN1WWWHX'::"text" NOT NULL
);


--
-- Name: link_module_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."link_module_migrations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."link_module_migrations_id_seq"'::"regclass");


--
-- Name: mikro_orm_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."mikro_orm_migrations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."mikro_orm_migrations_id_seq"'::"regclass");


--
-- Name: order display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order" ALTER COLUMN "display_id" SET DEFAULT "nextval"('"public"."order_display_id_seq"'::"regclass");


--
-- Name: order_change_action ordering; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_change_action" ALTER COLUMN "ordering" SET DEFAULT "nextval"('"public"."order_change_action_ordering_seq"'::"regclass");


--
-- Name: order_claim display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_claim" ALTER COLUMN "display_id" SET DEFAULT "nextval"('"public"."order_claim_display_id_seq"'::"regclass");


--
-- Name: order_exchange display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_exchange" ALTER COLUMN "display_id" SET DEFAULT "nextval"('"public"."order_exchange_display_id_seq"'::"regclass");


--
-- Name: return display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return" ALTER COLUMN "display_id" SET DEFAULT "nextval"('"public"."return_display_id_seq"'::"regclass");


--
-- Name: script_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."script_migrations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."script_migrations_id_seq"'::"regclass");


--
-- Data for Name: account_holder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."account_holder" ("id", "provider_id", "external_id", "email", "data", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."api_key" ("id", "token", "salt", "redacted", "title", "type", "last_used_at", "created_by", "created_at", "revoked_by", "revoked_at", "updated_at", "deleted_at") FROM stdin;
apk_01KPVEFEXD4T7AK78WP29SQT5F	pk_adb05355e6b818965d0c7120fc98af2647f03a0613acb9d475420c1f0be50d60		pk_adb***d60	Default Publishable API Key	publishable	\N		2026-04-22 22:35:33.422+02	\N	\N	2026-04-22 22:35:33.422+02	\N
\.


--
-- Data for Name: application_method_buy_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."application_method_buy_rules" ("application_method_id", "promotion_rule_id") FROM stdin;
\.


--
-- Data for Name: application_method_target_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."application_method_target_rules" ("application_method_id", "promotion_rule_id") FROM stdin;
\.


--
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_identity" ("id", "app_metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
authid_01KPX6FX6Y7JE238FC0KMBR0R3	{"customer_id": "cus_01KPX6FXANAJHJBT1FK54HS3Y1"}	2026-04-23 14:54:28.318+02	2026-04-23 14:54:28.454+02	\N
authid_01KPX7HJRRC06NESXD578TBBKY	{"customer_id": "cus_01KPX7HJW19P1TBYBHMRX6R6AR"}	2026-04-23 15:12:51.737+02	2026-04-23 15:12:51.852+02	\N
authid_01KPXNG0Y4D3Y9G31Z23P3MFFB	{"customer_id": "cus_01KPXNG2T90W2G9NDAN07TERT2"}	2026-04-23 19:16:40.773+02	2026-04-23 19:16:42.717+02	\N
authid_01KPXP4T79CHHYS94Z4K8C45A4	{"customer_id": "cus_01KPXP4TB3DK2DTWTYYPA27XBV"}	2026-04-23 19:28:02.028+02	2026-04-23 19:28:02.183+02	\N
authid_01KPXP6C8D8B8ZK5Y6AZ2DD86C	{"customer_id": "cus_01KPXP6CB9JZHVQ2C3NWPFESB8"}	2026-04-23 19:28:53.261+02	2026-04-23 19:28:53.37+02	\N
authid_01KPXRKW88S0G1WT68EFNE19H7	{"customer_id": "cus_01KPXRKWT1F112T80S2VF76PN3"}	2026-04-23 20:11:12.78+02	2026-04-23 20:11:13.38+02	\N
authid_01KPXTR4EN2PZKHVZQ3HSCVKTJ	{"customer_id": "cus_01KPXTR4HTN1A5GNBKJSZK0Q6B"}	2026-04-23 20:48:29.398+02	2026-04-23 20:48:29.538+02	\N
authid_01KPVERWVNVNA6VJQ5S6S5N5GC	{"user_id": "user_01KPVERWMYC488JMTY56E4HW5C", "customer_id": "cus_01KPZ9VF4PWG48MPEEW2819XHC"}	2026-04-22 22:40:42.613+02	2026-04-24 10:31:41.749+02	\N
\.


--
-- Data for Name: banner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."banner" ("id", "slot", "title", "link", "image_url", "image_url_mobile", "position", "is_active", "created_at", "updated_at", "deleted_at") FROM stdin;
01KQ2BHWP6FRJGKN5QKNVFT5RS	hero	Home Banner 1	/search	https://assets.becauseyou.com.my/assets/images/fresh-flower-min.jpg	\N	0	t	2026-04-25 14:59:08.359+02	2026-04-25 14:59:08.359+02	\N
01KQ2BHWQZ5K4YPFTWJEXN5E7F	hero	Home Banner 2	/search	https://assets.becauseyou.com.my/assets/images/premium-design-min.jpg	\N	1	t	2026-04-25 14:59:08.416+02	2026-04-25 14:59:08.416+02	\N
01KQ2BHWRRK4H92HG8GY9EVP3A	hero	Home Banner 3	/search	https://assets.becauseyou.com.my/assets/images/sameday-delivery-min.jpg	\N	2	t	2026-04-25 14:59:08.44+02	2026-04-25 14:59:08.44+02	\N
\.


--
-- Data for Name: blog_post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."blog_post" ("id", "slug", "title", "excerpt", "content", "thumbnail", "author_name", "tags", "is_published", "published_at", "views", "created_at", "updated_at", "deleted_at") FROM stdin;
01KPXY63FX1D3X262F41AQXH9Q	condolence-flowers-a-gentle-expression-of-sympathy	Condolence Flowers: A Gentle Expression of Sympathy	In times of loss, flowers carry quiet comfort when words are hard to find. A thoughtful condolence flower KL arrangement brings peace and respect, honoring the memory of a loved one with grace.	In times of loss, flowers carry quiet comfort when words are hard to find. A thoughtful condolence flower KL arrangement brings peace and respect, honoring the memory of a loved one with grace.\n\nWhite lilies, chrysanthemums, and soft roses are classic choices for such moments, symbolizing purity, remembrance, and sincere sympathy. Whether for a service or a home tribute, condolence flower KL deliveries ensure your care arrives gently and on time.\n\nFlowers remain a timeless way to show support, offering warmth to those who grieve.\n\n### Frequently Asked Questions\n\n**What flowers are suitable for condolence in KL?**\n\nWhite lilies, white roses, and chrysanthemums are the most common and respectful choices.\n\n**Can I order condolence flower KL for same-day delivery?**\n\nYes — place your order by 2 PM and we will deliver the same day across KL and Petaling Jaya.	https://assets.becauseyou.com.my/assets/images/sameday-delivery-min.jpg	Because You Florist	{condolence,sympathy,kl}	t	2026-03-26 01:00:00+01	44	2026-04-23 21:48:32.893+02	2026-04-25 17:55:16.027+02	\N
01KPXY63E7YHP7YQB41DFW99FV	birthday-flower-bouquet-kl-your-perfect-floral-gift-guide	Birthday Flower Bouquet KL: Your Perfect Floral Gift Guide	A lovely birthday bouquet is the sweetest way to celebrate someone special in Kuala Lumpur. Bright sunflowers, soft pink roses, fresh lilies and vibrant mixed blooms make perfect birthday gifts.	In the heart of Kuala Lumpur, birthday celebrations call for something as vibrant and special as the loved one being honored — and a handpicked birthday flower bouquet KL is the ultimate way to spread joy. Whether you're celebrating a friend, family member, partner, or colleague, KL's finest florists craft arrangements that blend fresh blooms, artistic design, and heartfelt sentiment, making every birthday feel unforgettable.\n\nOur KL flower bouquets are freshly arranged and hand-delivered with care. Whether for a friend, family or loved one, a beautiful bouquet brings joy and warmth to their special day.\n\nSame-day delivery is available across KL and Petaling Jaya. Let fresh flowers speak for you and make the birthday unforgettable.\n\n### Frequently Asked Questions\n\n**Do you offer same-day delivery for birthday bouquets in KL?**\n\nYes. This service covers major areas including Kuala Lumpur city centre, Petaling Jaya, and surrounding suburbs. For last-minute gifts, simply place your order early, and your fresh bouquet will be hand-delivered on time.	https://assets.becauseyou.com.my/assets/images/fresh-flower-min.jpg	Because You Florist	{birthday,flowers,kl}	t	2026-03-25 01:00:00+01	35	2026-04-23 21:48:32.84+02	2026-04-25 17:55:16.039+02	\N
01KPXY63F74NKPNPB60AH2JMMS	hand-bouquet	Hand Bouquet	Are you looking for a quality, reliable, yet affordable flower bouquet near me option? We deliver fresh hand bouquets across Kuala Lumpur for every occasion.	Are you looking for a quality, reliable, yet affordable flower bouquet near me option?\n\nFlowers have historically been used to express emotion, and this practice continues today. Sending a bouquet is a time-honoured tradition, and now, with just a few clicks, you can easily have them delivered anywhere in Kuala Lumpur.\n\nWe provide fresh flower bouquets in Kuala Lumpur to liven up your celebrations. We guarantee that our best affordable flower bouquets will stay within the budget. You can find a lovely hand bouquet for a special occasion like a birthday or wedding.\n\n### Flower Delivery Service\n\nAmong all of creation's gifts, flowers are the most pristine and perfect for any occasion. Flowers are a common gift for many events, including weddings, birthdays, anniversaries, and congratulations. When someone is going through a bad patch, they are given these kinds of gifts in hopes that it will help them relax.\n\nFlowers bring fresh air and an exotic touch to any room. The gift of flowers, the very embodiment of love and caring, is often given to loved ones to express the most ethereal of feelings.	https://assets.becauseyou.com.my/assets/images/premium-design-min.jpg	Because You Florist	{"hand bouquet",flowers}	t	2025-09-26 02:00:00+02	43	2026-04-23 21:48:32.871+02	2026-04-25 17:55:31.917+02	\N
\.


--
-- Data for Name: capture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."capture" ("id", "amount", "raw_amount", "payment_id", "created_at", "updated_at", "deleted_at", "created_by", "metadata") FROM stdin;
capt_01KPZVCYAGWHTXE7RAVN7B8R6E	30	{"value": "30", "precision": 20}	pay_01KPWECVYNNQ39CB87ZBENA1DG	2026-04-24 15:38:20.113+02	2026-04-24 15:38:20.113+02	\N	\N	\N
\.


--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart" ("id", "region_id", "customer_id", "sales_channel_id", "email", "currency_code", "shipping_address_id", "billing_address_id", "metadata", "created_at", "updated_at", "deleted_at", "completed_at", "locale") FROM stdin;
cart_01KPWE4YF6EFBZHNNZPSB81PQ6	reg_01KPVEFKYDPAKWC7499ZXE0DY9	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	eur	\N	\N	\N	2026-04-23 07:49:03.34+02	2026-04-23 07:49:03.341+02	\N	\N	\N
cart_01KPVFBRERNG8Q0RM3RRR1FDS3	reg_01KPVEFKYDPAKWC7499ZXE0DY9	cus_01KPWECT9YXCHTFC2E10XC38M3	sc_01KPVEFEV595D4YCDP15QR7DDX	abc@test.com	eur	caaddr_01KPWECTB6A4308W48ET511SKW	caaddr_01KPWECTB5EWABMKQHQ68ZZMVW	\N	2026-04-22 22:51:00.7+02	2026-04-23 07:53:22.864+02	\N	2026-04-23 07:53:22.825+02	\N
cart_01KPZA0N4YQDDR6G3DPHN23CQV	reg_01KPVEFKYDPAKWC7499ZXE0DY9	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	eur	\N	\N	\N	2026-04-24 10:34:31.713+02	2026-04-24 10:34:31.713+02	\N	\N	\N
cart_01KPZA2JHYS4MWH3CF6SB2PBWZ	reg_01KPVEFKYDPAKWC7499ZXE0DY9	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	eur	\N	\N	\N	2026-04-24 10:35:34.591+02	2026-04-24 10:35:34.591+02	\N	\N	\N
cart_01KPZRBP0S7YAFEWRH5BB5A81H	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRBP0WKDTQ2V51P85HMB0H	\N	\N	2026-04-24 14:45:13.118+02	2026-04-24 14:45:13.118+02	\N	\N	\N
cart_01KPZRBPS8XZGQEBFRC85KB1QD	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRBPS8HFTZDQ7TQBVTXS3F	\N	\N	2026-04-24 14:45:13.897+02	2026-04-24 14:45:13.897+02	\N	\N	\N
cart_01KPZRBQPK1TX6HHC9SE3666E4	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRBQPM1KQJ07C3Y25ENGJT	\N	\N	2026-04-24 14:45:14.836+02	2026-04-24 14:45:14.836+02	\N	\N	\N
cart_01KPZRBZG6TJ6HHK56X10DMJG4	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRBZG7S6Q063MCHQ2DKSTY	\N	\N	2026-04-24 14:45:22.823+02	2026-04-24 14:45:22.823+02	\N	\N	\N
cart_01KPZRH65D9520WFF000DP8XCS	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRH65EJCJJJ84C6TFSYRKC	\N	\N	2026-04-24 14:48:13.486+02	2026-04-24 14:48:13.486+02	\N	\N	\N
cart_01KPZRH7N0D3YBQ9XW5ABEPP22	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRH7N1M9YG1T9315V8Y95S	\N	\N	2026-04-24 14:48:15.009+02	2026-04-24 14:48:15.009+02	\N	\N	\N
cart_01KPZRH90AM94GXK4MM17HB1MJ	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRH90AJ3EGDHY1226GRRCR	\N	\N	2026-04-24 14:48:16.395+02	2026-04-24 14:48:16.395+02	\N	\N	\N
cart_01KPZRHJH9012KNX0HXCMPK2PN	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRHJHAY1ARXWH8DZ8Y7CB7	\N	\N	2026-04-24 14:48:26.154+02	2026-04-24 14:48:26.154+02	\N	\N	\N
cart_01KPZRHKMCDG10EH1FJ5922E5A	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRHKMC4JAQDZHSE6ZGQYBS	\N	\N	2026-04-24 14:48:27.277+02	2026-04-24 14:48:27.277+02	\N	\N	\N
cart_01KPZRHN4P5DDFV139MX17MFG6	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRHN4QPQATGMSSR1AJRVZF	\N	\N	2026-04-24 14:48:28.823+02	2026-04-24 14:48:28.823+02	\N	\N	\N
cart_01KPZRJTCCYY55N2RSJJPE12TD	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	myr	caaddr_01KPZRJTCDVXMGP2NN0M8G2340	\N	\N	2026-04-24 14:49:06.958+02	2026-04-24 14:49:06.958+02	\N	\N	\N
cart_01KPZWCNZ5BJD35P52K09HDXY1	reg_01KPZA4WP86M2QS4F7YPJY792P	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	myr	caaddr_01KPZWCNZ6892XVEZBJRSDW0D4	\N	\N	2026-04-24 15:55:40.135+02	2026-04-24 15:55:40.135+02	\N	\N	\N
cart_01KPZWCXBNXEBWCNBHPPH13W5W	reg_01KPZA4WP86M2QS4F7YPJY792P	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	myr	caaddr_01KPZWCXBNYERV9D0JZ4795P13	\N	\N	2026-04-24 15:55:47.702+02	2026-04-24 15:55:47.702+02	\N	\N	\N
cart_01KPZWTCVM6FJYDYE38VBYG2JP	reg_01KPZA4WP86M2QS4F7YPJY792P	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	myr	caaddr_01KPZWTCVN92JFE7GDKPKMK4VJ	\N	\N	2026-04-24 16:03:09.559+02	2026-04-24 16:03:09.559+02	\N	\N	\N
cart_01KPZWVGF8R18BQ1F06NR55EJ1	reg_01KPZA4WP86M2QS4F7YPJY792P	cus_01KPZ9VF4PWG48MPEEW2819XHC	sc_01KPVEFEV595D4YCDP15QR7DDX	fate6317@gmail.com	myr	caaddr_01KPZWVGF9146YCGQZ4J6EZ7GF	\N	\N	2026-04-24 16:03:46.026+02	2026-04-24 16:03:46.026+02	\N	\N	\N
\.


--
-- Data for Name: cart_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_address" ("id", "customer_id", "company", "first_name", "last_name", "address_1", "address_2", "city", "country_code", "province", "postal_code", "phone", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
caaddr_01KPWECTB5EWABMKQHQ68ZZMVW	\N	\N	Test	Test	Test		Kl	dk	Kl	56000		\N	2026-04-23 07:53:21.254+02	2026-04-23 07:53:21.254+02	\N
caaddr_01KPWECTB6A4308W48ET511SKW	\N	\N	Test	Test	Test		Kl	dk	Kl	56000		\N	2026-04-23 07:53:21.255+02	2026-04-23 07:53:21.255+02	\N
caaddr_01KPZRBP0WKDTQ2V51P85HMB0H	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:45:13.117+02	2026-04-24 14:45:13.117+02	\N
caaddr_01KPZRBPS8HFTZDQ7TQBVTXS3F	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:45:13.897+02	2026-04-24 14:45:13.897+02	\N
caaddr_01KPZRBQPM1KQJ07C3Y25ENGJT	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:45:14.836+02	2026-04-24 14:45:14.836+02	\N
caaddr_01KPZRBZG7S6Q063MCHQ2DKSTY	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:45:22.823+02	2026-04-24 14:45:22.823+02	\N
caaddr_01KPZRH65EJCJJJ84C6TFSYRKC	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:13.486+02	2026-04-24 14:48:13.486+02	\N
caaddr_01KPZRH7N1M9YG1T9315V8Y95S	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:15.009+02	2026-04-24 14:48:15.009+02	\N
caaddr_01KPZRH90AJ3EGDHY1226GRRCR	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:16.395+02	2026-04-24 14:48:16.395+02	\N
caaddr_01KPZRHJHAY1ARXWH8DZ8Y7CB7	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:26.154+02	2026-04-24 14:48:26.154+02	\N
caaddr_01KPZRHKMC4JAQDZHSE6ZGQYBS	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:27.277+02	2026-04-24 14:48:27.277+02	\N
caaddr_01KPZRHN4QPQATGMSSR1AJRVZF	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:48:28.823+02	2026-04-24 14:48:28.823+02	\N
caaddr_01KPZRJTCDVXMGP2NN0M8G2340	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 14:49:06.958+02	2026-04-24 14:49:06.958+02	\N
caaddr_01KPZWCNZ6892XVEZBJRSDW0D4	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 15:55:40.135+02	2026-04-24 15:55:40.135+02	\N
caaddr_01KPZWCXBNYERV9D0JZ4795P13	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 15:55:47.702+02	2026-04-24 15:55:47.702+02	\N
caaddr_01KPZWTCVN92JFE7GDKPKMK4VJ	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 16:03:09.558+02	2026-04-24 16:03:09.558+02	\N
caaddr_01KPZWVGF9146YCGQZ4J6EZ7GF	\N	\N	\N	\N	\N	\N	\N	my	\N	\N	\N	\N	2026-04-24 16:03:46.026+02	2026-04-24 16:03:46.026+02	\N
\.


--
-- Data for Name: cart_line_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_line_item" ("id", "cart_id", "title", "subtitle", "thumbnail", "quantity", "variant_id", "product_id", "product_title", "product_description", "product_subtitle", "product_type", "product_collection", "product_handle", "variant_sku", "variant_barcode", "variant_title", "variant_option_values", "requires_shipping", "is_discountable", "is_tax_inclusive", "compare_at_unit_price", "raw_compare_at_unit_price", "unit_price", "raw_unit_price", "metadata", "created_at", "updated_at", "deleted_at", "product_type_id", "is_custom_price", "is_giftcard") FROM stdin;
cali_01KPVFBRW96T4Q1TCVYV1NHCFC	cart_01KPVFBRERNG8Q0RM3RRR1FDS3	Medusa Shorts	L	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	1	variant_01KPVEFMJ6HYMRDT21HFF4V4KC	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	Medusa Shorts	Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.	\N	\N	\N	shorts	SHORTS-L	\N	L	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-22 22:51:01.129+02	2026-04-22 22:51:01.129+02	\N	\N	f	f
cali_01KPWE6AVSSRYZ3JKBWNS1WXW9	cart_01KPWE4YF6EFBZHNNZPSB81PQ6	Medusa T-Shirt	S / White	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	2	variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	\N	\N	\N	t-shirt	SHIRT-S-WHITE	\N	S / White	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-23 07:49:48.794+02	2026-04-23 07:49:48.794+02	\N	\N	f	f
cali_01KPWEAH4PJEA7BWWECMNW95GK	cart_01KPVFBRERNG8Q0RM3RRR1FDS3	Medusa T-Shirt	M / Black	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	1	variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	\N	\N	\N	t-shirt	SHIRT-M-BLACK	\N	M / Black	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-23 07:52:06.294+02	2026-04-23 07:52:06.294+02	\N	\N	f	f
cali_01KPZA0NYPDQCZ2FF6D0MZ5DRB	cart_01KPZA0N4YQDDR6G3DPHN23CQV	Medusa T-Shirt	S / Black	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	1	variant_01KPVEFMJ0PAC67DG1FTDR18QX	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	\N	\N	\N	t-shirt	SHIRT-S-BLACK	\N	S / Black	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-24 10:34:32.534+02	2026-04-24 10:34:32.534+02	\N	\N	f	f
cali_01KPZA2KK64W29KERQKTH40R41	cart_01KPZA2JHYS4MWH3CF6SB2PBWZ	Medusa T-Shirt	S / Black	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	1	variant_01KPVEFMJ0PAC67DG1FTDR18QX	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	\N	\N	\N	t-shirt	SHIRT-S-BLACK	\N	S / Black	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-24 10:35:35.654+02	2026-04-24 10:35:35.654+02	\N	\N	f	f
\.


--
-- Data for Name: cart_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_line_item_adjustment" ("id", "description", "promotion_id", "code", "amount", "raw_amount", "provider_id", "metadata", "created_at", "updated_at", "deleted_at", "item_id", "is_tax_inclusive") FROM stdin;
\.


--
-- Data for Name: cart_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_line_item_tax_line" ("id", "description", "tax_rate_id", "code", "rate", "provider_id", "metadata", "created_at", "updated_at", "deleted_at", "item_id") FROM stdin;
\.


--
-- Data for Name: cart_payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_payment_collection" ("cart_id", "payment_collection_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
cart_01KPVFBRERNG8Q0RM3RRR1FDS3	pay_col_01KPWECVGHJW90KXQ708NJQRS2	capaycol_01KPWECVGYW86DBAN4TB8B1K0Q	2026-04-23 07:53:22.461612+02	2026-04-23 07:53:22.461612+02	\N
\.


--
-- Data for Name: cart_promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_promotion" ("cart_id", "promotion_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: cart_shipping_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_shipping_method" ("id", "cart_id", "name", "description", "amount", "raw_amount", "is_tax_inclusive", "shipping_option_id", "data", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
casm_01KPWECTYXBKEC32BDFAYHM36B	cart_01KPVFBRERNG8Q0RM3RRR1FDS3	Standard Shipping	\N	10	{"value": "10", "precision": 20}	f	so_01KPVEFM8VS58X5XS6Z6PA0X3S	{}	\N	2026-04-23 07:53:21.886+02	2026-04-23 07:53:21.886+02	\N
\.


--
-- Data for Name: cart_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_shipping_method_adjustment" ("id", "description", "promotion_id", "code", "amount", "raw_amount", "provider_id", "metadata", "created_at", "updated_at", "deleted_at", "shipping_method_id") FROM stdin;
\.


--
-- Data for Name: cart_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cart_shipping_method_tax_line" ("id", "description", "tax_rate_id", "code", "rate", "provider_id", "metadata", "created_at", "updated_at", "deleted_at", "shipping_method_id") FROM stdin;
\.


--
-- Data for Name: credit_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."credit_line" ("id", "cart_id", "reference", "reference_id", "amount", "raw_amount", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."currency" ("code", "symbol", "symbol_native", "decimal_digits", "rounding", "raw_rounding", "name", "created_at", "updated_at", "deleted_at") FROM stdin;
usd	$	$	2	0	{"value": "0", "precision": 20}	US Dollar	2026-04-22 22:35:26.274+02	2026-04-22 22:35:26.274+02	\N
cad	CA$	$	2	0	{"value": "0", "precision": 20}	Canadian Dollar	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
eur	€	€	2	0	{"value": "0", "precision": 20}	Euro	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
aed	AED	د.إ.‏	2	0	{"value": "0", "precision": 20}	United Arab Emirates Dirham	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
afn	Af	؋	0	0	{"value": "0", "precision": 20}	Afghan Afghani	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
all	ALL	Lek	0	0	{"value": "0", "precision": 20}	Albanian Lek	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
amd	AMD	դր.	0	0	{"value": "0", "precision": 20}	Armenian Dram	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
ars	AR$	$	2	0	{"value": "0", "precision": 20}	Argentine Peso	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
aud	AU$	$	2	0	{"value": "0", "precision": 20}	Australian Dollar	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
azn	man.	ман.	2	0	{"value": "0", "precision": 20}	Azerbaijani Manat	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
bam	KM	KM	2	0	{"value": "0", "precision": 20}	Bosnia-Herzegovina Convertible Mark	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
bdt	Tk	৳	2	0	{"value": "0", "precision": 20}	Bangladeshi Taka	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
bgn	BGN	лв.	2	0	{"value": "0", "precision": 20}	Bulgarian Lev	2026-04-22 22:35:26.276+02	2026-04-22 22:35:26.276+02	\N
bhd	BD	د.ب.‏	3	0	{"value": "0", "precision": 20}	Bahraini Dinar	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
bif	FBu	FBu	0	0	{"value": "0", "precision": 20}	Burundian Franc	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
bnd	BN$	$	2	0	{"value": "0", "precision": 20}	Brunei Dollar	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
bob	Bs	Bs	2	0	{"value": "0", "precision": 20}	Bolivian Boliviano	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
brl	R$	R$	2	0	{"value": "0", "precision": 20}	Brazilian Real	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
bwp	BWP	P	2	0	{"value": "0", "precision": 20}	Botswanan Pula	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
byn	Br	руб.	2	0	{"value": "0", "precision": 20}	Belarusian Ruble	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
bzd	BZ$	$	2	0	{"value": "0", "precision": 20}	Belize Dollar	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
cdf	CDF	FrCD	2	0	{"value": "0", "precision": 20}	Congolese Franc	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
chf	CHF	CHF	2	0.05	{"value": "0.05", "precision": 20}	Swiss Franc	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
clp	CL$	$	0	0	{"value": "0", "precision": 20}	Chilean Peso	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
cny	CN¥	CN¥	2	0	{"value": "0", "precision": 20}	Chinese Yuan	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
cop	CO$	$	0	0	{"value": "0", "precision": 20}	Colombian Peso	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
crc	₡	₡	0	0	{"value": "0", "precision": 20}	Costa Rican Colón	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
cve	CV$	CV$	2	0	{"value": "0", "precision": 20}	Cape Verdean Escudo	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
czk	Kč	Kč	2	0	{"value": "0", "precision": 20}	Czech Republic Koruna	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
djf	Fdj	Fdj	0	0	{"value": "0", "precision": 20}	Djiboutian Franc	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
dkk	Dkr	kr	2	0	{"value": "0", "precision": 20}	Danish Krone	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.277+02	\N
dop	RD$	RD$	2	0	{"value": "0", "precision": 20}	Dominican Peso	2026-04-22 22:35:26.277+02	2026-04-22 22:35:26.278+02	\N
dzd	DA	د.ج.‏	2	0	{"value": "0", "precision": 20}	Algerian Dinar	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
eek	Ekr	kr	2	0	{"value": "0", "precision": 20}	Estonian Kroon	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
egp	EGP	ج.م.‏	2	0	{"value": "0", "precision": 20}	Egyptian Pound	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
ern	Nfk	Nfk	2	0	{"value": "0", "precision": 20}	Eritrean Nakfa	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
etb	Br	Br	2	0	{"value": "0", "precision": 20}	Ethiopian Birr	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
gbp	£	£	2	0	{"value": "0", "precision": 20}	British Pound Sterling	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
gel	GEL	GEL	2	0	{"value": "0", "precision": 20}	Georgian Lari	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
ghs	GH₵	GH₵	2	0	{"value": "0", "precision": 20}	Ghanaian Cedi	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
gnf	FG	FG	0	0	{"value": "0", "precision": 20}	Guinean Franc	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
gtq	GTQ	Q	2	0	{"value": "0", "precision": 20}	Guatemalan Quetzal	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
hkd	HK$	$	2	0	{"value": "0", "precision": 20}	Hong Kong Dollar	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
hnl	HNL	L	2	0	{"value": "0", "precision": 20}	Honduran Lempira	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
hrk	kn	kn	2	0	{"value": "0", "precision": 20}	Croatian Kuna	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
huf	Ft	Ft	0	0	{"value": "0", "precision": 20}	Hungarian Forint	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
idr	Rp	Rp	0	0	{"value": "0", "precision": 20}	Indonesian Rupiah	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
ils	₪	₪	2	0	{"value": "0", "precision": 20}	Israeli New Sheqel	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
inr	Rs	₹	2	0	{"value": "0", "precision": 20}	Indian Rupee	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
iqd	IQD	د.ع.‏	0	0	{"value": "0", "precision": 20}	Iraqi Dinar	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
irr	IRR	﷼	0	0	{"value": "0", "precision": 20}	Iranian Rial	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
isk	Ikr	kr	0	0	{"value": "0", "precision": 20}	Icelandic Króna	2026-04-22 22:35:26.278+02	2026-04-22 22:35:26.278+02	\N
jmd	J$	$	2	0	{"value": "0", "precision": 20}	Jamaican Dollar	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
jod	JD	د.أ.‏	3	0	{"value": "0", "precision": 20}	Jordanian Dinar	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
jpy	¥	￥	0	0	{"value": "0", "precision": 20}	Japanese Yen	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
kes	Ksh	Ksh	2	0	{"value": "0", "precision": 20}	Kenyan Shilling	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
khr	KHR	៛	2	0	{"value": "0", "precision": 20}	Cambodian Riel	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
kmf	CF	FC	0	0	{"value": "0", "precision": 20}	Comorian Franc	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
krw	₩	₩	0	0	{"value": "0", "precision": 20}	South Korean Won	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
kwd	KD	د.ك.‏	3	0	{"value": "0", "precision": 20}	Kuwaiti Dinar	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
kzt	KZT	тңг.	2	0	{"value": "0", "precision": 20}	Kazakhstani Tenge	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
lbp	LB£	ل.ل.‏	0	0	{"value": "0", "precision": 20}	Lebanese Pound	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
lkr	SLRs	SL Re	2	0	{"value": "0", "precision": 20}	Sri Lankan Rupee	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
ltl	Lt	Lt	2	0	{"value": "0", "precision": 20}	Lithuanian Litas	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
lvl	Ls	Ls	2	0	{"value": "0", "precision": 20}	Latvian Lats	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
lyd	LD	د.ل.‏	3	0	{"value": "0", "precision": 20}	Libyan Dinar	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mad	MAD	د.م.‏	2	0	{"value": "0", "precision": 20}	Moroccan Dirham	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mdl	MDL	MDL	2	0	{"value": "0", "precision": 20}	Moldovan Leu	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mga	MGA	MGA	0	0	{"value": "0", "precision": 20}	Malagasy Ariary	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mkd	MKD	MKD	2	0	{"value": "0", "precision": 20}	Macedonian Denar	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mmk	MMK	K	0	0	{"value": "0", "precision": 20}	Myanma Kyat	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mnt	MNT	₮	0	0	{"value": "0", "precision": 20}	Mongolian Tugrig	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mop	MOP$	MOP$	2	0	{"value": "0", "precision": 20}	Macanese Pataca	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mur	MURs	MURs	0	0	{"value": "0", "precision": 20}	Mauritian Rupee	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mwk	K	K	2	0	{"value": "0", "precision": 20}	Malawian Kwacha	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mxn	MX$	$	2	0	{"value": "0", "precision": 20}	Mexican Peso	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
myr	RM	RM	2	0	{"value": "0", "precision": 20}	Malaysian Ringgit	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
mzn	MTn	MTn	2	0	{"value": "0", "precision": 20}	Mozambican Metical	2026-04-22 22:35:26.279+02	2026-04-22 22:35:26.279+02	\N
nad	N$	N$	2	0	{"value": "0", "precision": 20}	Namibian Dollar	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
ngn	₦	₦	2	0	{"value": "0", "precision": 20}	Nigerian Naira	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
nio	C$	C$	2	0	{"value": "0", "precision": 20}	Nicaraguan Córdoba	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
nok	Nkr	kr	2	0	{"value": "0", "precision": 20}	Norwegian Krone	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
npr	NPRs	नेरू	2	0	{"value": "0", "precision": 20}	Nepalese Rupee	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
nzd	NZ$	$	2	0	{"value": "0", "precision": 20}	New Zealand Dollar	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
omr	OMR	ر.ع.‏	3	0	{"value": "0", "precision": 20}	Omani Rial	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
pab	B/.	B/.	2	0	{"value": "0", "precision": 20}	Panamanian Balboa	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
pen	S/.	S/.	2	0	{"value": "0", "precision": 20}	Peruvian Nuevo Sol	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
php	₱	₱	2	0	{"value": "0", "precision": 20}	Philippine Peso	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
pkr	PKRs	₨	0	0	{"value": "0", "precision": 20}	Pakistani Rupee	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
pln	zł	zł	2	0	{"value": "0", "precision": 20}	Polish Zloty	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
pyg	₲	₲	0	0	{"value": "0", "precision": 20}	Paraguayan Guarani	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
qar	QR	ر.ق.‏	2	0	{"value": "0", "precision": 20}	Qatari Rial	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
ron	RON	RON	2	0	{"value": "0", "precision": 20}	Romanian Leu	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
rsd	din.	дин.	0	0	{"value": "0", "precision": 20}	Serbian Dinar	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
rub	RUB	₽.	2	0	{"value": "0", "precision": 20}	Russian Ruble	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
rwf	RWF	FR	0	0	{"value": "0", "precision": 20}	Rwandan Franc	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
sar	SR	ر.س.‏	2	0	{"value": "0", "precision": 20}	Saudi Riyal	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
sdg	SDG	SDG	2	0	{"value": "0", "precision": 20}	Sudanese Pound	2026-04-22 22:35:26.28+02	2026-04-22 22:35:26.28+02	\N
sek	Skr	kr	2	0	{"value": "0", "precision": 20}	Swedish Krona	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
sgd	S$	$	2	0	{"value": "0", "precision": 20}	Singapore Dollar	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
sos	Ssh	Ssh	0	0	{"value": "0", "precision": 20}	Somali Shilling	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
syp	SY£	ل.س.‏	0	0	{"value": "0", "precision": 20}	Syrian Pound	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
thb	฿	฿	2	0	{"value": "0", "precision": 20}	Thai Baht	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
tnd	DT	د.ت.‏	3	0	{"value": "0", "precision": 20}	Tunisian Dinar	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
top	T$	T$	2	0	{"value": "0", "precision": 20}	Tongan Paʻanga	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
tjs	TJS	с.	2	0	{"value": "0", "precision": 20}	Tajikistani Somoni	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
try	₺	₺	2	0	{"value": "0", "precision": 20}	Turkish Lira	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
ttd	TT$	$	2	0	{"value": "0", "precision": 20}	Trinidad and Tobago Dollar	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
twd	NT$	NT$	2	0	{"value": "0", "precision": 20}	New Taiwan Dollar	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
tzs	TSh	TSh	0	0	{"value": "0", "precision": 20}	Tanzanian Shilling	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
uah	₴	₴	2	0	{"value": "0", "precision": 20}	Ukrainian Hryvnia	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
ugx	USh	USh	0	0	{"value": "0", "precision": 20}	Ugandan Shilling	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
uyu	$U	$	2	0	{"value": "0", "precision": 20}	Uruguayan Peso	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
uzs	UZS	UZS	0	0	{"value": "0", "precision": 20}	Uzbekistan Som	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
vef	Bs.F.	Bs.F.	2	0	{"value": "0", "precision": 20}	Venezuelan Bolívar	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
vnd	₫	₫	0	0	{"value": "0", "precision": 20}	Vietnamese Dong	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
xaf	FCFA	FCFA	0	0	{"value": "0", "precision": 20}	CFA Franc BEAC	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
xof	CFA	CFA	0	0	{"value": "0", "precision": 20}	CFA Franc BCEAO	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
xpf	₣	₣	0	0	{"value": "0", "precision": 20}	CFP Franc	2026-04-22 22:35:26.281+02	2026-04-22 22:35:26.281+02	\N
yer	YR	ر.ي.‏	0	0	{"value": "0", "precision": 20}	Yemeni Rial	2026-04-22 22:35:26.282+02	2026-04-22 22:35:26.282+02	\N
zar	R	R	2	0	{"value": "0", "precision": 20}	South African Rand	2026-04-22 22:35:26.282+02	2026-04-22 22:35:26.282+02	\N
zmk	ZK	ZK	0	0	{"value": "0", "precision": 20}	Zambian Kwacha	2026-04-22 22:35:26.282+02	2026-04-22 22:35:26.282+02	\N
zwl	ZWL$	ZWL$	0	0	{"value": "0", "precision": 20}	Zimbabwean Dollar	2026-04-22 22:35:26.282+02	2026-04-22 22:35:26.282+02	\N
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."customer" ("id", "company_name", "first_name", "last_name", "email", "phone", "has_account", "metadata", "created_at", "updated_at", "deleted_at", "created_by") FROM stdin;
cus_01KPWECT9YXCHTFC2E10XC38M3	\N	\N	\N	abc@test.com	\N	f	\N	2026-04-23 07:53:21.215+02	2026-04-23 07:53:21.215+02	\N	\N
cus_01KPX6FXANAJHJBT1FK54HS3Y1	\N	Test	User	test1776948867237@example.com	\N	t	\N	2026-04-23 14:54:28.438+02	2026-04-23 14:54:28.438+02	\N	\N
cus_01KPX7HJW19P1TBYBHMRX6R6AR	\N	Test	User	test1776949970723@example.com	\N	t	\N	2026-04-23 15:12:51.842+02	2026-04-23 15:12:51.842+02	\N	\N
cus_01KPXNG2T90W2G9NDAN07TERT2	\N	ken	\N	ken@test.com	\N	t	\N	2026-04-23 19:16:42.698+02	2026-04-23 19:16:42.698+02	\N	\N
cus_01KPXP4TB3DK2DTWTYYPA27XBV	\N	E2E	Test	test1776965276602@example.com	\N	t	\N	2026-04-23 19:28:02.147+02	2026-04-23 19:28:02.147+02	\N	\N
cus_01KPXP6CB9JZHVQ2C3NWPFESB8	\N	E2E	Test	test1776965330252@example.com	\N	t	\N	2026-04-23 19:28:53.354+02	2026-04-23 19:28:53.354+02	\N	\N
cus_01KPXRKWT1F112T80S2VF76PN3	\N	E2E	Runner	e2e1776967842906@example.com	\N	t	\N	2026-04-23 20:11:13.346+02	2026-04-23 20:11:13.346+02	\N	\N
cus_01KPXTR4HTN1A5GNBKJSZK0Q6B	\N	E2E	Real	e2e1776970101950@example.com	\N	t	\N	2026-04-23 20:48:29.499+02	2026-04-23 20:48:29.499+02	\N	\N
cus_01KPZ9VF4PWG48MPEEW2819XHC	\N	Fate		fate6317@gmail.com	\N	t	\N	2026-04-24 10:31:41.719+02	2026-04-24 10:31:41.719+02	\N	\N
\.


--
-- Data for Name: customer_account_holder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."customer_account_holder" ("customer_id", "account_holder_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: customer_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."customer_address" ("id", "customer_id", "address_name", "is_default_shipping", "is_default_billing", "company", "first_name", "last_name", "address_1", "address_2", "city", "country_code", "province", "postal_code", "phone", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: customer_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."customer_group" ("id", "name", "metadata", "created_by", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: customer_group_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."customer_group_customer" ("id", "customer_id", "customer_group_id", "metadata", "created_at", "updated_at", "created_by", "deleted_at") FROM stdin;
\.


--
-- Data for Name: fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment" ("id", "location_id", "packed_at", "shipped_at", "delivered_at", "canceled_at", "data", "provider_id", "shipping_option_id", "metadata", "delivery_address_id", "created_at", "updated_at", "deleted_at", "marked_shipped_by", "created_by", "requires_shipping") FROM stdin;
\.


--
-- Data for Name: fulfillment_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment_address" ("id", "company", "first_name", "last_name", "address_1", "address_2", "city", "country_code", "province", "postal_code", "phone", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: fulfillment_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment_item" ("id", "title", "sku", "barcode", "quantity", "raw_quantity", "line_item_id", "inventory_item_id", "fulfillment_id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: fulfillment_label; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment_label" ("id", "tracking_number", "tracking_url", "label_url", "fulfillment_id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment_provider" ("id", "is_enabled", "created_at", "updated_at", "deleted_at") FROM stdin;
manual_manual	t	2026-04-22 22:35:26.311+02	2026-04-22 22:35:26.311+02	\N
\.


--
-- Data for Name: fulfillment_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."fulfillment_set" ("id", "name", "type", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
fuset_01KPVEFM5MNMDSQ40ZRWHV0C3G	European Warehouse delivery	shipping	\N	2026-04-22 22:35:38.805+02	2026-04-22 22:35:38.805+02	\N
\.


--
-- Data for Name: geo_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."geo_zone" ("id", "type", "country_code", "province_code", "city", "service_zone_id", "postal_expression", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
fgz_01KPZA60BWH7R6A5CVX6SPMT22	country	my	\N	\N	serzo_01KPZA60BXGBWBP6ESN93YCCRF	\N	\N	2026-04-24 10:37:27.037+02	2026-04-24 10:37:27.037+02	\N
fgz_01KPVEFM5KCYN8SYMP9B1JVS0C	country	gb	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.805+02	2026-04-24 15:31:36.055+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5KQBKXFF5M8H08582N	country	de	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.055+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5MWFS621BE4ARCDJXD	country	dk	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5MR9TXHJVQ6999DQJV	country	se	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5MV2RAW6BRZHHQEQF4	country	fr	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5MJY7BNW2PW671FB9N	country	es	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
fgz_01KPVEFM5MBGGA87A0HWH3FY7B	country	it	\N	\N	serzo_01KPVEFM5MC5CT712T6KM95QZ9	\N	\N	2026-04-22 22:35:38.806+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."image" ("id", "url", "metadata", "created_at", "updated_at", "deleted_at", "rank", "product_id") FROM stdin;
img_01KPVEFMEQ2J7YVYP6CM88D0CW	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9
img_01KPVEFMEQ5YVK1DY067SG1NQB	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-back.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	1	prod_01KPVEFMEHWRKFH07N2Q5W9PF9
img_01KPVEFMERP75V3C4BGADHY2VK	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-white-front.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	2	prod_01KPVEFMEHWRKFH07N2Q5W9PF9
img_01KPVEFMERS5BMVCY7PXBBVG2M	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-white-back.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	3	prod_01KPVEFMEHWRKFH07N2Q5W9PF9
img_01KPVEFMETRWWYSKWPNCATN334	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-front.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	0	prod_01KPVEFMEJ4N6R7MXZREAQHD71
img_01KPVEFMETP5XQGTA0YTFXWB49	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-back.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	1	prod_01KPVEFMEJ4N6R7MXZREAQHD71
img_01KPVEFMEV71VZ50904Q5CFBE8	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-front.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	0	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW
img_01KPVEFMEVAMVZ7PD057VD5N9J	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-back.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	1	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW
img_01KPVEFMEXNPBK5CAXEZ175MNH	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N	0	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP
img_01KPVEFMEXRNYE31MRNSEF2284	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-back.png	\N	2026-04-22 22:35:39.105+02	2026-04-22 22:35:39.105+02	\N	1	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP
img_01KPXRBR78BMZWM3T9GSYX8G65	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-white-front.png	\N	2026-04-23 20:06:46.507+02	2026-04-23 20:06:46.507+02	\N	0	prod_01KPXRBR70C8XC3EDBSQGV2ZQX
img_01KPXRBRHFB9ZQPFK5TZP2HMPB	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	\N	2026-04-23 20:06:46.834+02	2026-04-23 20:06:46.834+02	\N	0	prod_01KPXRBRHECSVT8SMF2Q4JW4FK
img_01KPXRBRRQQN3CVQWY3K2DRJP3	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-front.png	\N	2026-04-23 20:06:47.064+02	2026-04-23 20:06:47.064+02	\N	0	prod_01KPXRBRRK9B6E3N6RP56QPRQK
img_01KPXRBRYX3P7PWVHXXJTAVE13	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-front.png	\N	2026-04-23 20:06:47.261+02	2026-04-23 20:06:47.261+02	\N	0	prod_01KPXRBRYWCZVEY55DAKQVHF0Z
img_01KPXRBS8JM8PV37ASJSPX6R2Z	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	\N	2026-04-23 20:06:47.571+02	2026-04-23 20:06:47.571+02	\N	0	prod_01KPXRBS8GKPXRGEK4S01NZ7CQ
img_01KPXRBSEQYMNK712HJ13WSW12	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	\N	2026-04-23 20:06:47.767+02	2026-04-23 20:06:47.767+02	\N	0	prod_01KPXRBSEPKM19XQMQ37YETB3Q
\.


--
-- Data for Name: inventory_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."inventory_item" ("id", "created_at", "updated_at", "deleted_at", "sku", "origin_country", "hs_code", "mid_code", "material", "weight", "length", "height", "width", "requires_shipping", "description", "title", "thumbnail", "metadata") FROM stdin;
iitem_01KPVEFMKN698MJE0HPEGDEECQ	2026-04-22 22:35:39.257+02	2026-04-22 22:35:39.257+02	\N	SHIRT-S-BLACK	\N	\N	\N	\N	\N	\N	\N	\N	t	S / Black	S / Black	\N	\N
iitem_01KPVEFMKN4RKQE3P33YHPEQS3	2026-04-22 22:35:39.258+02	2026-04-22 22:35:39.258+02	\N	SHIRT-S-WHITE	\N	\N	\N	\N	\N	\N	\N	\N	t	S / White	S / White	\N	\N
iitem_01KPVEFMKPAZEYXJDKZHAPD0CS	2026-04-22 22:35:39.258+02	2026-04-22 22:35:39.258+02	\N	SHIRT-M-BLACK	\N	\N	\N	\N	\N	\N	\N	\N	t	M / Black	M / Black	\N	\N
iitem_01KPVEFMKP6MZZ3YWE0GETDDAR	2026-04-22 22:35:39.258+02	2026-04-22 22:35:39.258+02	\N	SHIRT-M-WHITE	\N	\N	\N	\N	\N	\N	\N	\N	t	M / White	M / White	\N	\N
iitem_01KPVEFMKP80HC4FERJKDERW35	2026-04-22 22:35:39.258+02	2026-04-22 22:35:39.258+02	\N	SHIRT-L-BLACK	\N	\N	\N	\N	\N	\N	\N	\N	t	L / Black	L / Black	\N	\N
iitem_01KPVEFMKPG5ZXJ3Q6WBCB06TR	2026-04-22 22:35:39.258+02	2026-04-22 22:35:39.258+02	\N	SHIRT-L-WHITE	\N	\N	\N	\N	\N	\N	\N	\N	t	L / White	L / White	\N	\N
iitem_01KPVEFMKPFXCDVT1PAM6D2BAN	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHIRT-XL-BLACK	\N	\N	\N	\N	\N	\N	\N	\N	t	XL / Black	XL / Black	\N	\N
iitem_01KPVEFMKPANETGHXVGRA19SZ6	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHIRT-XL-WHITE	\N	\N	\N	\N	\N	\N	\N	\N	t	XL / White	XL / White	\N	\N
iitem_01KPVEFMKQH0CYM8BVQDH1RNGD	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATSHIRT-S	\N	\N	\N	\N	\N	\N	\N	\N	t	S	S	\N	\N
iitem_01KPVEFMKQPY3M6D7PEDGMEVE1	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATSHIRT-M	\N	\N	\N	\N	\N	\N	\N	\N	t	M	M	\N	\N
iitem_01KPVEFMKQCTZSX3G3EVJ5ANMC	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATSHIRT-L	\N	\N	\N	\N	\N	\N	\N	\N	t	L	L	\N	\N
iitem_01KPVEFMKRWBWNVE1H4FC2SFTS	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATSHIRT-XL	\N	\N	\N	\N	\N	\N	\N	\N	t	XL	XL	\N	\N
iitem_01KPVEFMKR02X4TXEXW601KVC3	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATPANTS-S	\N	\N	\N	\N	\N	\N	\N	\N	t	S	S	\N	\N
iitem_01KPVEFMKR75ZHS7GX9JQH3MQS	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATPANTS-M	\N	\N	\N	\N	\N	\N	\N	\N	t	M	M	\N	\N
iitem_01KPVEFMKR6BS8EWFF6B8VMPXT	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATPANTS-L	\N	\N	\N	\N	\N	\N	\N	\N	t	L	L	\N	\N
iitem_01KPVEFMKSF5V6C31RX26MEX9T	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SWEATPANTS-XL	\N	\N	\N	\N	\N	\N	\N	\N	t	XL	XL	\N	\N
iitem_01KPVEFMKS1JRH9JS7QJZ0D5M7	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHORTS-S	\N	\N	\N	\N	\N	\N	\N	\N	t	S	S	\N	\N
iitem_01KPVEFMKS3AAFP71BFK77RDS1	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHORTS-M	\N	\N	\N	\N	\N	\N	\N	\N	t	M	M	\N	\N
iitem_01KPVEFMKS3XS0V9HWQS8R8GE7	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHORTS-L	\N	\N	\N	\N	\N	\N	\N	\N	t	L	L	\N	\N
iitem_01KPVEFMKS0695AGEZHASTP9HV	2026-04-22 22:35:39.259+02	2026-04-22 22:35:39.259+02	\N	SHORTS-XL	\N	\N	\N	\N	\N	\N	\N	\N	t	XL	XL	\N	\N
\.


--
-- Data for Name: inventory_level; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."inventory_level" ("id", "created_at", "updated_at", "deleted_at", "inventory_item_id", "location_id", "stocked_quantity", "reserved_quantity", "incoming_quantity", "metadata", "raw_stocked_quantity", "raw_reserved_quantity", "raw_incoming_quantity") FROM stdin;
ilev_01KPVEFMTBCWE72AXKR548EHEE	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKN4RKQE3P33YHPEQS3	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCX300BR3AVKWXSQV0	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKN698MJE0HPEGDEECQ	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCB4PZWRF8A1DDVMV5	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKP6MZZ3YWE0GETDDAR	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCGW9MH624S0RRCYBF	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKP80HC4FERJKDERW35	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCY103BHHMR2PVKWWJ	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKPANETGHXVGRA19SZ6	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCMF8KXA6D1QEB01ZW	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKPFXCDVT1PAM6D2BAN	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTDCA1HVPM97MFAZSMR	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKPG5ZXJ3Q6WBCB06TR	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTDG413422MYJXM6FY7	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKQCTZSX3G3EVJ5ANMC	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTDKP4T6H525XVFHNX3	2026-04-22 22:35:39.471+02	2026-04-22 22:35:39.471+02	\N	iitem_01KPVEFMKQH0CYM8BVQDH1RNGD	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTD1AKPGQ7C8N767B4P	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKQPY3M6D7PEDGMEVE1	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTDM7S66PRBQAZNJWK7	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKR02X4TXEXW601KVC3	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTDVBFH7WYW0P207KAF	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKR6BS8EWFF6B8VMPXT	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTEQMZY198VJT3M1B6N	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKR75ZHS7GX9JQH3MQS	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTEGGMGJ98RSR8GCNCY	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKRWBWNVE1H4FC2SFTS	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTEA8BHNDEBE73345GH	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKS0695AGEZHASTP9HV	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTE569YWEWX9RP8DR97	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKS1JRH9JS7QJZ0D5M7	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTEFSGJYR5MB29R4S8W	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKS3AAFP71BFK77RDS1	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTETNKBBMBB9RWASSBY	2026-04-22 22:35:39.472+02	2026-04-22 22:35:39.472+02	\N	iitem_01KPVEFMKSF5V6C31RX26MEX9T	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTCH4KAJKDM9EK7XNYE	2026-04-22 22:35:39.471+02	2026-04-24 15:38:37.745+02	\N	iitem_01KPVEFMKPAZEYXJDKZHAPD0CS	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KPVEFMTESVZDDV90NRCHR1N9	2026-04-22 22:35:39.472+02	2026-04-24 15:38:37.745+02	\N	iitem_01KPVEFMKS3XS0V9HWQS8R8GE7	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1000000	0	0	\N	{"value": "1000000", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
\.


--
-- Data for Name: invite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."invite" ("id", "email", "accepted", "token", "expires_at", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
invite_01KPVEFEYQVBBWRQVCHC2C59RN	admin@medusa-test.com	f	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Imludml0ZV8wMUtQVkVGRVlRVkJCV1JRVkNIQzJDNTlSTiIsImVtYWlsIjoiYWRtaW5AbWVkdXNhLXRlc3QuY29tIiwiaWF0IjoxNzc2ODkwMTMzLCJleHAiOjE3NzY5NzY1MzMsImp0aSI6IjNmZjFjZjY2LTJlNzUtNDI4YS04ODkxLTAzNTdlYmRjZmIwZiJ9.3XsShqk2W_RVp4NqM76F9mxnRIbk4H86KwH2mKzP5Z8	2026-04-23 22:35:33.463+02	\N	2026-04-22 22:35:33.467+02	2026-04-22 22:35:33.467+02	\N
\.


--
-- Data for Name: invite_rbac_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."invite_rbac_role" ("invite_id", "rbac_role_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: link_module_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."link_module_migrations" ("id", "table_name", "link_descriptor", "created_at") FROM stdin;
1	cart_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "cart", "fromModule": "cart"}	2026-04-22 22:35:22.327738
2	cart_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "cart", "fromModule": "cart"}	2026-04-22 22:35:22.378596
3	customer_account_holder	{"toModel": "account_holder", "toModule": "payment", "fromModel": "customer", "fromModule": "customer"}	2026-04-22 22:35:22.422923
4	location_fulfillment_provider	{"toModel": "fulfillment_provider", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2026-04-22 22:35:22.462298
5	location_fulfillment_set	{"toModel": "fulfillment_set", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2026-04-22 22:35:22.487333
6	invite_rbac_role	{"toModel": "rbac_role", "toModule": "rbac", "fromModel": "invite", "fromModule": "user"}	2026-04-22 22:35:22.529624
7	order_cart	{"toModel": "cart", "toModule": "cart", "fromModel": "order", "fromModule": "order"}	2026-04-22 22:35:22.54471
8	order_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "order", "fromModule": "order"}	2026-04-22 22:35:22.557811
9	order_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "order", "fromModule": "order"}	2026-04-22 22:35:22.572173
10	order_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "order", "fromModule": "order"}	2026-04-22 22:35:22.58984
11	return_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "return", "fromModule": "order"}	2026-04-22 22:35:22.607049
12	product_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "product", "fromModule": "product"}	2026-04-22 22:35:22.61709
13	product_shipping_profile	{"toModel": "shipping_profile", "toModule": "fulfillment", "fromModel": "product", "fromModule": "product"}	2026-04-22 22:35:22.626378
14	product_variant_inventory_item	{"toModel": "inventory", "toModule": "inventory", "fromModel": "variant", "fromModule": "product"}	2026-04-22 22:35:22.63794
15	product_variant_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "variant", "fromModule": "product"}	2026-04-22 22:35:22.650162
16	publishable_api_key_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "api_key", "fromModule": "api_key"}	2026-04-22 22:35:22.663326
17	region_payment_provider	{"toModel": "payment_provider", "toModule": "payment", "fromModel": "region", "fromModule": "region"}	2026-04-22 22:35:22.679265
18	sales_channel_stock_location	{"toModel": "location", "toModule": "stock_location", "fromModel": "sales_channel", "fromModule": "sales_channel"}	2026-04-22 22:35:22.702165
19	shipping_option_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "shipping_option", "fromModule": "fulfillment"}	2026-04-22 22:35:22.713793
20	user_rbac_role	{"toModel": "rbac_role", "toModule": "rbac", "fromModel": "user", "fromModule": "user"}	2026-04-22 22:35:22.725331
\.


--
-- Data for Name: location_fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."location_fulfillment_provider" ("stock_location_id", "fulfillment_provider_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	manual_manual	locfp_01KPVEFM51R30611ZRK69FK82D	2026-04-22 22:35:38.785405+02	2026-04-22 22:35:38.785405+02	\N
\.


--
-- Data for Name: location_fulfillment_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."location_fulfillment_set" ("stock_location_id", "fulfillment_set_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	fuset_01KPVEFM5MNMDSQ40ZRWHV0C3G	locfs_01KPVEFM6VJFHSPGE6YYD7ZJ29	2026-04-22 22:35:38.843178+02	2026-04-22 22:35:38.843178+02	\N
\.


--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."menu_item" ("id", "menu_key", "parent_id", "label", "href", "position", "is_active", "created_at", "updated_at", "deleted_at") FROM stdin;
01KQ1H228PHTC0VQNYYP4D0HHF	header	\N	Occasions	/category/occasions	0	t	2026-04-25 07:16:06.806+02	2026-04-25 07:16:06.806+02	\N
01KQ1H229AJJYGFQMD552NNRFJ	header	01KQ1H228PHTC0VQNYYP4D0HHF	Birthday	/category/birthday	0	t	2026-04-25 07:16:06.827+02	2026-04-25 07:16:06.827+02	\N
01KQ1H229X38W02XBE1T04KN2K	header	01KQ1H228PHTC0VQNYYP4D0HHF	Surprise	/category/surprise	1	t	2026-04-25 07:16:06.845+02	2026-04-25 07:16:06.845+02	\N
01KQ1H22AA1WFE0V8537TBH1D8	header	01KQ1H228PHTC0VQNYYP4D0HHF	Business Opening	/category/business-opening	2	t	2026-04-25 07:16:06.859+02	2026-04-25 07:16:06.859+02	\N
01KQ1H22AXZMDGMGJDM4985XZT	header	01KQ1H228PHTC0VQNYYP4D0HHF	Wedding	/category/wedding	3	t	2026-04-25 07:16:06.877+02	2026-04-25 07:16:06.877+02	\N
01KQ1H22BERM1AGEWPG3K1TRV8	header	01KQ1H228PHTC0VQNYYP4D0HHF	Marriage Proposal	/category/marriage-proposal	4	t	2026-04-25 07:16:06.894+02	2026-04-25 07:16:06.894+02	\N
01KQ1H22C4N86PW4XAFM56MPQJ	header	01KQ1H228PHTC0VQNYYP4D0HHF	Graduation	/category/graduation	5	t	2026-04-25 07:16:06.917+02	2026-04-25 07:16:06.917+02	\N
01KQ1H22CSAKKGE12105B46DNS	header	01KQ1H228PHTC0VQNYYP4D0HHF	Condolences	/category/condolences	6	t	2026-04-25 07:16:06.937+02	2026-04-25 07:16:06.937+02	\N
01KQ1H22D6E069YNRSPAWZV5MY	header	01KQ1H228PHTC0VQNYYP4D0HHF	Apology	/category/apology	7	t	2026-04-25 07:16:06.95+02	2026-04-25 07:16:06.95+02	\N
01KQ1H22DM1ATMD2MHQG0T1528	header	\N	Flowers	/category/flowers	1	t	2026-04-25 07:16:06.965+02	2026-04-25 07:16:06.965+02	\N
01KQ1H22E3NXEV8RZDT6MEB98B	header	01KQ1H22DM1ATMD2MHQG0T1528	Hand Flower Bouquet	/category/hand-flower-bouquet	0	t	2026-04-25 07:16:06.98+02	2026-04-25 07:16:06.98+02	\N
01KQ1H22EGDG298J8RK5E28DJH	header	01KQ1H22DM1ATMD2MHQG0T1528	Flower Box	/category/flower-box	1	t	2026-04-25 07:16:06.992+02	2026-04-25 07:16:06.992+02	\N
01KQ1H22F1H8Y2M445QXNRGAQ4	header	01KQ1H22DM1ATMD2MHQG0T1528	Baby Breath Series	/category/baby-breath-series	2	t	2026-04-25 07:16:07.009+02	2026-04-25 07:16:07.009+02	\N
01KQ1H22FN6PKJS5PE91HN5GHA	header	01KQ1H22DM1ATMD2MHQG0T1528	Preserved Flower	/category/preserved-flower	3	t	2026-04-25 07:16:07.03+02	2026-04-25 07:16:07.03+02	\N
01KQ1H22G38QVFS5TBT9V4FQEJ	header	01KQ1H22DM1ATMD2MHQG0T1528	Opening Stand	/category/opening-stand	4	t	2026-04-25 07:16:07.043+02	2026-04-25 07:16:07.043+02	\N
01KQ1H22GM6DBHFC8FWG80CX00	header	01KQ1H22DM1ATMD2MHQG0T1528	Funeral	/category/funeral	5	t	2026-04-25 07:16:07.06+02	2026-04-25 07:16:07.06+02	\N
01KQ1H22H211C5C0J7NX19X1GF	header	01KQ1H22DM1ATMD2MHQG0T1528	Money Bouquet	/category/money-bouquet	6	t	2026-04-25 07:16:07.074+02	2026-04-25 07:16:07.074+02	\N
01KQ1H22HGBACN1JFAS2N7Y8SN	header	01KQ1H22DM1ATMD2MHQG0T1528	Soap Flower Bouquet	/category/soap-flower-bouquet	7	t	2026-04-25 07:16:07.088+02	2026-04-25 07:16:07.088+02	\N
01KQ1H22HXMSJSMZ1FMCBF9783	header	\N	Season	/category/season	2	t	2026-04-25 07:16:07.101+02	2026-04-25 07:16:07.101+02	\N
01KQ1H22JA7DCZBFKAH268MTRN	header	01KQ1H22HXMSJSMZ1FMCBF9783	Valentine 520 Special	/category/valentine	0	t	2026-04-25 07:16:07.115+02	2026-04-25 07:16:07.115+02	\N
01KQ1H22JX0Z447CT7RNHD424K	header	01KQ1H22HXMSJSMZ1FMCBF9783	Mother's Day Special	/category/mother-day	1	t	2026-04-25 07:16:07.133+02	2026-04-25 07:16:07.133+02	\N
01KQ1H22K61C4YX6P0M196GD3X	header	01KQ1H22HXMSJSMZ1FMCBF9783	Father's Day Special	/category/father-day	2	t	2026-04-25 07:16:07.143+02	2026-04-25 07:16:07.143+02	\N
01KQ1H22KKFW74F8XWDAQK9615	header	01KQ1H22HXMSJSMZ1FMCBF9783	Graduation Season	/category/graduation-season	3	t	2026-04-25 07:16:07.156+02	2026-04-25 07:16:07.156+02	\N
01KQ1H22M0GTQD15YVEY81GJ55	header	01KQ1H22HXMSJSMZ1FMCBF9783	Christmas Special	/category/christmas	4	t	2026-04-25 07:16:07.168+02	2026-04-25 07:16:07.168+02	\N
01KQ1H22ME5WKR3KFH3GD7Y899	header	01KQ1H22HXMSJSMZ1FMCBF9783	Teacher's Day Special	/category/teachers-day	5	t	2026-04-25 07:16:07.183+02	2026-04-25 07:16:07.183+02	\N
01KQ1H22MWHQH9JMHPK6PA6DV4	header	01KQ1H22HXMSJSMZ1FMCBF9783	International Women's Day	/category/international-women-day	6	t	2026-04-25 07:16:07.197+02	2026-04-25 07:16:07.197+02	\N
01KQ1H22NBC2ACSQJRFKA8NTA8	header	\N	F&B	/category/fb	3	t	2026-04-25 07:16:07.211+02	2026-04-25 07:16:07.211+02	\N
01KQ1H22NTCVP0RWNDDVNA2AY9	header	01KQ1H22NBC2ACSQJRFKA8NTA8	Fruit Basket	/category/fruit-basket	0	t	2026-04-25 07:16:07.227+02	2026-04-25 07:16:07.227+02	\N
01KQ1H22P7X4V0MPCHJ7PENYH9	header	01KQ1H22NBC2ACSQJRFKA8NTA8	Hamper	/category/hamper	1	t	2026-04-25 07:16:07.24+02	2026-04-25 07:16:07.24+02	\N
01KQ1H22PQN74P1SVKPQAFN4Y0	header	01KQ1H22NBC2ACSQJRFKA8NTA8	Chocolate	/category/chocolate	2	t	2026-04-25 07:16:07.255+02	2026-04-25 07:16:07.255+02	\N
01KQ1H22Q5Q3BE150NDGSVCW62	header	01KQ1H22NBC2ACSQJRFKA8NTA8	Cake	/category/cake	3	t	2026-04-25 07:16:07.27+02	2026-04-25 07:16:07.27+02	\N
01KQ1H22QTPJ4N6TFF70HNTP0A	header	\N	Budget	/search	4	t	2026-04-25 07:16:07.291+02	2026-04-25 07:16:07.291+02	\N
01KQ1H22RA55B9DAZGXBYEDCK3	header	01KQ1H22QTPJ4N6TFF70HNTP0A	Under RM120	/search?price=0-120	0	t	2026-04-25 07:16:07.306+02	2026-04-25 07:16:07.306+02	\N
01KQ1H22RSAXGSDZZ8H8NCM1Z2	header	01KQ1H22QTPJ4N6TFF70HNTP0A	RM120 - RM220	/search?price=120-220	1	t	2026-04-25 07:16:07.322+02	2026-04-25 07:16:07.322+02	\N
01KQ1H22S6Y31BMHQX9QMZB225	header	01KQ1H22QTPJ4N6TFF70HNTP0A	RM220 - RM320	/search?price=220-320	2	t	2026-04-25 07:16:07.334+02	2026-04-25 07:16:07.334+02	\N
01KQ1H22SNFQN9VC4QRTGBV89F	header	01KQ1H22QTPJ4N6TFF70HNTP0A	RM320 & Above	/search?price=320-99999	3	t	2026-04-25 07:16:07.35+02	2026-04-25 07:16:07.35+02	\N
01KQ1H22T35156CE2BBD6PK0CK	header	\N	Gifts	/category/gifts	5	t	2026-04-25 07:16:07.363+02	2026-04-25 07:16:07.363+02	\N
01KQ1H22TKD4FX7QZ2XGCWD8PC	header	01KQ1H22T35156CE2BBD6PK0CK	Balloon	/category/balloon	0	t	2026-04-25 07:16:07.379+02	2026-04-25 07:16:07.379+02	\N
01KQ1H22V3Z37Q7MM5E0TS4SMW	header	\N	Contact	/contact-us	6	t	2026-04-25 07:16:07.396+02	2026-04-25 07:16:07.396+02	\N
01KQ1H22VK7WDN2Y7NTF2H52SH	header	01KQ1H22V3Z37Q7MM5E0TS4SMW	WhatsApp	https://api.whatsapp.com/send/?phone=601155508866	0	t	2026-04-25 07:16:07.411+02	2026-04-25 07:16:07.411+02	\N
01KQ1H22W4ZN4E3V93DVN75SR2	header	\N	Blogs	/blog	7	t	2026-04-25 07:16:07.428+02	2026-04-25 07:16:07.428+02	\N
\.


--
-- Data for Name: mikro_orm_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."mikro_orm_migrations" ("id", "name", "executed_at") FROM stdin;
1	Migration20240307161216	2026-04-22 22:35:12.42049+02
2	Migration20241210073813	2026-04-22 22:35:12.42049+02
3	Migration20250106142624	2026-04-22 22:35:12.42049+02
4	Migration20250120110820	2026-04-22 22:35:12.42049+02
5	Migration20240307132720	2026-04-22 22:35:12.702102+02
6	Migration20240719123015	2026-04-22 22:35:12.702102+02
7	Migration20241213063611	2026-04-22 22:35:12.702102+02
8	Migration20251010131115	2026-04-22 22:35:12.702102+02
9	InitialSetup20240401153642	2026-04-22 22:35:13.067772+02
10	Migration20240601111544	2026-04-22 22:35:13.067772+02
11	Migration202408271511	2026-04-22 22:35:13.067772+02
12	Migration20241122120331	2026-04-22 22:35:13.067772+02
13	Migration20241125090957	2026-04-22 22:35:13.067772+02
14	Migration20250411073236	2026-04-22 22:35:13.067772+02
15	Migration20250516081326	2026-04-22 22:35:13.067772+02
16	Migration20250910154539	2026-04-22 22:35:13.067772+02
17	Migration20250911092221	2026-04-22 22:35:13.067772+02
18	Migration20250929204438	2026-04-22 22:35:13.067772+02
19	Migration20251008132218	2026-04-22 22:35:13.067772+02
20	Migration20251011090511	2026-04-22 22:35:13.067772+02
21	Migration20230929122253	2026-04-22 22:35:13.946398+02
22	Migration20240322094407	2026-04-22 22:35:13.946398+02
23	Migration20240322113359	2026-04-22 22:35:13.946398+02
24	Migration20240322120125	2026-04-22 22:35:13.946398+02
25	Migration20240626133555	2026-04-22 22:35:13.946398+02
26	Migration20240704094505	2026-04-22 22:35:13.946398+02
27	Migration20241127114534	2026-04-22 22:35:13.946398+02
28	Migration20241127223829	2026-04-22 22:35:13.946398+02
29	Migration20241128055359	2026-04-22 22:35:13.946398+02
30	Migration20241212190401	2026-04-22 22:35:13.946398+02
31	Migration20250408145122	2026-04-22 22:35:13.946398+02
32	Migration20250409122219	2026-04-22 22:35:13.946398+02
33	Migration20251009110625	2026-04-22 22:35:13.946398+02
34	Migration20251112192723	2026-04-22 22:35:13.946398+02
35	Migration20240227120221	2026-04-22 22:35:14.722287+02
36	Migration20240617102917	2026-04-22 22:35:14.722287+02
37	Migration20240624153824	2026-04-22 22:35:14.722287+02
38	Migration20241211061114	2026-04-22 22:35:14.722287+02
39	Migration20250113094144	2026-04-22 22:35:14.722287+02
40	Migration20250120110700	2026-04-22 22:35:14.722287+02
41	Migration20250226130616	2026-04-22 22:35:14.722287+02
42	Migration20250508081510	2026-04-22 22:35:14.722287+02
43	Migration20250828075407	2026-04-22 22:35:14.722287+02
44	Migration20250909083125	2026-04-22 22:35:14.722287+02
45	Migration20250916120552	2026-04-22 22:35:14.722287+02
46	Migration20250917143818	2026-04-22 22:35:14.722287+02
47	Migration20250919122137	2026-04-22 22:35:14.722287+02
48	Migration20251006000000	2026-04-22 22:35:14.722287+02
49	Migration20251015113934	2026-04-22 22:35:14.722287+02
50	Migration20251107050148	2026-04-22 22:35:14.722287+02
51	Migration20240124154000	2026-04-22 22:35:15.442638+02
52	Migration20240524123112	2026-04-22 22:35:15.442638+02
53	Migration20240602110946	2026-04-22 22:35:15.442638+02
54	Migration20241211074630	2026-04-22 22:35:15.442638+02
55	Migration20251010130829	2026-04-22 22:35:15.442638+02
56	Migration20240115152146	2026-04-22 22:35:15.712888+02
57	Migration20240222170223	2026-04-22 22:35:15.89324+02
58	Migration20240831125857	2026-04-22 22:35:15.89324+02
59	Migration20241106085918	2026-04-22 22:35:15.89324+02
60	Migration20241205095237	2026-04-22 22:35:15.89324+02
61	Migration20241216183049	2026-04-22 22:35:15.89324+02
62	Migration20241218091938	2026-04-22 22:35:15.89324+02
63	Migration20250120115059	2026-04-22 22:35:15.89324+02
64	Migration20250212131240	2026-04-22 22:35:15.89324+02
65	Migration20250326151602	2026-04-22 22:35:15.89324+02
66	Migration20250508081553	2026-04-22 22:35:15.89324+02
67	Migration20251017153909	2026-04-22 22:35:15.89324+02
68	Migration20251208130704	2026-04-22 22:35:15.89324+02
69	Migration20240205173216	2026-04-22 22:35:16.351441+02
70	Migration20240624200006	2026-04-22 22:35:16.351441+02
71	Migration20250120110744	2026-04-22 22:35:16.351441+02
72	InitialSetup20240221144943	2026-04-22 22:35:16.590827+02
73	Migration20240604080145	2026-04-22 22:35:16.590827+02
74	Migration20241205122700	2026-04-22 22:35:16.590827+02
75	Migration20251015123842	2026-04-22 22:35:16.590827+02
76	InitialSetup20240227075933	2026-04-22 22:35:16.831244+02
77	Migration20240621145944	2026-04-22 22:35:16.831244+02
78	Migration20241206083313	2026-04-22 22:35:16.831244+02
79	Migration20251202184737	2026-04-22 22:35:16.831244+02
80	Migration20251212161429	2026-04-22 22:35:16.831244+02
81	Migration20240227090331	2026-04-22 22:35:17.110585+02
82	Migration20240710135844	2026-04-22 22:35:17.110585+02
83	Migration20240924114005	2026-04-22 22:35:17.110585+02
84	Migration20241212052837	2026-04-22 22:35:17.110585+02
85	InitialSetup20240228133303	2026-04-22 22:35:17.557564+02
86	Migration20240624082354	2026-04-22 22:35:17.557564+02
87	Migration20240225134525	2026-04-22 22:35:17.753702+02
88	Migration20240806072619	2026-04-22 22:35:17.753702+02
89	Migration20241211151053	2026-04-22 22:35:17.753702+02
90	Migration20250115160517	2026-04-22 22:35:17.753702+02
91	Migration20250120110552	2026-04-22 22:35:17.753702+02
92	Migration20250123122334	2026-04-22 22:35:17.753702+02
93	Migration20250206105639	2026-04-22 22:35:17.753702+02
94	Migration20250207132723	2026-04-22 22:35:17.753702+02
95	Migration20250625084134	2026-04-22 22:35:17.753702+02
96	Migration20250924135437	2026-04-22 22:35:17.753702+02
97	Migration20250929124701	2026-04-22 22:35:17.753702+02
98	Migration20240219102530	2026-04-22 22:35:18.203469+02
99	Migration20240604100512	2026-04-22 22:35:18.203469+02
100	Migration20240715102100	2026-04-22 22:35:18.203469+02
101	Migration20240715174100	2026-04-22 22:35:18.203469+02
102	Migration20240716081800	2026-04-22 22:35:18.203469+02
103	Migration20240801085921	2026-04-22 22:35:18.203469+02
104	Migration20240821164505	2026-04-22 22:35:18.203469+02
105	Migration20240821170920	2026-04-22 22:35:18.203469+02
106	Migration20240827133639	2026-04-22 22:35:18.203469+02
107	Migration20240902195921	2026-04-22 22:35:18.203469+02
108	Migration20240913092514	2026-04-22 22:35:18.203469+02
109	Migration20240930122627	2026-04-22 22:35:18.203469+02
110	Migration20241014142943	2026-04-22 22:35:18.203469+02
111	Migration20241106085223	2026-04-22 22:35:18.203469+02
112	Migration20241129124827	2026-04-22 22:35:18.203469+02
113	Migration20241217162224	2026-04-22 22:35:18.203469+02
114	Migration20250326151554	2026-04-22 22:35:18.203469+02
115	Migration20250522181137	2026-04-22 22:35:18.203469+02
116	Migration20250702095353	2026-04-22 22:35:18.203469+02
117	Migration20250704120229	2026-04-22 22:35:18.203469+02
118	Migration20250910130000	2026-04-22 22:35:18.203469+02
119	Migration20251016160403	2026-04-22 22:35:18.203469+02
120	Migration20251016182939	2026-04-22 22:35:18.203469+02
121	Migration20251017155709	2026-04-22 22:35:18.203469+02
122	Migration20251114100559	2026-04-22 22:35:18.203469+02
123	Migration20251125164002	2026-04-22 22:35:18.203469+02
124	Migration20251210112909	2026-04-22 22:35:18.203469+02
125	Migration20251210112924	2026-04-22 22:35:18.203469+02
126	Migration20251225120947	2026-04-22 22:35:18.203469+02
127	Migration20250717162007	2026-04-22 22:35:19.572094+02
128	Migration20240205025928	2026-04-22 22:35:19.805194+02
129	Migration20240529080336	2026-04-22 22:35:19.805194+02
130	Migration20241202100304	2026-04-22 22:35:19.805194+02
131	Migration20240214033943	2026-04-22 22:35:20.166691+02
132	Migration20240703095850	2026-04-22 22:35:20.166691+02
133	Migration20241202103352	2026-04-22 22:35:20.166691+02
134	Migration20240311145700_InitialSetupMigration	2026-04-22 22:35:20.45167+02
135	Migration20240821170957	2026-04-22 22:35:20.45167+02
136	Migration20240917161003	2026-04-22 22:35:20.45167+02
137	Migration20241217110416	2026-04-22 22:35:20.45167+02
138	Migration20250113122235	2026-04-22 22:35:20.45167+02
139	Migration20250120115002	2026-04-22 22:35:20.45167+02
140	Migration20250822130931	2026-04-22 22:35:20.45167+02
141	Migration20250825132614	2026-04-22 22:35:20.45167+02
142	Migration20251114133146	2026-04-22 22:35:20.45167+02
143	Migration20240509083918_InitialSetupMigration	2026-04-22 22:35:21.009321+02
144	Migration20240628075401	2026-04-22 22:35:21.009321+02
145	Migration20240830094712	2026-04-22 22:35:21.009321+02
146	Migration20250120110514	2026-04-22 22:35:21.009321+02
147	Migration20251028172715	2026-04-22 22:35:21.009321+02
148	Migration20251121123942	2026-04-22 22:35:21.009321+02
149	Migration20251121150408	2026-04-22 22:35:21.009321+02
150	Migration20231228143900	2026-04-22 22:35:21.478138+02
151	Migration20241206101446	2026-04-22 22:35:21.478138+02
152	Migration20250128174331	2026-04-22 22:35:21.478138+02
153	Migration20250505092459	2026-04-22 22:35:21.478138+02
154	Migration20250819104213	2026-04-22 22:35:21.478138+02
155	Migration20250819110924	2026-04-22 22:35:21.478138+02
156	Migration20250908080305	2026-04-22 22:35:21.478138+02
157	Migration20260423193701	2026-04-23 21:37:14.517288+02
158	Migration20260423223558	2026-04-24 00:36:08.548133+02
159	Migration20241206123341	2026-04-24 19:43:32.40677+02
160	Migration20250120111059	2026-04-24 19:43:32.40677+02
161	Migration20250128174354	2026-04-24 19:43:32.40677+02
162	Migration20250505101505	2026-04-24 19:43:32.40677+02
163	Migration20250819110923	2026-04-24 19:43:32.40677+02
164	Migration20250908080326	2026-04-24 19:43:32.40677+02
165	Migration20260424174303	2026-04-24 19:43:34.073648+02
166	Migration20260424174312	2026-04-24 19:43:34.814299+02
167	Migration20260425125644	2026-04-25 14:57:01.44189+02
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."notification" ("id", "to", "channel", "template", "data", "trigger_type", "resource_id", "resource_type", "receiver_id", "original_notification_id", "idempotency_key", "external_id", "provider_id", "created_at", "updated_at", "deleted_at", "status", "from", "provider_data") FROM stdin;
\.


--
-- Data for Name: notification_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."notification_provider" ("id", "handle", "name", "is_enabled", "channels", "created_at", "updated_at", "deleted_at") FROM stdin;
local	local	local	t	{feed}	2026-04-22 22:35:26.321+02	2026-04-22 22:35:26.321+02	\N
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order" ("id", "region_id", "display_id", "customer_id", "version", "sales_channel_id", "status", "is_draft_order", "email", "currency_code", "shipping_address_id", "billing_address_id", "no_notification", "metadata", "created_at", "updated_at", "deleted_at", "canceled_at", "custom_display_id", "locale") FROM stdin;
order_01KPWECVRHA1YDZSXFAMWKRNA0	reg_01KPVEFKYDPAKWC7499ZXE0DY9	1	cus_01KPWECT9YXCHTFC2E10XC38M3	2	sc_01KPVEFEV595D4YCDP15QR7DDX	canceled	f	abc@test.com	eur	ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD	ordaddr_01KPWECVR8F31RVWQS9T69F2MY	f	\N	2026-04-23 07:53:22.711+02	2026-04-24 15:38:38.228+02	\N	2026-04-24 15:38:38.225+02	\N	\N
\.


--
-- Data for Name: order_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_address" ("id", "customer_id", "company", "first_name", "last_name", "address_1", "address_2", "city", "country_code", "province", "postal_code", "phone", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
ordaddr_01KPWECVR8F31RVWQS9T69F2MY	\N	\N	Test	Test	Test		Kl	dk	Kl	56000		\N	2026-04-23 07:53:21.254+02	2026-04-23 07:53:21.254+02	\N
ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD	\N	\N	Test	Test	Test		Kl	dk	Kl	56000		\N	2026-04-23 07:53:21.255+02	2026-04-23 07:53:21.255+02	\N
\.


--
-- Data for Name: order_cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_cart" ("order_id", "cart_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
order_01KPWECVRHA1YDZSXFAMWKRNA0	cart_01KPVFBRERNG8Q0RM3RRR1FDS3	ordercart_01KPWECVWTMH4YAH3Z335AE2VE	2026-04-23 07:53:22.842236+02	2026-04-23 07:53:22.842236+02	\N
\.


--
-- Data for Name: order_change; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_change" ("id", "order_id", "version", "description", "status", "internal_note", "created_by", "requested_by", "requested_at", "confirmed_by", "confirmed_at", "declined_by", "declined_reason", "metadata", "declined_at", "canceled_by", "canceled_at", "created_at", "updated_at", "change_type", "deleted_at", "return_id", "claim_id", "exchange_id", "carry_over_promotions") FROM stdin;
ordch_01KPZVDFQFCF1DQKN2A4RTTAAF	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	\N	confirmed	\N	\N	\N	\N	\N	2026-04-24 15:38:38.047+02	\N	\N	\N	\N	\N	\N	2026-04-24 15:38:37.935+02	2026-04-24 15:38:38.117+02	credit_line	\N	\N	\N	\N	\N
\.


--
-- Data for Name: order_change_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_change_action" ("id", "order_id", "version", "ordering", "order_change_id", "reference", "reference_id", "action", "details", "amount", "raw_amount", "internal_note", "applied", "created_at", "updated_at", "deleted_at", "return_id", "claim_id", "exchange_id") FROM stdin;
ordchact_01KPZVDFS1W881KT0E3R8R2P56	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	1	ordch_01KPZVDFQFCF1DQKN2A4RTTAAF	payment_collection	pay_col_01KPWECVGHJW90KXQ708NJQRS2	CREDIT_LINE_ADD	{}	30	{"value": "30", "precision": 20}	\N	t	2026-04-24 15:38:37.991+02	2026-04-24 15:38:38.149+02	\N	\N	\N	\N
\.


--
-- Data for Name: order_claim; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_claim" ("id", "order_id", "return_id", "order_version", "display_id", "type", "no_notification", "refund_amount", "raw_refund_amount", "metadata", "created_at", "updated_at", "deleted_at", "canceled_at", "created_by") FROM stdin;
\.


--
-- Data for Name: order_claim_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_claim_item" ("id", "claim_id", "item_id", "is_additional_item", "reason", "quantity", "raw_quantity", "note", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_claim_item_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_claim_item_image" ("id", "claim_item_id", "url", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_credit_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_credit_line" ("id", "order_id", "reference", "reference_id", "amount", "raw_amount", "metadata", "created_at", "updated_at", "deleted_at", "version") FROM stdin;
ordcl_01KPZVDFX4J7TGXW5004CDD3WV	order_01KPWECVRHA1YDZSXFAMWKRNA0	payment_collection	pay_col_01KPWECVGHJW90KXQ708NJQRS2	30	{"value": "30", "precision": 20}	{"created_in_version": 2}	2026-04-24 15:38:38.118+02	2026-04-24 15:38:38.118+02	\N	2
\.


--
-- Data for Name: order_exchange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_exchange" ("id", "order_id", "return_id", "order_version", "display_id", "no_notification", "allow_backorder", "difference_due", "raw_difference_due", "metadata", "created_at", "updated_at", "deleted_at", "canceled_at", "created_by") FROM stdin;
\.


--
-- Data for Name: order_exchange_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_exchange_item" ("id", "exchange_id", "item_id", "quantity", "raw_quantity", "note", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_fulfillment" ("order_id", "fulfillment_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_item" ("id", "order_id", "version", "item_id", "quantity", "raw_quantity", "fulfilled_quantity", "raw_fulfilled_quantity", "shipped_quantity", "raw_shipped_quantity", "return_requested_quantity", "raw_return_requested_quantity", "return_received_quantity", "raw_return_received_quantity", "return_dismissed_quantity", "raw_return_dismissed_quantity", "written_off_quantity", "raw_written_off_quantity", "metadata", "created_at", "updated_at", "deleted_at", "delivered_quantity", "raw_delivered_quantity", "unit_price", "raw_unit_price", "compare_at_unit_price", "raw_compare_at_unit_price") FROM stdin;
orditem_01KPWECVRNC3DH6NSV32MJ3EAM	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	ordli_01KPWECVRM631BSED4QY9H1P8V	1	{"value": "1", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	\N	2026-04-23 07:53:22.712+02	2026-04-23 07:53:22.712+02	\N	0	{"value": "0", "precision": 20}	\N	\N	\N	\N
orditem_01KPWECVRPYM0PXNKK5H0P07ZT	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	ordli_01KPWECVRMEM3WEM6VW45WG6AN	1	{"value": "1", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	\N	2026-04-23 07:53:22.712+02	2026-04-23 07:53:22.712+02	\N	0	{"value": "0", "precision": 20}	\N	\N	\N	\N
orditem_01KPZVDFWZGK3SH8GSB4A3ZEX5	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	ordli_01KPWECVRM631BSED4QY9H1P8V	1	{"value": "1", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	\N	2026-04-24 15:38:38.117+02	2026-04-24 15:38:38.117+02	\N	0	{"value": "0", "precision": 20}	10	{"value": "10", "precision": 20}	\N	\N
orditem_01KPZVDFX07KK6349RTHZDB8KH	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	ordli_01KPWECVRMEM3WEM6VW45WG6AN	1	{"value": "1", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	0	{"value": "0", "precision": 20}	\N	2026-04-24 15:38:38.118+02	2026-04-24 15:38:38.118+02	\N	0	{"value": "0", "precision": 20}	10	{"value": "10", "precision": 20}	\N	\N
\.


--
-- Data for Name: order_line_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_line_item" ("id", "totals_id", "title", "subtitle", "thumbnail", "variant_id", "product_id", "product_title", "product_description", "product_subtitle", "product_type", "product_collection", "product_handle", "variant_sku", "variant_barcode", "variant_title", "variant_option_values", "requires_shipping", "is_discountable", "is_tax_inclusive", "compare_at_unit_price", "raw_compare_at_unit_price", "unit_price", "raw_unit_price", "metadata", "created_at", "updated_at", "deleted_at", "is_custom_price", "product_type_id", "is_giftcard") FROM stdin;
ordli_01KPWECVRM631BSED4QY9H1P8V	\N	Medusa Shorts	L	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	variant_01KPVEFMJ6HYMRDT21HFF4V4KC	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	Medusa Shorts	Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.	\N	\N	\N	shorts	SHORTS-L	\N	L	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-23 07:53:22.712+02	2026-04-23 07:53:22.712+02	\N	f	\N	f
ordli_01KPWECVRMEM3WEM6VW45WG6AN	\N	Medusa T-Shirt	M / Black	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	\N	\N	\N	t-shirt	SHIRT-M-BLACK	\N	M / Black	\N	t	t	f	\N	\N	10	{"value": "10", "precision": 20}	{}	2026-04-23 07:53:22.712+02	2026-04-23 07:53:22.712+02	\N	f	\N	f
\.


--
-- Data for Name: order_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_line_item_adjustment" ("id", "description", "promotion_id", "code", "amount", "raw_amount", "provider_id", "created_at", "updated_at", "item_id", "deleted_at", "is_tax_inclusive", "version") FROM stdin;
\.


--
-- Data for Name: order_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_line_item_tax_line" ("id", "description", "tax_rate_id", "code", "rate", "raw_rate", "provider_id", "created_at", "updated_at", "item_id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_payment_collection" ("order_id", "payment_collection_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
order_01KPWECVRHA1YDZSXFAMWKRNA0	pay_col_01KPWECVGHJW90KXQ708NJQRS2	ordpay_01KPWECVX1HCJ8MB745ZXZKKAJ	2026-04-23 07:53:22.84232+02	2026-04-23 07:53:22.84232+02	\N
\.


--
-- Data for Name: order_promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_promotion" ("order_id", "promotion_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_shipping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_shipping" ("id", "order_id", "version", "shipping_method_id", "created_at", "updated_at", "deleted_at", "return_id", "claim_id", "exchange_id") FROM stdin;
ordspmv_01KPWECVRHYSBBJ5SAQR7PPBBF	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	ordsm_01KPWECVRG62SZ4NV07AF518C6	2026-04-23 07:53:22.713+02	2026-04-23 07:53:22.713+02	\N	\N	\N	\N
ordspmv_01KPZVDFX2EXGH008CJW3D4DJN	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	ordsm_01KPWECVRG62SZ4NV07AF518C6	2026-04-23 07:53:22.713+02	2026-04-23 07:53:22.713+02	\N	\N	\N	\N
\.


--
-- Data for Name: order_shipping_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_shipping_method" ("id", "name", "description", "amount", "raw_amount", "is_tax_inclusive", "shipping_option_id", "data", "metadata", "created_at", "updated_at", "deleted_at", "is_custom_amount") FROM stdin;
ordsm_01KPWECVRG62SZ4NV07AF518C6	Standard Shipping	\N	10	{"value": "10", "precision": 20}	f	so_01KPVEFM8VS58X5XS6Z6PA0X3S	{}	\N	2026-04-23 07:53:22.713+02	2026-04-23 07:53:22.713+02	\N	f
\.


--
-- Data for Name: order_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_shipping_method_adjustment" ("id", "description", "promotion_id", "code", "amount", "raw_amount", "provider_id", "created_at", "updated_at", "shipping_method_id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_shipping_method_tax_line" ("id", "description", "tax_rate_id", "code", "rate", "raw_rate", "provider_id", "created_at", "updated_at", "shipping_method_id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: order_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_summary" ("id", "order_id", "version", "totals", "created_at", "updated_at", "deleted_at") FROM stdin;
ordsum_01KPWECVRE9AW4PCGM8A3AEKXF	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	{"paid_total": 30, "raw_paid_total": {"value": "30", "precision": 20}, "refunded_total": 30, "accounting_total": 30, "credit_line_total": 0, "transaction_total": 0, "pending_difference": 30, "raw_refunded_total": {"value": "30", "precision": 20}, "current_order_total": 30, "original_order_total": 30, "raw_accounting_total": {"value": "30", "precision": 20}, "raw_credit_line_total": {"value": "0", "precision": 20}, "raw_transaction_total": {"value": "0", "precision": 20}, "raw_pending_difference": {"value": "30", "precision": 20}, "raw_current_order_total": {"value": "30", "precision": 20}, "raw_original_order_total": {"value": "30", "precision": 20}}	2026-04-23 07:53:22.712+02	2026-04-24 15:38:37.869+02	\N
ordsum_01KPZVDFX15X5P1D9JYM7NE98C	order_01KPWECVRHA1YDZSXFAMWKRNA0	2	{"paid_total": 30, "raw_paid_total": {"value": "30", "precision": 20}, "refunded_total": 30, "accounting_total": 0, "credit_line_total": 30, "transaction_total": 0, "pending_difference": 0, "raw_refunded_total": {"value": "30", "precision": 20}, "current_order_total": 0, "original_order_total": 30, "raw_accounting_total": {"value": "0", "precision": 20}, "raw_credit_line_total": {"value": "30", "precision": 20}, "raw_transaction_total": {"value": "0", "precision": 20}, "raw_pending_difference": {"value": "0", "precision": 20}, "raw_current_order_total": {"value": "0", "precision": 20}, "raw_original_order_total": {"value": "30", "precision": 20}}	2026-04-24 15:38:38.118+02	2026-04-24 15:38:38.118+02	\N
\.


--
-- Data for Name: order_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."order_transaction" ("id", "order_id", "version", "amount", "raw_amount", "currency_code", "reference", "reference_id", "created_at", "updated_at", "deleted_at", "return_id", "claim_id", "exchange_id") FROM stdin;
ordtrx_01KPZVCYD7RGT02C9JAHBN1EWK	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	30	{"value": "30", "precision": 20}	eur	capture	capt_01KPZVCYAGWHTXE7RAVN7B8R6E	2026-04-24 15:38:20.214+02	2026-04-24 15:38:20.214+02	\N	\N	\N	\N
ordtrx_01KPZVDFN7K9KEGX9JZT7EB3B5	order_01KPWECVRHA1YDZSXFAMWKRNA0	1	-30	{"value": "-30", "precision": 20}	eur	refund	pay_01KPWECVYNNQ39CB87ZBENA1DG	2026-04-24 15:38:37.869+02	2026-04-24 15:38:37.869+02	\N	\N	\N	\N
\.


--
-- Data for Name: page; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."page" ("id", "slug", "title", "content", "meta_description", "is_published", "created_at", "updated_at", "deleted_at") FROM stdin;
01KQ09S1XY7TRM8835EYVVWDZA	privacy	Privacy Policy	<div><div><h1>Privacy Policy</h1></div></div><div><div><div><nav><ol><li><a>00 Purpose</a></li><li><a>01 Personal Information Collection</a></li><li><a>02 Who We Share Your Personal Information To</a></li><li><a>03 Advertising</a></li><li><a>04 Cookies</a></li><li><a>05 Security</a></li><li><a>06 Your Acceptance of These Terms</a></li></ol></nav><div><div><h2>Purpose</h2><div><p>This Privacy Policy describes our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You.<br><br>By using the Site, you agree to our Privacy Policy. If you do not agree to our Privacy Policy, you shall not use this website. The Site reserves the right, to change, modify, add, or remove portions of our Privacy Policy at any time. Changes will be effective when posted on the Site with no other notice provided.</p></div></div><div><h2>Personal Information Collection</h2><div><p>When you subscribe to the Site either by joining our mailing list or by purchasing product(s) or our service(s), we may collect some personal information from you. The following are some personal information gathered on the Site, which include but are not limited to the below:<br><br>1. Name<br>2. Gender<br>3. Delivery address<br>4. Mailing address (for billing purposes)<br>5. Email Address<br>6. Contact No<br>7. Date of Birth</p></div></div><div><h2>Who We Share Your Personal Information To</h2><div><p>We employ third-party service providers to perform some functions or event on our behalf. Examples include payment processing and delivering orders. They have access to your Personal Information needed to perform their functions, but may not use them for other purposes.</p></div></div><div><h2>Advertising</h2><div><p>Ads appearing on our website may be delivered to users by advertising partners, who may set cookies. These cookies allow the ad server to recognize your computer each time they send you an online advertisement to compile information about you or others who use your computer. This information allows ad networks to, among other things, deliver targeted advertisements that they believe will be of most interest to you. This Privacy Policy covers the use of cookies by Because You Florist and does not cover the use of cookies by any advertisers. Ads appearing on our website may be delivered to users by advertising partners, who may set cookies. These cookies allow the ad server to recognize your computer each time they send you an online advertisement to compile information about you or others who use your computer. This information allows ad networks to, among other things, deliver targeted advertisements that they believe will be of most interest to you. This Privacy Policy covers the use of cookies by Because You Florist and does not cover the use of cookies by any advertisers.</p></div></div><div><h2>Cookies</h2><div><p>A cookies are pieces of information that a website transfers to an individual’s computer hard drive for record keeping purposes. Cookies make using our Sites easier by, among other things, saving your passwords and preferences for you. As an example, we use cookies to help identify you when you return to the Store. These cookies are restricted for use only on our Sites, and do not transfer any personal information to any other party. Most browsers are initially set up to accept cookies; however, you can reset your browser to refuse all cookies or indicate when a cookie is being sent. (Note: you will need to consult the help area of your browser application for instructions.) If you choose to disable your cookies setting or refuse to accept a cookie, some parts of our web sites will not function properly or may be considerably slower. For example, without cookies, you will not be able to set personalized preferences or you may have difficulty completing shopping transactions, entering contests, or playing games.</p></div></div><div><h2>Security</h2><div><p>Because You website do applies appropriate security application in order to prevent the leaking customers’ personal identification details from third parties, illegal disclosure and hackers. However bear in mind that any information transmitted through Internet is <strong> NOT </strong> 100% guaranteed safe and secure.</p></div></div><div><h2>Your Acceptance of These Terms</h2><div><p>By using Because You Florist website, you signify your acceptance of Because You Florist ‘s Privacy Policy. If you do not agree to this policy, please do not use our Site. Because You Florist reserves the right to modify, alter or otherwise update this policy at any time, so visitors are encouraged to review this policy from time to time. Your continued use of the Because You Florist website following the posting of changes to these terms will mean you accept those changes. If you have any questions regarding our Privacy Policy, you may contact us at <strong> becauseyouflorist@gmail.com </strong> .</p></div></div></div></div></div></div>	How What Shop collects, uses, and protects your personal data.	t	2026-04-24 19:49:37.086+02	2026-04-24 19:49:37.086+02	\N
01KQ09S225EE8D1E40DSJKTD6D	terms	Terms & Conditions	<div><div><h1>Terms of Service</h1></div></div><div><div><div><nav><ol><li><a>00 General</a></li><li><a>01 Order Policy</a></li><li><a>02 Change Your Order</a></li><li><a>03 Delivery Policy</a></li><li><a>04 Delivery Area</a></li><li><a>05 Non-Delivery Policy</a></li><li><a>06 Payment Policy</a></li><li><a>07 Cancellation &amp; Refund Policy</a></li><li><a>08 Site Contents &amp; Copyrights</a></li><li><a>09 Comments And Feedbacks</a></li><li><a>10 Weather Conditions</a></li></ol></nav><div><div><h2>General</h2><div><p>The content of terms and conditions may be change, move or delete at any time. Please note that <strong>Because You Florist</strong> have the rights to change the contents of the terms and conditions without any notice. Any violation of rules and regulations of these terms and conditions, <strong>Because You Florist</strong> will take immediate actions against the offender(s).</p></div></div><div><h2>Order Policy</h2><div><p>Orders are not binding upon <strong>Because You Florist</strong> until accepted and confirmed by us. Once an order has been placed and accepted by us, the order is not cancelable unless the shipment is unavoidably delayed. The order can be cancelled only on the following conditions.</p></div></div><div><h2>Change Your Order</h2><div><p>If you wish to change your order, please do so by contacting us at <strong>becauseyouflorist@gmail.com</strong>. We will always do our best to make last-minute changes for you, <strong>NOT</strong> 100% guarantee changes in relation to the delivery address and card messages that are requested by one (1) day before the intended delivery day.</p></div></div><div><h2>Delivery Policy</h2><div><p><strong>Because You Florist</strong> ‘s delivery is unavailable on Public Holidays are.<br>We will leave the delivery timing to the professionals. Time of Delivery is variable and not customizable.<br><strong>Because You Florist</strong> reserves the right to reschedule the delivery if fail to adhere to delivery requirements.</p></div></div><div><h2>Delivery Area</h2><div><p><strong>Because You Florist</strong> only delivers within Kuala Lumpur and selected areas in Selangor at this moment. We do not deliver to PO boxes.</p></div></div><div><h2>Non-Delivery Policy</h2><div><p>In the event for those order recipients is not around when we deliver the product(s), we will deliver to the following:<br>-For delivery to office, we will deliver to the receptionist or order recipient’s colleague;<br>-For delivery to house or apartment, we will deliver to order recipient’s family member or to the security office or management office;<br>-For delivery to college/university campus, we may contact you or the order recipient to make arrangement to deliver to the order recipient’s friend.<br>during the delivery and due to the absence and/or non-acceptance of item(s) from the Alternative Recipients, we will not be held responsible for the non-delivery of the item(s) and no refund shall be issued in such event.<br> In the event that the item(s) are not delivered due to incorrect delivery details, we will not be held responsible for the non-delivery of the item(s) and no refund shall be issued in such event. Please contact us at <strong>becauseyouflorist@gmail.com</strong> . It is your responsibility to contact us to scheduled delivery date in order to claim a refund for non-delivery. Failure to do so will result in the lapse of any rights to a refund.</p></div></div><div><h2>Payment Policy</h2><div><p>We are accepting Online Banking Malaysia only.<br>For all other payment methods, please contact us at <strong>becauseyouflorist@gmail.com</strong>.</p></div></div><div><h2>Cancellation &amp; Refund Policy</h2><div><p>Cancellation and Refund will be processed within 24 hours from the receipt of <strong>Because You Florist</strong>, contact us at <strong>becauseyouflorist@gmail.com</strong>. Refunds for non-defective items are subject to item returned within the first 3 days of return time qualifies for full refund and defective items returned after 3 days, Shipping fee is <strong>NON REFUNDABLE</strong>. All returns must be accompanied by your <strong> ORIGINAL </strong> sales receipt. The product must be returned in its original condition accompanied by all the packaging, manuals, and accessories. All items must be returned in the original manufacture’s box. Items returned without boxes will not be accepted. Missing accessories, parts, manuals are subject to additional restocking fee.</p></div></div><div><h2>Site Contents &amp; Copyrights</h2><div><p>Unless otherwise noted, all materials, including images, illustrations, designs, icons, photographs, video clips, and written and other materials that appear as part of this Site, in other words “Contents of the Site” are copyrights, trademarks, trade dress and/or other intellectual properties owned, controlled or licensed by <strong>Because You Florist</strong>.</p></div></div><div><h2>Comments And Feedbacks</h2><div><p>All comments and feedbacks to <strong>becauseyouflorist@gmail.com</strong> will be remain <strong>Because You Florist</strong> ‘s property.<br>User shall agree that there will be no comment(s) submitted to the <strong>becauseyouflorist@gmail.com</strong> will violate any rights of any third party, including copyrights, trademarks, privacy of other personal or proprietary right(s). Furthermore, the user shall agree there will not be content of unlawful, abusive, or obscene material(s) submitted to the site. User will be the only one responsible for any comment’s content made.</p></div></div><div><h2>Weather Conditions</h2><div><p>During adverse weather conditions (heavy rain and flood), our delivery man may not be able to deliver orders on time. This is beyond our control and we cannot accept responsibility for the late delivery of the order. Therefore, in the event of adverse weather conditions, we will not issue a refund or offer re-delivery for the affected orders.</p></div></div></div></div></div></div>	Terms and conditions for using What Shop and completing orders.	t	2026-04-24 19:49:37.222+02	2026-04-24 19:49:37.222+02	\N
01KQ2JX492EA5JP8JV92GMQ1NJ	about-us	About Us	<h2>Because You</h2>\n<p>Because You is an florist online shop which is located in Klang Valley, Malaysia which primarily focused on delivery service. Founded in 2016, the company has evolved from small office to a robust team of professionals with backgrounds in designers, customer service representatives, and delivery guys.</p> <p>Because You (All of our customers) are important, our professional staffs are dedicated to making our customers' experience a pleasant one.Each of us is  doing his best to make our customers satisfied. Please leave your feedback on your experience with us, your opinion matters.</p>\n<h2>Why Choose Us?</h2>\n<strong>Why Choose Us?</strong><p>We ensure YOU " our customer" that one of our main focus will be on product quality. We'll make sure YOU get the best quality from us and we serve each customers as V.I.P.</p> <strong>Friendly Service</strong> <p>It is our job to serve YOU "our customer" with friendly. We will make sure YOU feel comfortable and provide YOU our best support if you require any assistance throughout your shopping with us.</p>\n<h2>OUR MISSION</h2>\n<p>1. <strong>Because You </strong>, we thrive to become the leader in providing floral products and services in Klang Valley, Malaysia.</p><p>2. <strong>Because You </strong>, we thrive to maintain a tradition of exceeding customers' expectations with our quality products and services at a reasonable price.</p><p>3. <strong>Because You </strong>, we thrive to improve by provide opportunities for the staff to grow with the business.</p>\n<h2>OUR VISION</h2>\n<p>Our mission at Because You is to offer the best selection of floral products at affordable costs and provides knowledgeable and customer-focused staffs who offer fast efficient service so that YOU "our customers" can have the best value and experience.</p>\n<h2>Because You Florist – Online Flower Delivery</h2>\n<p>Because You is an online florist located in Klang Valley and Kuala Lumpur. We also provide <strong> online floral services </strong> to weddings, events, table and vase arrangements.</p>\n<h2>Same Day Delivery in Klang Valley areas</h2>\n<p>We provide <strong> same day delivery </strong> florist service to a vast part of Klang Valley areas, including areas such as Petaling Jaya (PJ), Kuala Lumpur (KL), Cheras, Subang Jaya, Ampang, Seri Kembangan, Puchong, Shah Alam, Klang and more. You could book your bonquet or gift anytime with Becauseyou <strong> florist online </strong> and we will <strong> send flower </strong> with your <strong> suprise </strong> time given.</p>\n<h2>Gift for Lover, Anniversary , Birthday</h2>\n<p>We created some of the most striking hand-tied bouquets in Malaysia, your hand bouquet/ flower bouquet will be hand-tied by one of our <strong> professional florists </strong> with years of experience！A wide array of beautiful hand bouquet flowers available from fresh to dried to <strong>soap flowers</strong>! Every piece is arranged beautifully by Because You Florist.</p>\n<h2>Affordable Flower Price in Klang Valley</h2>\n<p>Our products price caters to all kinds of budget, from cheap and affordable to luxurious <strong>bouquet</strong>. We also have designs that are suitable for all kinds of occasions like Valentine's Day, Mother's Day, Father's Day, Christmas, Chinese New Year, anniversary, birthday, proposal, graduation, surprise, condolence and sympathy.</p>	Learn about What Shop, our same-day delivery promise, and the team crafting every order.	t	2026-04-25 17:07:36.611+02	2026-04-25 17:07:36.611+02	\N
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."payment" ("id", "amount", "raw_amount", "currency_code", "provider_id", "data", "created_at", "updated_at", "deleted_at", "captured_at", "canceled_at", "payment_collection_id", "payment_session_id", "metadata") FROM stdin;
pay_01KPWECVYNNQ39CB87ZBENA1DG	30	{"value": "30", "precision": 20}	eur	pp_system_default	{}	2026-04-23 07:53:22.902+02	2026-04-24 15:38:20.136+02	\N	2026-04-24 15:38:20.128+02	\N	pay_col_01KPWECVGHJW90KXQ708NJQRS2	payses_01KPWECVJWKW3HF9HQQZ25K7RS	\N
\.


--
-- Data for Name: payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."payment_collection" ("id", "currency_code", "amount", "raw_amount", "authorized_amount", "raw_authorized_amount", "captured_amount", "raw_captured_amount", "refunded_amount", "raw_refunded_amount", "created_at", "updated_at", "deleted_at", "completed_at", "status", "metadata") FROM stdin;
pay_col_01KPWECVGHJW90KXQ708NJQRS2	eur	30	{"value": "30", "precision": 20}	30	{"value": "30", "precision": 20}	30	{"value": "30", "precision": 20}	30	{"value": "30", "precision": 20}	2026-04-23 07:53:22.449+02	2026-04-24 15:38:38.176+02	\N	2026-04-24 15:38:37.83+02	canceled	\N
\.


--
-- Data for Name: payment_collection_payment_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."payment_collection_payment_providers" ("payment_collection_id", "payment_provider_id") FROM stdin;
\.


--
-- Data for Name: payment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."payment_provider" ("id", "is_enabled", "created_at", "updated_at", "deleted_at") FROM stdin;
pp_system_default	t	2026-04-22 22:35:26.319+02	2026-04-22 22:35:26.319+02	\N
pp_stripe-oxxo_stripe	t	2026-04-23 20:09:32.864+02	2026-04-23 20:09:32.864+02	\N
pp_stripe-promptpay_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe-przelewy24_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe-ideal_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe-giropay_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe-blik_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
pp_stripe-bancontact_stripe	t	2026-04-23 20:09:32.865+02	2026-04-23 20:09:32.865+02	\N
\.


--
-- Data for Name: payment_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."payment_session" ("id", "currency_code", "amount", "raw_amount", "provider_id", "data", "context", "status", "authorized_at", "payment_collection_id", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
payses_01KPWECVJWKW3HF9HQQZ25K7RS	eur	30	{"value": "30", "precision": 20}	pp_system_default	{}	{}	authorized	2026-04-23 07:53:22.895+02	pay_col_01KPWECVGHJW90KXQ708NJQRS2	{}	2026-04-23 07:53:22.524+02	2026-04-23 07:53:22.903+02	\N
\.


--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price" ("id", "title", "price_set_id", "currency_code", "raw_amount", "rules_count", "created_at", "updated_at", "deleted_at", "price_list_id", "amount", "min_quantity", "max_quantity", "raw_min_quantity", "raw_max_quantity") FROM stdin;
price_01KPVEFMNG3ZD74PAZ9SKM62K2	\N	pset_01KPVEFMNGRCFZ6VGS425R599R	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNG9H47VX0WQMQYE7D2	\N	pset_01KPVEFMNGRCFZ6VGS425R599R	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNH2E65WSKQKKKT7DET	\N	pset_01KPVEFMNHBA5BVB8NDCWKJBND	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNHCJYA401HG6FES4JF	\N	pset_01KPVEFMNHBA5BVB8NDCWKJBND	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNHRGWDTMZV4D1YFA0W	\N	pset_01KPVEFMNHF1JZHB22EK67PRBV	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNHWZNSHHCMQ44QDBMN	\N	pset_01KPVEFMNHF1JZHB22EK67PRBV	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNJWNW7ZB1493YAV3N4	\N	pset_01KPVEFMNJW99ZZ8H8C2READ0V	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNJ864JD38XDF6KT6Q0	\N	pset_01KPVEFMNJW99ZZ8H8C2READ0V	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNJB1GSQQS178GBXPRQ	\N	pset_01KPVEFMNJEVR2TN22MA4711VM	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNJKZQN5S7JVH687WV2	\N	pset_01KPVEFMNJEVR2TN22MA4711VM	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNKDXNZGZ1Z8KVHZ6XP	\N	pset_01KPVEFMNK2WGGN7ND0WTBTY48	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNK3GQVQ5XTC0F3N1FM	\N	pset_01KPVEFMNK2WGGN7ND0WTBTY48	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNKEP5THKFANWMZN1TV	\N	pset_01KPVEFMNKFBJSSKPMPZ06H5YV	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNK8NFNYC0NPBHEEY9F	\N	pset_01KPVEFMNKFBJSSKPMPZ06H5YV	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNMH95SQPDYG9CN26FR	\N	pset_01KPVEFMNMYKTSAS6WKSTPCHYQ	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNMXJ2XRSJX2EREGRQ7	\N	pset_01KPVEFMNMYKTSAS6WKSTPCHYQ	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNMREDVQCAPE20CGQ94	\N	pset_01KPVEFMNMCF9CPSKCVD8HKWG4	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNMQTEX5TZST6HQ6BM2	\N	pset_01KPVEFMNMCF9CPSKCVD8HKWG4	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNNYFMFCFARSNBZ25H1	\N	pset_01KPVEFMNN9BKKZ9VCH93SPX8N	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNNMJH748D8CV5BQYDB	\N	pset_01KPVEFMNN9BKKZ9VCH93SPX8N	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNNR9FZBJ5DRQTNCMD9	\N	pset_01KPVEFMNN2X0V74G5CW0QVG4G	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNNM1KXADM8PT13G3SW	\N	pset_01KPVEFMNN2X0V74G5CW0QVG4G	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNP8XRWW7PXJ6ND1KVD	\N	pset_01KPVEFMNP8K5CWYA6SMDZEM91	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNPMCDRT0X9WVAARV92	\N	pset_01KPVEFMNP8K5CWYA6SMDZEM91	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNP81XV8019YS74DDNS	\N	pset_01KPVEFMNP99CVCKY9KB1KDBAH	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNPNEH0V7PSA6KQ4JF8	\N	pset_01KPVEFMNP99CVCKY9KB1KDBAH	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNQ4WARTSHYZ0S16N2Z	\N	pset_01KPVEFMNQYWDWJ3G1G7ZG4DQV	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNQRKXJ1MCEPFHACEWW	\N	pset_01KPVEFMNQYWDWJ3G1G7ZG4DQV	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNQ36BZJX5G2FJ9A0VZ	\N	pset_01KPVEFMNQJBGFZ59Z1WQS1GR8	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNQPXAG3J180TA7N5D5	\N	pset_01KPVEFMNQJBGFZ59Z1WQS1GR8	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNQ5R1JNREW58A6VBE7	\N	pset_01KPVEFMNRBYXTB761XRJB6TTK	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNQJW6WYSS7F64YJ5MD	\N	pset_01KPVEFMNRBYXTB761XRJB6TTK	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNR3A9D37SXDB25Y8BM	\N	pset_01KPVEFMNRC4RHTF0E442QXM7N	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.324+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNRT3FP3PP25NN5ZZ3S	\N	pset_01KPVEFMNRC4RHTF0E442QXM7N	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNREXDBAFVSQZB17A54	\N	pset_01KPVEFMNS9K8M35QQTG012Y9J	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNSS8NAFJMN7TGQRAXW	\N	pset_01KPVEFMNS9K8M35QQTG012Y9J	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNSPN2MD5WKVNSYCA1B	\N	pset_01KPVEFMNSSG99XP81Q8ZQQ3CS	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFMNSQKHQDGXFJMZHSEDA	\N	pset_01KPVEFMNSSG99XP81Q8ZQQ3CS	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	15	\N	\N	\N	\N
price_01KPVEFMNSC1CDWCVVKY15TPAW	\N	pset_01KPVEFMNSBHWDK9G383SSCKKK	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	10	\N	\N	\N	\N
price_01KPVEFM9VRAG7VF0TGT4V2D9F	\N	pset_01KPVEFM9VV72RGDK9J8DAKT4J	usd	{"value": "10", "precision": 20}	0	2026-04-22 22:35:38.941+02	2026-04-24 15:31:29.703+02	2026-04-24 15:31:29.697+02	\N	10	\N	\N	\N	\N
price_01KPVEFM9VKPXGGBWCYD1B3W5W	\N	pset_01KPVEFM9VV72RGDK9J8DAKT4J	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:38.941+02	2026-04-24 15:31:29.703+02	2026-04-24 15:31:29.697+02	\N	10	\N	\N	\N	\N
price_01KPVEFM9VWHG38A2NNH16TNF8	\N	pset_01KPVEFM9VV72RGDK9J8DAKT4J	eur	{"value": "10", "precision": 20}	1	2026-04-22 22:35:38.941+02	2026-04-24 15:31:29.703+02	2026-04-24 15:31:29.697+02	\N	10	\N	\N	\N	\N
price_01KPVEFMNS22TMQPPBYGPR94CS	\N	pset_01KPVEFMNSBHWDK9G383SSCKKK	usd	{"value": "15", "precision": 20}	0	2026-04-22 22:35:39.324+02	2026-04-22 22:35:39.324+02	\N	\N	15	\N	\N	\N	\N
price_01KPXRBRCRSQZWRFF3MTK438QN	\N	pset_01KPXRBRCR9KJGB3MHRWXM9ZE1	eur	{"value": "1200", "precision": 20}	0	2026-04-23 20:06:46.682+02	2026-04-23 20:06:46.682+02	\N	\N	1200	\N	\N	\N	\N
price_01KPXRBRCRVH3SGXGBZMDAXNMJ	\N	pset_01KPXRBRCR9KJGB3MHRWXM9ZE1	usd	{"value": "1200", "precision": 20}	0	2026-04-23 20:06:46.682+02	2026-04-23 20:06:46.682+02	\N	\N	1200	\N	\N	\N	\N
price_01KPXRBRMXVH1S434HK6ZXAK7Y	\N	pset_01KPXRBRMYDJG7DVMDAPRH64G2	eur	{"value": "1500", "precision": 20}	0	2026-04-23 20:06:46.942+02	2026-04-23 20:06:46.942+02	\N	\N	1500	\N	\N	\N	\N
price_01KPXRBRMX72H32XYEWGT9FY7S	\N	pset_01KPXRBRMYDJG7DVMDAPRH64G2	usd	{"value": "1500", "precision": 20}	0	2026-04-23 20:06:46.942+02	2026-04-23 20:06:46.942+02	\N	\N	1500	\N	\N	\N	\N
price_01KPXRBRVJK5CMWAFT88B7853S	\N	pset_01KPXRBRVKGKR4REHQJG6B7ACG	eur	{"value": "2800", "precision": 20}	0	2026-04-23 20:06:47.155+02	2026-04-23 20:06:47.155+02	\N	\N	2800	\N	\N	\N	\N
price_01KPXRBRVKS4J5Q3RZPJNDRZN8	\N	pset_01KPXRBRVKGKR4REHQJG6B7ACG	usd	{"value": "2800", "precision": 20}	0	2026-04-23 20:06:47.155+02	2026-04-23 20:06:47.155+02	\N	\N	2800	\N	\N	\N	\N
price_01KPXRBS240CJJ6520FQN2WGWF	\N	pset_01KPXRBS248HT0VM2M33Y4G43N	eur	{"value": "2200", "precision": 20}	0	2026-04-23 20:06:47.364+02	2026-04-23 20:06:47.364+02	\N	\N	2200	\N	\N	\N	\N
price_01KPXRBS24TVEBX023JE99S48E	\N	pset_01KPXRBS248HT0VM2M33Y4G43N	usd	{"value": "2200", "precision": 20}	0	2026-04-23 20:06:47.364+02	2026-04-23 20:06:47.364+02	\N	\N	2200	\N	\N	\N	\N
price_01KPXRBSBQ7ESX5NKFJW3DSN4F	\N	pset_01KPXRBSBRRN5S9VBY39YVB2Z9	eur	{"value": "900", "precision": 20}	0	2026-04-23 20:06:47.672+02	2026-04-23 20:06:47.672+02	\N	\N	900	\N	\N	\N	\N
price_01KPXRBSBR7PSNZ1HSAP8PW1MW	\N	pset_01KPXRBSBRRN5S9VBY39YVB2Z9	usd	{"value": "900", "precision": 20}	0	2026-04-23 20:06:47.673+02	2026-04-23 20:06:47.673+02	\N	\N	900	\N	\N	\N	\N
price_01KPXRBSJE2XXFQ6K20CH4JE90	\N	pset_01KPXRBSJESFNPHBAY7KTYX9TK	eur	{"value": "1800", "precision": 20}	0	2026-04-23 20:06:47.886+02	2026-04-23 20:06:47.886+02	\N	\N	1800	\N	\N	\N	\N
price_01KPXRBSJECDCE93SHXBNMHPFH	\N	pset_01KPXRBSJESFNPHBAY7KTYX9TK	usd	{"value": "1800", "precision": 20}	0	2026-04-23 20:06:47.886+02	2026-04-23 20:06:47.886+02	\N	\N	1800	\N	\N	\N	\N
price_01KPZA60QENSDCAQJ20KF3045W	\N	pset_01KPZA60QF4EAP72MB72P97EEP	myr	{"value": "1500", "precision": 20}	0	2026-04-24 10:37:27.408+02	2026-04-24 10:37:27.408+02	\N	\N	1500	\N	\N	\N	\N
price_01KPZA60QFCHDFGV9KB55565FN	\N	pset_01KPZA60QF4EAP72MB72P97EEP	myr	{"value": "1500", "precision": 20}	1	2026-04-24 10:37:27.409+02	2026-04-24 10:37:27.409+02	\N	\N	1500	\N	\N	\N	\N
price_01KPVEFM9SP0KPQHE41HSF3NVB	\N	pset_01KPVEFM9TY6FMDJZ0GYQH912P	usd	{"value": "10", "precision": 20}	0	2026-04-22 22:35:38.94+02	2026-04-24 15:31:19.537+02	2026-04-24 15:31:19.518+02	\N	10	\N	\N	\N	\N
price_01KPVEFM9S6GW6Z8PXKW5S2NR5	\N	pset_01KPVEFM9TY6FMDJZ0GYQH912P	eur	{"value": "10", "precision": 20}	0	2026-04-22 22:35:38.94+02	2026-04-24 15:31:19.537+02	2026-04-24 15:31:19.518+02	\N	10	\N	\N	\N	\N
price_01KPVEFM9TR6M6JQAM6ZQHVHT8	\N	pset_01KPVEFM9TY6FMDJZ0GYQH912P	eur	{"value": "10", "precision": 20}	1	2026-04-22 22:35:38.941+02	2026-04-24 15:31:19.537+02	2026-04-24 15:31:19.518+02	\N	10	\N	\N	\N	\N
\.


--
-- Data for Name: price_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_list" ("id", "status", "starts_at", "ends_at", "rules_count", "title", "description", "type", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: price_list_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_list_rule" ("id", "price_list_id", "created_at", "updated_at", "deleted_at", "value", "attribute") FROM stdin;
\.


--
-- Data for Name: price_preference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_preference" ("id", "attribute", "value", "is_tax_inclusive", "created_at", "updated_at", "deleted_at") FROM stdin;
prpref_01KPVEFEWWEZ0WN8HBRYC5EHDQ	currency_code	eur	f	2026-04-22 22:35:33.404+02	2026-04-22 22:35:33.404+02	\N
prpref_01KPVEFM1GR2ZEBRQXTPKACHMB	region_id	reg_01KPVEFKYDPAKWC7499ZXE0DY9	f	2026-04-22 22:35:38.677+02	2026-04-22 22:35:38.677+02	\N
prpref_01KPZA4WQDFEK6QTFF4CYG7EVR	region_id	reg_01KPZA4WP86M2QS4F7YPJY792P	f	2026-04-24 10:36:50.541+02	2026-04-24 10:36:50.541+02	\N
prpref_01KPZTYCY6V7TY8TCBP18GNP9H	currency_code	myr	t	2026-04-24 15:30:23.559+02	2026-04-24 15:30:23.559+02	\N
prpref_01KPZTYCY6VZR4VTTRT8ZV7422	currency_code	usd	f	2026-04-24 15:30:23.559+02	2026-04-24 15:30:23.559+02	\N
\.


--
-- Data for Name: price_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_rule" ("id", "value", "priority", "price_id", "created_at", "updated_at", "deleted_at", "attribute", "operator") FROM stdin;
prule_01KPZA60QF12QDJQHKFFYJG17E	reg_01KPZA4WP86M2QS4F7YPJY792P	0	price_01KPZA60QFCHDFGV9KB55565FN	2026-04-24 10:37:27.409+02	2026-04-24 10:37:27.409+02	\N	region_id	eq
prule_01KPVEFM9TZ2DMXT66BS7B1HC5	reg_01KPVEFKYDPAKWC7499ZXE0DY9	0	price_01KPVEFM9TR6M6JQAM6ZQHVHT8	2026-04-22 22:35:38.941+02	2026-04-24 15:31:19.56+02	2026-04-24 15:31:19.518+02	region_id	eq
prule_01KPVEFM9V5M837MMCF8N7QM37	reg_01KPVEFKYDPAKWC7499ZXE0DY9	0	price_01KPVEFM9VWHG38A2NNH16TNF8	2026-04-22 22:35:38.941+02	2026-04-24 15:31:29.714+02	2026-04-24 15:31:29.697+02	region_id	eq
\.


--
-- Data for Name: price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_set" ("id", "created_at", "updated_at", "deleted_at") FROM stdin;
pset_01KPVEFMNGRCFZ6VGS425R599R	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNHBA5BVB8NDCWKJBND	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNHF1JZHB22EK67PRBV	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNJW99ZZ8H8C2READ0V	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNJEVR2TN22MA4711VM	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNK2WGGN7ND0WTBTY48	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNKFBJSSKPMPZ06H5YV	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNMYKTSAS6WKSTPCHYQ	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNMCF9CPSKCVD8HKWG4	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNN9BKKZ9VCH93SPX8N	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNN2X0V74G5CW0QVG4G	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNP8K5CWYA6SMDZEM91	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNP99CVCKY9KB1KDBAH	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNQYWDWJ3G1G7ZG4DQV	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNQJBGFZ59Z1WQS1GR8	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNRBYXTB761XRJB6TTK	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNRC4RHTF0E442QXM7N	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNS9K8M35QQTG012Y9J	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNSSG99XP81Q8ZQQ3CS	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPVEFMNSBHWDK9G383SSCKKK	2026-04-22 22:35:39.323+02	2026-04-22 22:35:39.323+02	\N
pset_01KPXRBRCR9KJGB3MHRWXM9ZE1	2026-04-23 20:06:46.681+02	2026-04-23 20:06:46.681+02	\N
pset_01KPXRBRMYDJG7DVMDAPRH64G2	2026-04-23 20:06:46.942+02	2026-04-23 20:06:46.942+02	\N
pset_01KPXRBRVKGKR4REHQJG6B7ACG	2026-04-23 20:06:47.155+02	2026-04-23 20:06:47.155+02	\N
pset_01KPXRBS248HT0VM2M33Y4G43N	2026-04-23 20:06:47.364+02	2026-04-23 20:06:47.364+02	\N
pset_01KPXRBSBRRN5S9VBY39YVB2Z9	2026-04-23 20:06:47.672+02	2026-04-23 20:06:47.672+02	\N
pset_01KPXRBSJESFNPHBAY7KTYX9TK	2026-04-23 20:06:47.886+02	2026-04-23 20:06:47.886+02	\N
pset_01KPZA60QF4EAP72MB72P97EEP	2026-04-24 10:37:27.408+02	2026-04-24 10:37:27.408+02	\N
pset_01KPVEFM9TY6FMDJZ0GYQH912P	2026-04-22 22:35:38.94+02	2026-04-24 15:31:19.519+02	2026-04-24 15:31:19.518+02
pset_01KPVEFM9VV72RGDK9J8DAKT4J	2026-04-22 22:35:38.94+02	2026-04-24 15:31:29.697+02	2026-04-24 15:31:29.697+02
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product" ("id", "title", "handle", "subtitle", "description", "is_giftcard", "status", "thumbnail", "weight", "length", "height", "width", "origin_country", "hs_code", "mid_code", "material", "collection_id", "type_id", "discountable", "external_id", "created_at", "updated_at", "deleted_at", "metadata") FROM stdin;
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	Medusa T-Shirt	t-shirt	\N	Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-22 22:35:39.102+02	2026-04-22 22:35:39.102+02	\N	\N
prod_01KPVEFMEJ4N6R7MXZREAQHD71	Medusa Sweatshirt	sweatshirt	\N	Reimagine the feeling of a classic sweatshirt. With our cotton sweatshirt, everyday essentials no longer have to be ordinary.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-front.png	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N	\N
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	Medusa Sweatpants	sweatpants	\N	Reimagine the feeling of classic sweatpants. With our cotton sweatpants, everyday essentials no longer have to be ordinary.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-front.png	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N	\N
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	Medusa Shorts	shorts	\N	Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N	\N
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	Classic Tee White	classic-tee-white	\N	Soft cotton tee in white, made for everyday.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-white-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:46.507+02	2026-04-23 20:06:46.507+02	\N	\N
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	Longsleeve Tee	longsleeve-tee	\N	Relaxed-fit long sleeve tee with ribbed cuffs.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:46.832+02	2026-04-23 20:06:46.832+02	\N	\N
prod_01KPXRBRRK9B6E3N6RP56QPRQK	Crewneck Sweatshirt	crewneck-sweatshirt	\N	Heavyweight crewneck sweatshirt with brushed interior.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:47.063+02	2026-04-23 20:06:47.063+02	\N	\N
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	Jogger Pants	jogger-pants	\N	Tapered-fit jogger pants with elastic cuffs.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:47.261+02	2026-04-23 20:06:47.261+02	\N	\N
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	Tote Bag	tote-bag	\N	Heavyweight canvas tote with reinforced straps.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:47.571+02	2026-04-23 20:06:47.571+02	\N	\N
prod_01KPXRBSEPKM19XQMQ37YETB3Q	Baseball Cap	baseball-cap	\N	6-panel cap in washed cotton with curved brim.	f	published	https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-04-23 20:06:47.767+02	2026-04-23 20:06:47.767+02	\N	\N
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_category" ("id", "name", "description", "handle", "mpath", "is_active", "is_internal", "rank", "parent_category_id", "created_at", "updated_at", "deleted_at", "metadata") FROM stdin;
pcat_01KPVEFMDGTRMACAM10ZA8JWRD	Shirts		shirts	pcat_01KPVEFMDGTRMACAM10ZA8JWRD	t	f	0	\N	2026-04-22 22:35:39.059+02	2026-04-23 19:29:38.938+02	\N	{"image": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png"}
pcat_01KPVEFMDJDE5PXMYD56DGVVDC	Pants		pants	pcat_01KPVEFMDJDE5PXMYD56DGVVDC	t	f	2	\N	2026-04-22 22:35:39.059+02	2026-04-23 19:29:38.994+02	\N	{"image": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatpants-gray-front.png"}
pcat_01KPVEFMDHYRGKF48PKS20BV3K	Sweatshirts		sweatshirts	pcat_01KPVEFMDHYRGKF48PKS20BV3K	t	f	1	\N	2026-04-22 22:35:39.059+02	2026-04-23 19:29:39.039+02	\N	{"image": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/sweatshirt-vintage-front.png"}
pcat_01KPVEFMDJXJAGY58XBM3ZY0AT	Merch		merch	pcat_01KPVEFMDJXJAGY58XBM3ZY0AT	t	f	3	\N	2026-04-22 22:35:39.059+02	2026-04-23 19:29:39.108+02	\N	{"image": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png"}
pcat_01KQ1H15XED04ZJCDS3BBQDWQY	Occasions		occasions	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	t	f	4	\N	2026-04-25 07:15:37.775+02	2026-04-25 07:15:37.775+02	\N	\N
pcat_01KQ1H15ZEKB1FMF6HV0X10Y7R	Birthday		birthday	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H15ZEKB1FMF6HV0X10Y7R	t	f	0	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:37.839+02	2026-04-25 07:15:37.839+02	\N	\N
pcat_01KQ1H1613NMTCCZD4ZSREZTHV	Surprise		surprise	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H1613NMTCCZD4ZSREZTHV	t	f	1	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:37.892+02	2026-04-25 07:15:37.892+02	\N	\N
pcat_01KQ1H162RJVFN4MNR84VR16D6	Business Opening		business-opening	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H162RJVFN4MNR84VR16D6	t	f	2	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:37.945+02	2026-04-25 07:15:37.945+02	\N	\N
pcat_01KQ1H164ESMYFNJTF18D55RTB	Wedding		wedding	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H164ESMYFNJTF18D55RTB	t	f	3	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:37.999+02	2026-04-25 07:15:37.999+02	\N	\N
pcat_01KQ1H166EH6BNRYNCQ6V7VDST	Marriage Proposal		marriage-proposal	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H166EH6BNRYNCQ6V7VDST	t	f	4	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:38.064+02	2026-04-25 07:15:38.064+02	\N	\N
pcat_01KQ1H167SB05T09XFEMAK6R23	Graduation		graduation	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H167SB05T09XFEMAK6R23	t	f	5	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:38.105+02	2026-04-25 07:15:38.105+02	\N	\N
pcat_01KQ1H16904G2JVT7WMN3SJV9G	Condolences		condolences	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H16904G2JVT7WMN3SJV9G	t	f	6	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:38.144+02	2026-04-25 07:15:38.144+02	\N	\N
pcat_01KQ1H16A6JD32B96YD2DE7KJZ	Apology		apology	pcat_01KQ1H15XED04ZJCDS3BBQDWQY.pcat_01KQ1H16A6JD32B96YD2DE7KJZ	t	f	7	pcat_01KQ1H15XED04ZJCDS3BBQDWQY	2026-04-25 07:15:38.182+02	2026-04-25 07:15:38.182+02	\N	\N
pcat_01KQ1H16BGCY4V668P2X523HVT	Flowers		flowers	pcat_01KQ1H16BGCY4V668P2X523HVT	t	f	5	\N	2026-04-25 07:15:38.224+02	2026-04-25 07:15:38.224+02	\N	\N
pcat_01KQ1H16DBFQ0Z1NFWX3G8SDK5	Hand Flower Bouquet		hand-flower-bouquet	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16DBFQ0Z1NFWX3G8SDK5	t	f	0	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.285+02	2026-04-25 07:15:38.285+02	\N	\N
pcat_01KQ1H16EX8140QE8PQ6D37MZM	Flower Box		flower-box	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16EX8140QE8PQ6D37MZM	t	f	1	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.333+02	2026-04-25 07:15:38.333+02	\N	\N
pcat_01KQ1H16GNFZBWNBAR2H63BC4W	Baby Breath Series		baby-breath-series	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16GNFZBWNBAR2H63BC4W	t	f	2	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.389+02	2026-04-25 07:15:38.389+02	\N	\N
pcat_01KQ1H16J2Q4P91EFV52GQGFXG	Preserved Flower		preserved-flower	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16J2Q4P91EFV52GQGFXG	t	f	3	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.434+02	2026-04-25 07:15:38.434+02	\N	\N
pcat_01KQ1H16KSBYJTV9QHR6F9FAEG	Opening Stand		opening-stand	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16KSBYJTV9QHR6F9FAEG	t	f	4	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.489+02	2026-04-25 07:15:38.489+02	\N	\N
pcat_01KQ1H16N463MTZHBN1PGTX726	Funeral		funeral	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16N463MTZHBN1PGTX726	t	f	5	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.533+02	2026-04-25 07:15:38.533+02	\N	\N
pcat_01KQ1H16PFJ5Q3YB7J8WMAZP6N	Money Bouquet		money-bouquet	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16PFJ5Q3YB7J8WMAZP6N	t	f	6	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.575+02	2026-04-25 07:15:38.575+02	\N	\N
pcat_01KQ1H16R2D0FV8ZKBD05FK8JP	Soap Flower Bouquet		soap-flower-bouquet	pcat_01KQ1H16BGCY4V668P2X523HVT.pcat_01KQ1H16R2D0FV8ZKBD05FK8JP	t	f	7	pcat_01KQ1H16BGCY4V668P2X523HVT	2026-04-25 07:15:38.626+02	2026-04-25 07:15:38.626+02	\N	\N
pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	Season		season	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	t	f	6	\N	2026-04-25 07:15:38.669+02	2026-04-25 07:15:38.669+02	\N	\N
pcat_01KQ1H16TV6W00V9GRWR3N79HX	Valentine 520 Special		valentine	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H16TV6W00V9GRWR3N79HX	t	f	0	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.715+02	2026-04-25 07:15:38.715+02	\N	\N
pcat_01KQ1H16WFFCJQRTX1SM6APYVB	Mother's Day Special		mother-day	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H16WFFCJQRTX1SM6APYVB	t	f	1	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.768+02	2026-04-25 07:15:38.768+02	\N	\N
pcat_01KQ1H16XT8J35GCKGMK45QV3B	Father's Day Special		father-day	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H16XT8J35GCKGMK45QV3B	t	f	2	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.811+02	2026-04-25 07:15:38.811+02	\N	\N
pcat_01KQ1H16Z2CHH7X26ZSFWEBTVG	Graduation Season		graduation-season	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H16Z2CHH7X26ZSFWEBTVG	t	f	3	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.85+02	2026-04-25 07:15:38.85+02	\N	\N
pcat_01KQ1H170F9AT5V0WA3QEN1WC6	Christmas Special		christmas	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H170F9AT5V0WA3QEN1WC6	t	f	4	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.895+02	2026-04-25 07:15:38.895+02	\N	\N
pcat_01KQ1H171TV5473VPY4J85E49C	Teacher's Day Special		teachers-day	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H171TV5473VPY4J85E49C	t	f	5	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.938+02	2026-04-25 07:15:38.938+02	\N	\N
pcat_01KQ1H1736P2GYSV98ES47YFB2	International Women's Day		international-women-day	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF.pcat_01KQ1H1736P2GYSV98ES47YFB2	t	f	6	pcat_01KQ1H16SDSWYWA3ZKZNW62BYF	2026-04-25 07:15:38.982+02	2026-04-25 07:15:38.982+02	\N	\N
pcat_01KQ1H174N59XCT7D9XGQD0VWJ	F&B		fb	pcat_01KQ1H174N59XCT7D9XGQD0VWJ	t	f	7	\N	2026-04-25 07:15:39.029+02	2026-04-25 07:15:39.029+02	\N	\N
pcat_01KQ1H175X9YS0W381APJRY9PF	Fruit Basket		fruit-basket	pcat_01KQ1H174N59XCT7D9XGQD0VWJ.pcat_01KQ1H175X9YS0W381APJRY9PF	t	f	0	pcat_01KQ1H174N59XCT7D9XGQD0VWJ	2026-04-25 07:15:39.069+02	2026-04-25 07:15:39.069+02	\N	\N
pcat_01KQ1H177BWE1XB32RRFX4AQ2X	Hamper		hamper	pcat_01KQ1H174N59XCT7D9XGQD0VWJ.pcat_01KQ1H177BWE1XB32RRFX4AQ2X	t	f	1	pcat_01KQ1H174N59XCT7D9XGQD0VWJ	2026-04-25 07:15:39.116+02	2026-04-25 07:15:39.116+02	\N	\N
pcat_01KQ1H178SMARZKVCEM15CWVRT	Chocolate		chocolate	pcat_01KQ1H174N59XCT7D9XGQD0VWJ.pcat_01KQ1H178SMARZKVCEM15CWVRT	t	f	2	pcat_01KQ1H174N59XCT7D9XGQD0VWJ	2026-04-25 07:15:39.161+02	2026-04-25 07:15:39.161+02	\N	\N
pcat_01KQ1H179QH0GR47W3CMMFRWC4	Cake		cake	pcat_01KQ1H174N59XCT7D9XGQD0VWJ.pcat_01KQ1H179QH0GR47W3CMMFRWC4	t	f	3	pcat_01KQ1H174N59XCT7D9XGQD0VWJ	2026-04-25 07:15:39.191+02	2026-04-25 07:15:39.191+02	\N	\N
pcat_01KQ1H17AZQ48T4215VKMQCHQN	Gifts		gifts	pcat_01KQ1H17AZQ48T4215VKMQCHQN	t	f	8	\N	2026-04-25 07:15:39.232+02	2026-04-25 07:15:39.232+02	\N	\N
pcat_01KQ1H17C71VBB6DHKBH74R317	Balloon		balloon	pcat_01KQ1H17AZQ48T4215VKMQCHQN.pcat_01KQ1H17C71VBB6DHKBH74R317	t	f	0	pcat_01KQ1H17AZQ48T4215VKMQCHQN	2026-04-25 07:15:39.272+02	2026-04-25 07:15:39.272+02	\N	\N
\.


--
-- Data for Name: product_category_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_category_product" ("product_id", "product_category_id") FROM stdin;
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	pcat_01KPVEFMDGTRMACAM10ZA8JWRD
prod_01KPVEFMEJ4N6R7MXZREAQHD71	pcat_01KPVEFMDHYRGKF48PKS20BV3K
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	pcat_01KPVEFMDJDE5PXMYD56DGVVDC
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	pcat_01KPVEFMDJXJAGY58XBM3ZY0AT
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	pcat_01KPVEFMDGTRMACAM10ZA8JWRD
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	pcat_01KPVEFMDGTRMACAM10ZA8JWRD
prod_01KPXRBRRK9B6E3N6RP56QPRQK	pcat_01KPVEFMDHYRGKF48PKS20BV3K
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	pcat_01KPVEFMDJDE5PXMYD56DGVVDC
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	pcat_01KPVEFMDJXJAGY58XBM3ZY0AT
prod_01KPXRBSEPKM19XQMQ37YETB3Q	pcat_01KPVEFMDJXJAGY58XBM3ZY0AT
\.


--
-- Data for Name: product_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_collection" ("id", "title", "handle", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: product_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_option" ("id", "title", "product_id", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
opt_01KPVEFMENJBG16HAQ7XA79A5B	Size	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N
opt_01KPVEFMEPMYH953JPEX24TAG9	Color	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
opt_01KPVEFMETKZ70P5T1NQ0DRFZ8	Size	prod_01KPVEFMEJ4N6R7MXZREAQHD71	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
opt_01KPVEFMEV43GK5E74GW1RXBA8	Size	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
opt_01KPVEFMEWJNNZV3DW943FVGYS	Size	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
opt_01KPXRBR77D6EYC5EQYRQN0FMR	Size	prod_01KPXRBR70C8XC3EDBSQGV2ZQX	\N	2026-04-23 20:06:46.507+02	2026-04-23 20:06:46.507+02	\N
opt_01KPXRBRHFV5QR44VPJR8M3368	Size	prod_01KPXRBRHECSVT8SMF2Q4JW4FK	\N	2026-04-23 20:06:46.833+02	2026-04-23 20:06:46.833+02	\N
opt_01KPXRBRRPPZT0J120CTFF4VRJ	Size	prod_01KPXRBRRK9B6E3N6RP56QPRQK	\N	2026-04-23 20:06:47.064+02	2026-04-23 20:06:47.064+02	\N
opt_01KPXRBRYXAEB9FQC9T0MP1GJV	Size	prod_01KPXRBRYWCZVEY55DAKQVHF0Z	\N	2026-04-23 20:06:47.261+02	2026-04-23 20:06:47.261+02	\N
opt_01KPXRBS8JP0AFQKYCC7J9785E	Size	prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	\N	2026-04-23 20:06:47.571+02	2026-04-23 20:06:47.571+02	\N
opt_01KPXRBSEQX8RAVASRRTN7QBYY	Size	prod_01KPXRBSEPKM19XQMQ37YETB3Q	\N	2026-04-23 20:06:47.767+02	2026-04-23 20:06:47.767+02	\N
\.


--
-- Data for Name: product_option_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_option_value" ("id", "value", "option_id", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
optval_01KPVEFMENSTGDCW2BAKWXW3BT	S	opt_01KPVEFMENJBG16HAQ7XA79A5B	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N
optval_01KPVEFMENXQEFW8PMCY7EJE3G	M	opt_01KPVEFMENJBG16HAQ7XA79A5B	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N
optval_01KPVEFMEN6N7NR3BWQDZ31RV5	L	opt_01KPVEFMENJBG16HAQ7XA79A5B	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N
optval_01KPVEFMENSSAQ1XXMRCNPGHCM	XL	opt_01KPVEFMENJBG16HAQ7XA79A5B	\N	2026-04-22 22:35:39.103+02	2026-04-22 22:35:39.103+02	\N
optval_01KPVEFMEPH3G8SE99Z6DX9GBC	Black	opt_01KPVEFMEPMYH953JPEX24TAG9	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEPSZFF5XKN0YDS258G	White	opt_01KPVEFMEPMYH953JPEX24TAG9	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMESCC1K3PJ3FH9N3P6Q	S	opt_01KPVEFMETKZ70P5T1NQ0DRFZ8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMESRAGRFZCXZVVJTWA5	M	opt_01KPVEFMETKZ70P5T1NQ0DRFZ8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMESFR62SKB7FAETY2QM	L	opt_01KPVEFMETKZ70P5T1NQ0DRFZ8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMESXF7ESDRBPKGRECRR	XL	opt_01KPVEFMETKZ70P5T1NQ0DRFZ8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEVSK7N3558S1QHQ1GY	S	opt_01KPVEFMEV43GK5E74GW1RXBA8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEVB1FSBMKF9TB5C0MA	M	opt_01KPVEFMEV43GK5E74GW1RXBA8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEVPCEDEX9AWZCY5HZ1	L	opt_01KPVEFMEV43GK5E74GW1RXBA8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEV8TBHXS8WWE2QTRPF	XL	opt_01KPVEFMEV43GK5E74GW1RXBA8	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEWHM3V31A8QRG2N8G3	S	opt_01KPVEFMEWJNNZV3DW943FVGYS	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEWSD6VD812YMVZMR2D	M	opt_01KPVEFMEWJNNZV3DW943FVGYS	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEWM0GXTVPQ1604CXF6	L	opt_01KPVEFMEWJNNZV3DW943FVGYS	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPVEFMEW3JTY91K0D4H6S6H8	XL	opt_01KPVEFMEWJNNZV3DW943FVGYS	\N	2026-04-22 22:35:39.104+02	2026-04-22 22:35:39.104+02	\N
optval_01KPXRBR77TFE09ECZ6G5JS94M	One Size	opt_01KPXRBR77D6EYC5EQYRQN0FMR	\N	2026-04-23 20:06:46.507+02	2026-04-23 20:06:46.507+02	\N
optval_01KPXRBRHF1SZNZYPBNB5Z0YH2	One Size	opt_01KPXRBRHFV5QR44VPJR8M3368	\N	2026-04-23 20:06:46.834+02	2026-04-23 20:06:46.834+02	\N
optval_01KPXRBRRN20G5YQ8CAN1G3ZZR	One Size	opt_01KPXRBRRPPZT0J120CTFF4VRJ	\N	2026-04-23 20:06:47.064+02	2026-04-23 20:06:47.064+02	\N
optval_01KPXRBRYWDC1M1M1C106DS56G	One Size	opt_01KPXRBRYXAEB9FQC9T0MP1GJV	\N	2026-04-23 20:06:47.261+02	2026-04-23 20:06:47.261+02	\N
optval_01KPXRBS8HT5015NTXZS511H6A	One Size	opt_01KPXRBS8JP0AFQKYCC7J9785E	\N	2026-04-23 20:06:47.571+02	2026-04-23 20:06:47.571+02	\N
optval_01KPXRBSEQ7MW6D549XMPBSME8	One Size	opt_01KPXRBSEQX8RAVASRRTN7QBYY	\N	2026-04-23 20:06:47.767+02	2026-04-23 20:06:47.767+02	\N
\.


--
-- Data for Name: product_sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_sales_channel" ("product_id", "sales_channel_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPVEFMG4Q9YABQTV3S6TFHD6	2026-04-22 22:35:39.139496+02	2026-04-22 22:35:39.139496+02	\N
prod_01KPVEFMEJ4N6R7MXZREAQHD71	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPVEFMG5A4HHV0A37CRQG6CK	2026-04-22 22:35:39.139496+02	2026-04-22 22:35:39.139496+02	\N
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPVEFMG5W7SQ487Y9MQRBC3Z	2026-04-22 22:35:39.139496+02	2026-04-22 22:35:39.139496+02	\N
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPVEFMG5EX2RB46ZS5PDWYMJ	2026-04-22 22:35:39.139496+02	2026-04-22 22:35:39.139496+02	\N
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBR8EMC9WM4CF5X195F32	2026-04-23 20:06:46.541192+02	2026-04-23 20:06:46.541192+02	\N
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBRJAASBXSB09HSPX91SP	2026-04-23 20:06:46.857609+02	2026-04-23 20:06:46.857609+02	\N
prod_01KPXRBRRK9B6E3N6RP56QPRQK	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBRSCNCGPG65TR62NH989	2026-04-23 20:06:47.083207+02	2026-04-23 20:06:47.083207+02	\N
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBRZG1F4EZQNJGFF76J7M	2026-04-23 20:06:47.279565+02	2026-04-23 20:06:47.279565+02	\N
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBS9DSHRWXX19ZF4CGZAP	2026-04-23 20:06:47.597105+02	2026-04-23 20:06:47.597105+02	\N
prod_01KPXRBSEPKM19XQMQ37YETB3Q	sc_01KPVEFEV595D4YCDP15QR7DDX	prodsc_01KPXRBSG62PV1NB9K19P7GZS7	2026-04-23 20:06:47.81328+02	2026-04-23 20:06:47.81328+02	\N
\.


--
-- Data for Name: product_shipping_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_shipping_profile" ("product_id", "shipping_profile_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPVEFMGP1TG159XC27YNXF4W	2026-04-22 22:35:39.157898+02	2026-04-22 22:35:39.157898+02	\N
prod_01KPVEFMEJ4N6R7MXZREAQHD71	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPVEFMGQYV1ZJ24SS7AAMGK5	2026-04-22 22:35:39.157898+02	2026-04-22 22:35:39.157898+02	\N
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPVEFMGQ4PV29SR9TT244CC3	2026-04-22 22:35:39.157898+02	2026-04-22 22:35:39.157898+02	\N
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPVEFMGQXZ43PQSTHGG04DKR	2026-04-22 22:35:39.157898+02	2026-04-22 22:35:39.157898+02	\N
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBR9EGRV0Q8AKCDE3XS98	2026-04-23 20:06:46.574007+02	2026-04-23 20:06:46.574007+02	\N
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBRJP55W89Z6PJ0JNRJN3	2026-04-23 20:06:46.869906+02	2026-04-23 20:06:46.869906+02	\N
prod_01KPXRBRRK9B6E3N6RP56QPRQK	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBRSZ443MJSBXWSPVV0DZ	2026-04-23 20:06:47.100519+02	2026-04-23 20:06:47.100519+02	\N
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBRZTER3VMM672GAC41Z7	2026-04-23 20:06:47.289824+02	2026-04-23 20:06:47.289824+02	\N
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBS9RYY096QBG83CKEWJM	2026-04-23 20:06:47.607698+02	2026-04-23 20:06:47.607698+02	\N
prod_01KPXRBSEPKM19XQMQ37YETB3Q	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	prodsp_01KPXRBSGKBNZFX1RYD1KK0MRJ	2026-04-23 20:06:47.82619+02	2026-04-23 20:06:47.82619+02	\N
\.


--
-- Data for Name: product_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_tag" ("id", "value", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP	season-pick	\N	2026-04-23 21:22:08.896+02	2026-04-23 21:22:08.896+02	\N
ptag_01KPXWNRQ262CMT0CTZ6AQTFHF	designer-pick	\N	2026-04-23 21:22:08.994+02	2026-04-23 21:22:08.994+02	\N
\.


--
-- Data for Name: product_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_tags" ("product_id", "product_tag_id") FROM stdin;
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPVEFMEHWRKFH07N2Q5W9PF9	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPVEFMEJ4N6R7MXZREAQHD71	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPVEFMEJ4N6R7MXZREAQHD71	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBR70C8XC3EDBSQGV2ZQX	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBRHECSVT8SMF2Q4JW4FK	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBRRK9B6E3N6RP56QPRQK	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBRRK9B6E3N6RP56QPRQK	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBRYWCZVEY55DAKQVHF0Z	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
prod_01KPXRBSEPKM19XQMQ37YETB3Q	ptag_01KPXWNRKZJABZ6VT8ZR7NC3TP
prod_01KPXRBSEPKM19XQMQ37YETB3Q	ptag_01KPXWNRQ262CMT0CTZ6AQTFHF
\.


--
-- Data for Name: product_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_type" ("id", "value", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: product_variant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_variant" ("id", "title", "sku", "barcode", "ean", "upc", "allow_backorder", "manage_inventory", "hs_code", "origin_country", "mid_code", "material", "weight", "length", "height", "width", "metadata", "variant_rank", "product_id", "created_at", "updated_at", "deleted_at", "thumbnail") FROM stdin;
variant_01KPVEFMJ0PAC67DG1FTDR18QX	S / Black	SHIRT-S-BLACK	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.207+02	2026-04-22 22:35:39.207+02	\N	\N
variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	S / White	SHIRT-S-WHITE	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.207+02	2026-04-22 22:35:39.207+02	\N	\N
variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	M / Black	SHIRT-M-BLACK	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.207+02	2026-04-22 22:35:39.207+02	\N	\N
variant_01KPVEFMJ1QR9HV5NMQ4VAFKHP	M / White	SHIRT-M-WHITE	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ25K2SZV2CDH4P5VCB	L / Black	SHIRT-L-BLACK	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ2V8NZ7ZX7GRE63QPM	L / White	SHIRT-L-WHITE	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ2H4QKW3JGQJNKBV4M	XL / Black	SHIRT-XL-BLACK	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ3B0Q4BG1HDKE283MX	XL / White	SHIRT-XL-WHITE	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEHWRKFH07N2Q5W9PF9	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ3Q5ZKMZDA4H83A2BK	S	SWEATSHIRT-S	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4N6R7MXZREAQHD71	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ4C7BRKMWEG2N95NQS	M	SWEATSHIRT-M	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4N6R7MXZREAQHD71	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ4WK9RXVWT21SKYDES	L	SWEATSHIRT-L	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4N6R7MXZREAQHD71	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ4RWXNG0ZHBW24MSXR	XL	SWEATSHIRT-XL	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4N6R7MXZREAQHD71	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ4Q1JME3NNCHWHJHE8	S	SWEATPANTS-S	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ5SX27H0G6030CK56K	M	SWEATPANTS-M	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ51YXYD2QGPPA6BZD9	L	SWEATPANTS-L	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ5NGRX52JSA5EZMF1M	XL	SWEATPANTS-XL	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJ4EAZQ0RAZG96KEKW	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ580E2HPQR5VZ0DYXH	S	SHORTS-S	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ52T75APAXT1961VE5	M	SHORTS-M	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ6HYMRDT21HFF4V4KC	L	SHORTS-L	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPVEFMJ6Z9Z2QYYWEXBDBC76	XL	SHORTS-XL	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPVEFMEJJVJAJJ25FQ1CF4QP	2026-04-22 22:35:39.208+02	2026-04-22 22:35:39.208+02	\N	\N
variant_01KPXRBRAN25XK07W7JG1S17KG	Default	classic-tee-white-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBR70C8XC3EDBSQGV2ZQX	2026-04-23 20:06:46.613+02	2026-04-23 20:06:46.613+02	\N	\N
variant_01KPXRBRKQZ5TTMRGXRBMQ0TDS	Default	longsleeve-tee-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBRHECSVT8SMF2Q4JW4FK	2026-04-23 20:06:46.904+02	2026-04-23 20:06:46.904+02	\N	\N
variant_01KPXRBRTQWQE0X1KTKNT3PRB3	Default	crewneck-sweatshirt-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBRRK9B6E3N6RP56QPRQK	2026-04-23 20:06:47.127+02	2026-04-23 20:06:47.127+02	\N	\N
variant_01KPXRBS0QBR0P035YVW8PXS9R	Default	jogger-pants-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBRYWCZVEY55DAKQVHF0Z	2026-04-23 20:06:47.321+02	2026-04-23 20:06:47.321+02	\N	\N
variant_01KPXRBSAJTV3NYMPAC42S0J8G	Default	tote-bag-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBS8GKPXRGEK4S01NZ7CQ	2026-04-23 20:06:47.635+02	2026-04-23 20:06:47.635+02	\N	\N
variant_01KPXRBSHGFVH2RF7KEY817XPX	Default	baseball-cap-default	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KPXRBSEPKM19XQMQ37YETB3Q	2026-04-23 20:06:47.857+02	2026-04-23 20:06:47.857+02	\N	\N
\.


--
-- Data for Name: product_variant_inventory_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_variant_inventory_item" ("variant_id", "inventory_item_id", "id", "required_quantity", "created_at", "updated_at", "deleted_at") FROM stdin;
variant_01KPVEFMJ0PAC67DG1FTDR18QX	iitem_01KPVEFMKN698MJE0HPEGDEECQ	pvitem_01KPVEFMMT7BFMF1RSRPX5N4Y3	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	iitem_01KPVEFMKN4RKQE3P33YHPEQS3	pvitem_01KPVEFMMVN33WB82WSJ36P2R3	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	iitem_01KPVEFMKPAZEYXJDKZHAPD0CS	pvitem_01KPVEFMMW72V7V03AH6E2T2AC	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ1QR9HV5NMQ4VAFKHP	iitem_01KPVEFMKP6MZZ3YWE0GETDDAR	pvitem_01KPVEFMMW9W7JT9XCPFH28HVD	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ25K2SZV2CDH4P5VCB	iitem_01KPVEFMKP80HC4FERJKDERW35	pvitem_01KPVEFMMW9EXF896AD3HMSN9G	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ2V8NZ7ZX7GRE63QPM	iitem_01KPVEFMKPG5ZXJ3Q6WBCB06TR	pvitem_01KPVEFMMWDFR4V1HR3QYMBVE3	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ2H4QKW3JGQJNKBV4M	iitem_01KPVEFMKPFXCDVT1PAM6D2BAN	pvitem_01KPVEFMMW9YT3PZCTC373QDYJ	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ3B0Q4BG1HDKE283MX	iitem_01KPVEFMKPANETGHXVGRA19SZ6	pvitem_01KPVEFMMW6SEPEDNT3Z1W75FK	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ3Q5ZKMZDA4H83A2BK	iitem_01KPVEFMKQH0CYM8BVQDH1RNGD	pvitem_01KPVEFMMX3Q6TFQEGF4M5VMD7	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ4C7BRKMWEG2N95NQS	iitem_01KPVEFMKQPY3M6D7PEDGMEVE1	pvitem_01KPVEFMMX41YY04VPGBH2TN8R	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ4WK9RXVWT21SKYDES	iitem_01KPVEFMKQCTZSX3G3EVJ5ANMC	pvitem_01KPVEFMMXP2PPRXAZ0STZWKNH	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ4RWXNG0ZHBW24MSXR	iitem_01KPVEFMKRWBWNVE1H4FC2SFTS	pvitem_01KPVEFMMXVBXM71GX6S18GBZS	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ4Q1JME3NNCHWHJHE8	iitem_01KPVEFMKR02X4TXEXW601KVC3	pvitem_01KPVEFMMX0NBR4F37HRJVHW5D	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ5SX27H0G6030CK56K	iitem_01KPVEFMKR75ZHS7GX9JQH3MQS	pvitem_01KPVEFMMXXPTVSAGSN57GABTN	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ51YXYD2QGPPA6BZD9	iitem_01KPVEFMKR6BS8EWFF6B8VMPXT	pvitem_01KPVEFMMX44GV439B9XTK99W3	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ5NGRX52JSA5EZMF1M	iitem_01KPVEFMKSF5V6C31RX26MEX9T	pvitem_01KPVEFMMYE5JSKH63M988WWGY	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ580E2HPQR5VZ0DYXH	iitem_01KPVEFMKS1JRH9JS7QJZ0D5M7	pvitem_01KPVEFMMYMQ49410TGDG00A6Y	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ52T75APAXT1961VE5	iitem_01KPVEFMKS3AAFP71BFK77RDS1	pvitem_01KPVEFMMY95JH430ZCPCW0DSQ	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ6HYMRDT21HFF4V4KC	iitem_01KPVEFMKS3XS0V9HWQS8R8GE7	pvitem_01KPVEFMMYAMJSCDSCNG3GK25A	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
variant_01KPVEFMJ6Z9Z2QYYWEXBDBC76	iitem_01KPVEFMKS0695AGEZHASTP9HV	pvitem_01KPVEFMMYZE19S2ZZEHJJY9BK	1	2026-04-22 22:35:39.290171+02	2026-04-22 22:35:39.290171+02	\N
\.


--
-- Data for Name: product_variant_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_variant_option" ("variant_id", "option_value_id") FROM stdin;
variant_01KPVEFMJ0PAC67DG1FTDR18QX	optval_01KPVEFMENSTGDCW2BAKWXW3BT
variant_01KPVEFMJ0PAC67DG1FTDR18QX	optval_01KPVEFMEPH3G8SE99Z6DX9GBC
variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	optval_01KPVEFMENSTGDCW2BAKWXW3BT
variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	optval_01KPVEFMEPSZFF5XKN0YDS258G
variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	optval_01KPVEFMENXQEFW8PMCY7EJE3G
variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	optval_01KPVEFMEPH3G8SE99Z6DX9GBC
variant_01KPVEFMJ1QR9HV5NMQ4VAFKHP	optval_01KPVEFMENXQEFW8PMCY7EJE3G
variant_01KPVEFMJ1QR9HV5NMQ4VAFKHP	optval_01KPVEFMEPSZFF5XKN0YDS258G
variant_01KPVEFMJ25K2SZV2CDH4P5VCB	optval_01KPVEFMEN6N7NR3BWQDZ31RV5
variant_01KPVEFMJ25K2SZV2CDH4P5VCB	optval_01KPVEFMEPH3G8SE99Z6DX9GBC
variant_01KPVEFMJ2V8NZ7ZX7GRE63QPM	optval_01KPVEFMEN6N7NR3BWQDZ31RV5
variant_01KPVEFMJ2V8NZ7ZX7GRE63QPM	optval_01KPVEFMEPSZFF5XKN0YDS258G
variant_01KPVEFMJ2H4QKW3JGQJNKBV4M	optval_01KPVEFMENSSAQ1XXMRCNPGHCM
variant_01KPVEFMJ2H4QKW3JGQJNKBV4M	optval_01KPVEFMEPH3G8SE99Z6DX9GBC
variant_01KPVEFMJ3B0Q4BG1HDKE283MX	optval_01KPVEFMENSSAQ1XXMRCNPGHCM
variant_01KPVEFMJ3B0Q4BG1HDKE283MX	optval_01KPVEFMEPSZFF5XKN0YDS258G
variant_01KPVEFMJ3Q5ZKMZDA4H83A2BK	optval_01KPVEFMESCC1K3PJ3FH9N3P6Q
variant_01KPVEFMJ4C7BRKMWEG2N95NQS	optval_01KPVEFMESRAGRFZCXZVVJTWA5
variant_01KPVEFMJ4WK9RXVWT21SKYDES	optval_01KPVEFMESFR62SKB7FAETY2QM
variant_01KPVEFMJ4RWXNG0ZHBW24MSXR	optval_01KPVEFMESXF7ESDRBPKGRECRR
variant_01KPVEFMJ4Q1JME3NNCHWHJHE8	optval_01KPVEFMEVSK7N3558S1QHQ1GY
variant_01KPVEFMJ5SX27H0G6030CK56K	optval_01KPVEFMEVB1FSBMKF9TB5C0MA
variant_01KPVEFMJ51YXYD2QGPPA6BZD9	optval_01KPVEFMEVPCEDEX9AWZCY5HZ1
variant_01KPVEFMJ5NGRX52JSA5EZMF1M	optval_01KPVEFMEV8TBHXS8WWE2QTRPF
variant_01KPVEFMJ580E2HPQR5VZ0DYXH	optval_01KPVEFMEWHM3V31A8QRG2N8G3
variant_01KPVEFMJ52T75APAXT1961VE5	optval_01KPVEFMEWSD6VD812YMVZMR2D
variant_01KPVEFMJ6HYMRDT21HFF4V4KC	optval_01KPVEFMEWM0GXTVPQ1604CXF6
variant_01KPVEFMJ6Z9Z2QYYWEXBDBC76	optval_01KPVEFMEW3JTY91K0D4H6S6H8
variant_01KPXRBRAN25XK07W7JG1S17KG	optval_01KPXRBR77TFE09ECZ6G5JS94M
variant_01KPXRBRKQZ5TTMRGXRBMQ0TDS	optval_01KPXRBRHF1SZNZYPBNB5Z0YH2
variant_01KPXRBRTQWQE0X1KTKNT3PRB3	optval_01KPXRBRRN20G5YQ8CAN1G3ZZR
variant_01KPXRBS0QBR0P035YVW8PXS9R	optval_01KPXRBRYWDC1M1M1C106DS56G
variant_01KPXRBSAJTV3NYMPAC42S0J8G	optval_01KPXRBS8HT5015NTXZS511H6A
variant_01KPXRBSHGFVH2RF7KEY817XPX	optval_01KPXRBSEQ7MW6D549XMPBSME8
\.


--
-- Data for Name: product_variant_price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_variant_price_set" ("variant_id", "price_set_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
variant_01KPVEFMJ0PAC67DG1FTDR18QX	pset_01KPVEFMNGRCFZ6VGS425R599R	pvps_01KPVEFMQTGNF1GM6F11YAKXGS	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ03MYG7EM57C6Y2Y6B	pset_01KPVEFMNHBA5BVB8NDCWKJBND	pvps_01KPVEFMQVRB81CX4ZQRQWDJ7H	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ1HNRT3FEDNGXBVEE6	pset_01KPVEFMNHF1JZHB22EK67PRBV	pvps_01KPVEFMQW15015FPSCNJ59YSJ	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ1QR9HV5NMQ4VAFKHP	pset_01KPVEFMNJW99ZZ8H8C2READ0V	pvps_01KPVEFMQW6EZ4T8BZ56RCP05A	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ25K2SZV2CDH4P5VCB	pset_01KPVEFMNJEVR2TN22MA4711VM	pvps_01KPVEFMQW7GJBWZRYKRGHKK0R	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ2V8NZ7ZX7GRE63QPM	pset_01KPVEFMNK2WGGN7ND0WTBTY48	pvps_01KPVEFMQW0TRAXMNHSVGB17J6	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ2H4QKW3JGQJNKBV4M	pset_01KPVEFMNKFBJSSKPMPZ06H5YV	pvps_01KPVEFMQWPM73J432BTERZGQQ	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ3B0Q4BG1HDKE283MX	pset_01KPVEFMNMYKTSAS6WKSTPCHYQ	pvps_01KPVEFMQXTX8WXMGD98A9SWQ7	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ3Q5ZKMZDA4H83A2BK	pset_01KPVEFMNMCF9CPSKCVD8HKWG4	pvps_01KPVEFMQXD41YND5KBRBYF1GS	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ4C7BRKMWEG2N95NQS	pset_01KPVEFMNN9BKKZ9VCH93SPX8N	pvps_01KPVEFMQXECTBGH67JC0HMW4X	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ4WK9RXVWT21SKYDES	pset_01KPVEFMNN2X0V74G5CW0QVG4G	pvps_01KPVEFMQXVGWA1B7FXXC78SY1	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ4RWXNG0ZHBW24MSXR	pset_01KPVEFMNP8K5CWYA6SMDZEM91	pvps_01KPVEFMQY3BFB4X5FTGBQ7BCJ	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ4Q1JME3NNCHWHJHE8	pset_01KPVEFMNP99CVCKY9KB1KDBAH	pvps_01KPVEFMQYD04HYEC77XHX5Y64	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ5SX27H0G6030CK56K	pset_01KPVEFMNQYWDWJ3G1G7ZG4DQV	pvps_01KPVEFMQYE7572NADR3F96N17	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ51YXYD2QGPPA6BZD9	pset_01KPVEFMNQJBGFZ59Z1WQS1GR8	pvps_01KPVEFMQYBNK9A5SWGT389FSP	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ5NGRX52JSA5EZMF1M	pset_01KPVEFMNRBYXTB761XRJB6TTK	pvps_01KPVEFMQYTZ5HS6FXJ914NVFG	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ580E2HPQR5VZ0DYXH	pset_01KPVEFMNRC4RHTF0E442QXM7N	pvps_01KPVEFMQZP1764EZA2WPK63N3	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ52T75APAXT1961VE5	pset_01KPVEFMNS9K8M35QQTG012Y9J	pvps_01KPVEFMQZ1SZVJ99KVHNNMZ1E	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ6HYMRDT21HFF4V4KC	pset_01KPVEFMNSSG99XP81Q8ZQQ3CS	pvps_01KPVEFMQZNN6X7V5JW79Z797W	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPVEFMJ6Z9Z2QYYWEXBDBC76	pset_01KPVEFMNSBHWDK9G383SSCKKK	pvps_01KPVEFMQZGG1J0AG540DBJXH4	2026-04-22 22:35:39.384515+02	2026-04-22 22:35:39.384515+02	\N
variant_01KPXRBRAN25XK07W7JG1S17KG	pset_01KPXRBRCR9KJGB3MHRWXM9ZE1	pvps_01KPXRBRDN5JFPKYA37PN5N9DW	2026-04-23 20:06:46.708661+02	2026-04-23 20:06:46.708661+02	\N
variant_01KPXRBRKQZ5TTMRGXRBMQ0TDS	pset_01KPXRBRMYDJG7DVMDAPRH64G2	pvps_01KPXRBRNK6VJC84CMK74P5J0F	2026-04-23 20:06:46.963239+02	2026-04-23 20:06:46.963239+02	\N
variant_01KPXRBRTQWQE0X1KTKNT3PRB3	pset_01KPXRBRVKGKR4REHQJG6B7ACG	pvps_01KPXRBRWBE2Y6PJTDXQJ003G2	2026-04-23 20:06:47.17872+02	2026-04-23 20:06:47.17872+02	\N
variant_01KPXRBS0QBR0P035YVW8PXS9R	pset_01KPXRBS248HT0VM2M33Y4G43N	pvps_01KPXRBS4P8HD2PTMFRX3AHDH1	2026-04-23 20:06:47.44607+02	2026-04-23 20:06:47.44607+02	\N
variant_01KPXRBSAJTV3NYMPAC42S0J8G	pset_01KPXRBSBRRN5S9VBY39YVB2Z9	pvps_01KPXRBSCA7VY0G52TF4RJHGKW	2026-04-23 20:06:47.689333+02	2026-04-23 20:06:47.689333+02	\N
variant_01KPXRBSHGFVH2RF7KEY817XPX	pset_01KPXRBSJESFNPHBAY7KTYX9TK	pvps_01KPXRBSK2QZDX0WFP3XEVY1CB	2026-04-23 20:06:47.906257+02	2026-04-23 20:06:47.906257+02	\N
\.


--
-- Data for Name: product_variant_product_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."product_variant_product_image" ("id", "variant_id", "image_id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion" ("id", "code", "campaign_id", "is_automatic", "type", "created_at", "updated_at", "deleted_at", "status", "is_tax_inclusive", "limit", "used", "metadata") FROM stdin;
\.


--
-- Data for Name: promotion_application_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_application_method" ("id", "value", "raw_value", "max_quantity", "apply_to_quantity", "buy_rules_min_quantity", "type", "target_type", "allocation", "promotion_id", "created_at", "updated_at", "deleted_at", "currency_code") FROM stdin;
\.


--
-- Data for Name: promotion_campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_campaign" ("id", "name", "description", "campaign_identifier", "starts_at", "ends_at", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: promotion_campaign_budget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_campaign_budget" ("id", "type", "campaign_id", "limit", "raw_limit", "used", "raw_used", "created_at", "updated_at", "deleted_at", "currency_code", "attribute") FROM stdin;
\.


--
-- Data for Name: promotion_campaign_budget_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_campaign_budget_usage" ("id", "attribute_value", "used", "budget_id", "raw_used", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: promotion_promotion_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_promotion_rule" ("promotion_id", "promotion_rule_id") FROM stdin;
\.


--
-- Data for Name: promotion_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_rule" ("id", "description", "attribute", "operator", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: promotion_rule_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."promotion_rule_value" ("id", "promotion_rule_id", "value", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: provider_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."provider_identity" ("id", "entity_id", "provider", "auth_identity_id", "user_metadata", "provider_metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
01KPVERWVMZSWGJDWEPY2JKERV	fate6317@gmail.com	emailpass	authid_01KPVERWVNVNA6VJQ5S6S5N5GC	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAfuWgXZ8rt9wnWw/q3TNg4q0VuHTDaDSPTQEnqgHOsWCHqDe5DY4zY6Pofr1McQk0ZI3AGtloGd81H0Jni/CoJyqhugDBJ4VB5mWT6vPyI5T"}	2026-04-22 22:40:42.614+02	2026-04-22 22:40:42.614+02	\N
01KPX6FX6XBSA40PRJWC23NT1J	test1776948867237@example.com	emailpass	authid_01KPX6FX6Y7JE238FC0KMBR0R3	\N	{"password": "c2NyeXB0AA8AAAAIAAAAATg8DGrzURkhIQiLOHqy2/1ENAhfuydU2tT1Me+O/BXdkT8dszfEEC0mEhsnZ7SEm4s3Wq7FRDcLhFMTERfq1zTCN/19i7r47fcgvlY7bT4T"}	2026-04-23 14:54:28.319+02	2026-04-23 14:54:28.319+02	\N
01KPX7HJRR5TDQ4X32M62HZ9KN	test1776949970723@example.com	emailpass	authid_01KPX7HJRRC06NESXD578TBBKY	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAcisie2WGr/5gc2Rc6JeSWBjTGS+F2m9NAm0k1S0KVVUv+glvYy3nY5Iq6qXDhgC7vYfKz58H8A+/I69JWrZAxyej9QHAscrIc01HOCa0+PG"}	2026-04-23 15:12:51.737+02	2026-04-23 15:12:51.737+02	\N
01KPXNG0Y3HXTSD9WVG2658FTW	ken@test.com	emailpass	authid_01KPXNG0Y4D3Y9G31Z23P3MFFB	\N	{"password": "c2NyeXB0AA8AAAAIAAAAASKyNnWWIxUSfGDz9C7urd8zsNaT8pOICE+dM5wGayexwDOhMOguMti6dc1nbYlpgdTG5hU6kfFY8psQv62+cxaUzHadHwiMspaKDdvEANoe"}	2026-04-23 19:16:40.773+02	2026-04-23 19:16:40.773+02	\N
01KPXP4T78PMZ0VH89P2SXGTAP	test1776965276602@example.com	emailpass	authid_01KPXP4T79CHHYS94Z4K8C45A4	\N	{"password": "c2NyeXB0AA8AAAAIAAAAARozOws7XMc5UKTGNE9z2qc/K5JkJU01yS0dUrXGrgVy4HrqHZvO0ayFxRhgkYjiTZNBQpKA9Fs7W84V1v584BjpVGTwyWMcbCAvBzcygYaY"}	2026-04-23 19:28:02.029+02	2026-04-23 19:28:02.029+02	\N
01KPXP6C8C9C7WME17F34WM9R8	test1776965330252@example.com	emailpass	authid_01KPXP6C8D8B8ZK5Y6AZ2DD86C	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAdu1gvYGp0bRNqK+8E3nC0AtCx1s4SIcOvz9nWyfe/5ie6YHU0JvaWZQcSDktau1VMRzcKu1DwRE2HiTf3rlG+kq1yi2O25u3be/VkKgcqEK"}	2026-04-23 19:28:53.261+02	2026-04-23 19:28:53.261+02	\N
01KPXRKW81GJ8M2SM06HQ5XASF	e2e1776967842906@example.com	emailpass	authid_01KPXRKW88S0G1WT68EFNE19H7	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAV2G6TCn2PkHUBDfhvFy5j1xk4rcmLS8cuV9loXjx4T1xjS5WO1O/V39Hn7k2YIP3ivm17XIzfQO4wHD795bC1w6aBg9SQ22y8rHdALpA4Pn"}	2026-04-23 20:11:12.782+02	2026-04-23 20:11:12.782+02	\N
01KPXTR4EN3WX90JA5F0RQNY0G	e2e1776970101950@example.com	emailpass	authid_01KPXTR4EN2PZKHVZQ3HSCVKTJ	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAcB64PjAerPtzZ206onZNHfbtcpcJ4kEsDloPYax6SXlpt2omNnxUxfJ2SSLT2HsPX0TulyQLGUZ6H5ud+DZAiUO+6xYpyda8ap/bu8Np7NB"}	2026-04-23 20:48:29.398+02	2026-04-23 20:48:29.398+02	\N
\.


--
-- Data for Name: publishable_api_key_sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."publishable_api_key_sales_channel" ("publishable_key_id", "sales_channel_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
apk_01KPVEFEXD4T7AK78WP29SQT5F	sc_01KPVEFEV595D4YCDP15QR7DDX	pksc_01KPVEFMCXREJ6JGQVBF8KXGS2	2026-04-22 22:35:33.43832+02	2026-04-22 22:35:33.43832+02	\N
\.


--
-- Data for Name: refund; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."refund" ("id", "amount", "raw_amount", "payment_id", "created_at", "updated_at", "deleted_at", "created_by", "metadata", "refund_reason_id", "note") FROM stdin;
ref_01KPZVDFK4AET303ZA35AD5J95	30	{"value": "30", "precision": 20}	pay_01KPWECVYNNQ39CB87ZBENA1DG	2026-04-24 15:38:37.796+02	2026-04-24 15:38:37.796+02	\N	user_01KPVERWMYC488JMTY56E4HW5C	\N	\N	\N
\.


--
-- Data for Name: refund_reason; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."refund_reason" ("id", "label", "description", "metadata", "created_at", "updated_at", "deleted_at", "code") FROM stdin;
refr_01KPVEEZW2D2KM4H9QPVVFCR14	Shipping Issue	Refund due to lost, delayed, or misdelivered shipment	\N	2026-04-22 22:35:17.753702+02	2026-04-22 22:35:17.753702+02	\N	shipping_issue
refr_01KPVEEZW3FJQH7Y9KZ499GAHQ	Customer Care Adjustment	Refund given as goodwill or compensation for inconvenience	\N	2026-04-22 22:35:17.753702+02	2026-04-22 22:35:17.753702+02	\N	customer_care_adjustment
refr_01KPVEEZW3M6PSY32MMEZ40Z2H	Pricing Error	Refund to correct an overcharge, missing discount, or incorrect price	\N	2026-04-22 22:35:17.753702+02	2026-04-22 22:35:17.753702+02	\N	pricing_error
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."region" ("id", "name", "currency_code", "metadata", "created_at", "updated_at", "deleted_at", "automatic_taxes") FROM stdin;
reg_01KPZA4WP86M2QS4F7YPJY792P	Malaysia	myr	\N	2026-04-24 10:36:50.513+02	2026-04-24 10:36:50.513+02	\N	t
reg_01KPVEFKYDPAKWC7499ZXE0DY9	Europe	eur	\N	2026-04-22 22:35:38.597+02	2026-04-24 15:29:48.242+02	2026-04-24 15:29:48.24+02	t
\.


--
-- Data for Name: region_country; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."region_country" ("iso_2", "iso_3", "num_code", "name", "display_name", "region_id", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
af	afg	004	AFGHANISTAN	Afghanistan	\N	\N	2026-04-22 22:35:26.173+02	2026-04-22 22:35:26.173+02	\N
al	alb	008	ALBANIA	Albania	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
dz	dza	012	ALGERIA	Algeria	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
as	asm	016	AMERICAN SAMOA	American Samoa	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
ad	and	020	ANDORRA	Andorra	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
ao	ago	024	ANGOLA	Angola	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
ai	aia	660	ANGUILLA	Anguilla	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
aq	ata	010	ANTARCTICA	Antarctica	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
ag	atg	028	ANTIGUA AND BARBUDA	Antigua and Barbuda	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
ar	arg	032	ARGENTINA	Argentina	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
am	arm	051	ARMENIA	Armenia	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
aw	abw	533	ARUBA	Aruba	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
au	aus	036	AUSTRALIA	Australia	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
at	aut	040	AUSTRIA	Austria	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
az	aze	031	AZERBAIJAN	Azerbaijan	\N	\N	2026-04-22 22:35:26.175+02	2026-04-22 22:35:26.175+02	\N
bs	bhs	044	BAHAMAS	Bahamas	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bh	bhr	048	BAHRAIN	Bahrain	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bd	bgd	050	BANGLADESH	Bangladesh	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bb	brb	052	BARBADOS	Barbados	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
by	blr	112	BELARUS	Belarus	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
be	bel	056	BELGIUM	Belgium	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bz	blz	084	BELIZE	Belize	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bj	ben	204	BENIN	Benin	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bm	bmu	060	BERMUDA	Bermuda	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bt	btn	064	BHUTAN	Bhutan	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bo	bol	068	BOLIVIA	Bolivia	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bq	bes	535	BONAIRE, SINT EUSTATIUS AND SABA	Bonaire, Sint Eustatius and Saba	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
ba	bih	070	BOSNIA AND HERZEGOVINA	Bosnia and Herzegovina	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bw	bwa	072	BOTSWANA	Botswana	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bv	bvd	074	BOUVET ISLAND	Bouvet Island	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
br	bra	076	BRAZIL	Brazil	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
io	iot	086	BRITISH INDIAN OCEAN TERRITORY	British Indian Ocean Territory	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bn	brn	096	BRUNEI DARUSSALAM	Brunei Darussalam	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bg	bgr	100	BULGARIA	Bulgaria	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bf	bfa	854	BURKINA FASO	Burkina Faso	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
bi	bdi	108	BURUNDI	Burundi	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
kh	khm	116	CAMBODIA	Cambodia	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
cm	cmr	120	CAMEROON	Cameroon	\N	\N	2026-04-22 22:35:26.176+02	2026-04-22 22:35:26.176+02	\N
ca	can	124	CANADA	Canada	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cv	cpv	132	CAPE VERDE	Cape Verde	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
ky	cym	136	CAYMAN ISLANDS	Cayman Islands	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cf	caf	140	CENTRAL AFRICAN REPUBLIC	Central African Republic	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
td	tcd	148	CHAD	Chad	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cl	chl	152	CHILE	Chile	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cn	chn	156	CHINA	China	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cx	cxr	162	CHRISTMAS ISLAND	Christmas Island	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cc	cck	166	COCOS (KEELING) ISLANDS	Cocos (Keeling) Islands	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
co	col	170	COLOMBIA	Colombia	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
km	com	174	COMOROS	Comoros	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cg	cog	178	CONGO	Congo	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cd	cod	180	CONGO, THE DEMOCRATIC REPUBLIC OF THE	Congo, the Democratic Republic of the	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
ck	cok	184	COOK ISLANDS	Cook Islands	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cr	cri	188	COSTA RICA	Costa Rica	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
ci	civ	384	COTE D'IVOIRE	Cote D'Ivoire	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
hr	hrv	191	CROATIA	Croatia	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cu	cub	192	CUBA	Cuba	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cw	cuw	531	CURAÇAO	Curaçao	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cy	cyp	196	CYPRUS	Cyprus	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
cz	cze	203	CZECH REPUBLIC	Czech Republic	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
dj	dji	262	DJIBOUTI	Djibouti	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
dm	dma	212	DOMINICA	Dominica	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
do	dom	214	DOMINICAN REPUBLIC	Dominican Republic	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
ec	ecu	218	ECUADOR	Ecuador	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
eg	egy	818	EGYPT	Egypt	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
sv	slv	222	EL SALVADOR	El Salvador	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
gq	gnq	226	EQUATORIAL GUINEA	Equatorial Guinea	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
er	eri	232	ERITREA	Eritrea	\N	\N	2026-04-22 22:35:26.177+02	2026-04-22 22:35:26.177+02	\N
ee	est	233	ESTONIA	Estonia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
et	eth	231	ETHIOPIA	Ethiopia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
fk	flk	238	FALKLAND ISLANDS (MALVINAS)	Falkland Islands (Malvinas)	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
fo	fro	234	FAROE ISLANDS	Faroe Islands	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
fj	fji	242	FIJI	Fiji	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
fi	fin	246	FINLAND	Finland	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gf	guf	254	FRENCH GUIANA	French Guiana	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
pf	pyf	258	FRENCH POLYNESIA	French Polynesia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
tf	atf	260	FRENCH SOUTHERN TERRITORIES	French Southern Territories	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
ga	gab	266	GABON	Gabon	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gm	gmb	270	GAMBIA	Gambia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
ge	geo	268	GEORGIA	Georgia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gh	gha	288	GHANA	Ghana	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gi	gib	292	GIBRALTAR	Gibraltar	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gr	grc	300	GREECE	Greece	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gl	grl	304	GREENLAND	Greenland	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gd	grd	308	GRENADA	Grenada	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gp	glp	312	GUADELOUPE	Guadeloupe	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gu	gum	316	GUAM	Guam	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gt	gtm	320	GUATEMALA	Guatemala	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gg	ggy	831	GUERNSEY	Guernsey	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gn	gin	324	GUINEA	Guinea	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gw	gnb	624	GUINEA-BISSAU	Guinea-Bissau	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
gy	guy	328	GUYANA	Guyana	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
ht	hti	332	HAITI	Haiti	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
hm	hmd	334	HEARD ISLAND AND MCDONALD ISLANDS	Heard Island And Mcdonald Islands	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
va	vat	336	HOLY SEE (VATICAN CITY STATE)	Holy See (Vatican City State)	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
hn	hnd	340	HONDURAS	Honduras	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
hk	hkg	344	HONG KONG	Hong Kong	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
hu	hun	348	HUNGARY	Hungary	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
is	isl	352	ICELAND	Iceland	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
in	ind	356	INDIA	India	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
id	idn	360	INDONESIA	Indonesia	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
ir	irn	364	IRAN, ISLAMIC REPUBLIC OF	Iran, Islamic Republic of	\N	\N	2026-04-22 22:35:26.178+02	2026-04-22 22:35:26.178+02	\N
iq	irq	368	IRAQ	Iraq	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ie	irl	372	IRELAND	Ireland	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
im	imn	833	ISLE OF MAN	Isle Of Man	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
il	isr	376	ISRAEL	Israel	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
jm	jam	388	JAMAICA	Jamaica	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
jp	jpn	392	JAPAN	Japan	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
je	jey	832	JERSEY	Jersey	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
jo	jor	400	JORDAN	Jordan	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
kz	kaz	398	KAZAKHSTAN	Kazakhstan	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ke	ken	404	KENYA	Kenya	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ki	kir	296	KIRIBATI	Kiribati	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
kp	prk	408	KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF	Korea, Democratic People's Republic of	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
kr	kor	410	KOREA, REPUBLIC OF	Korea, Republic of	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
xk	xkx	900	KOSOVO	Kosovo	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
kw	kwt	414	KUWAIT	Kuwait	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
kg	kgz	417	KYRGYZSTAN	Kyrgyzstan	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
la	lao	418	LAO PEOPLE'S DEMOCRATIC REPUBLIC	Lao People's Democratic Republic	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
lv	lva	428	LATVIA	Latvia	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
lb	lbn	422	LEBANON	Lebanon	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ls	lso	426	LESOTHO	Lesotho	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
lr	lbr	430	LIBERIA	Liberia	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ly	lby	434	LIBYA	Libya	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
li	lie	438	LIECHTENSTEIN	Liechtenstein	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
lt	ltu	440	LITHUANIA	Lithuania	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
lu	lux	442	LUXEMBOURG	Luxembourg	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mo	mac	446	MACAO	Macao	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mg	mdg	450	MADAGASCAR	Madagascar	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mw	mwi	454	MALAWI	Malawi	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mv	mdv	462	MALDIVES	Maldives	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
ml	mli	466	MALI	Mali	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mt	mlt	470	MALTA	Malta	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mh	mhl	584	MARSHALL ISLANDS	Marshall Islands	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mq	mtq	474	MARTINIQUE	Martinique	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mr	mrt	478	MAURITANIA	Mauritania	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mu	mus	480	MAURITIUS	Mauritius	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
yt	myt	175	MAYOTTE	Mayotte	\N	\N	2026-04-22 22:35:26.179+02	2026-04-22 22:35:26.179+02	\N
mx	mex	484	MEXICO	Mexico	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
fm	fsm	583	MICRONESIA, FEDERATED STATES OF	Micronesia, Federated States of	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
md	mda	498	MOLDOVA, REPUBLIC OF	Moldova, Republic of	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mc	mco	492	MONACO	Monaco	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mn	mng	496	MONGOLIA	Mongolia	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
me	mne	499	MONTENEGRO	Montenegro	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ms	msr	500	MONTSERRAT	Montserrat	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ma	mar	504	MOROCCO	Morocco	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mz	moz	508	MOZAMBIQUE	Mozambique	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mm	mmr	104	MYANMAR	Myanmar	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
na	nam	516	NAMIBIA	Namibia	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nr	nru	520	NAURU	Nauru	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
np	npl	524	NEPAL	Nepal	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nl	nld	528	NETHERLANDS	Netherlands	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nc	ncl	540	NEW CALEDONIA	New Caledonia	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nz	nzl	554	NEW ZEALAND	New Zealand	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ni	nic	558	NICARAGUA	Nicaragua	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ne	ner	562	NIGER	Niger	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ng	nga	566	NIGERIA	Nigeria	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nu	niu	570	NIUE	Niue	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
nf	nfk	574	NORFOLK ISLAND	Norfolk Island	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mk	mkd	807	NORTH MACEDONIA	North Macedonia	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
mp	mnp	580	NORTHERN MARIANA ISLANDS	Northern Mariana Islands	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
no	nor	578	NORWAY	Norway	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
om	omn	512	OMAN	Oman	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pk	pak	586	PAKISTAN	Pakistan	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pw	plw	585	PALAU	Palau	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ps	pse	275	PALESTINIAN TERRITORY, OCCUPIED	Palestinian Territory, Occupied	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pa	pan	591	PANAMA	Panama	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pg	png	598	PAPUA NEW GUINEA	Papua New Guinea	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
py	pry	600	PARAGUAY	Paraguay	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pe	per	604	PERU	Peru	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ph	phl	608	PHILIPPINES	Philippines	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pn	pcn	612	PITCAIRN	Pitcairn	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pl	pol	616	POLAND	Poland	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pt	prt	620	PORTUGAL	Portugal	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
pr	pri	630	PUERTO RICO	Puerto Rico	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
qa	qat	634	QATAR	Qatar	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
re	reu	638	REUNION	Reunion	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
ro	rom	642	ROMANIA	Romania	\N	\N	2026-04-22 22:35:26.18+02	2026-04-22 22:35:26.18+02	\N
my	mys	458	MALAYSIA	Malaysia	reg_01KPZA4WP86M2QS4F7YPJY792P	\N	2026-04-22 22:35:26.179+02	2026-04-24 10:36:50.514+02	\N
ru	rus	643	RUSSIAN FEDERATION	Russian Federation	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
rw	rwa	646	RWANDA	Rwanda	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
bl	blm	652	SAINT BARTHÉLEMY	Saint Barthélemy	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sh	shn	654	SAINT HELENA	Saint Helena	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
kn	kna	659	SAINT KITTS AND NEVIS	Saint Kitts and Nevis	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
lc	lca	662	SAINT LUCIA	Saint Lucia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
mf	maf	663	SAINT MARTIN (FRENCH PART)	Saint Martin (French part)	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
pm	spm	666	SAINT PIERRE AND MIQUELON	Saint Pierre and Miquelon	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
vc	vct	670	SAINT VINCENT AND THE GRENADINES	Saint Vincent and the Grenadines	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
ws	wsm	882	SAMOA	Samoa	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sm	smr	674	SAN MARINO	San Marino	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
st	stp	678	SAO TOME AND PRINCIPE	Sao Tome and Principe	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sa	sau	682	SAUDI ARABIA	Saudi Arabia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sn	sen	686	SENEGAL	Senegal	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
rs	srb	688	SERBIA	Serbia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sc	syc	690	SEYCHELLES	Seychelles	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sl	sle	694	SIERRA LEONE	Sierra Leone	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sg	sgp	702	SINGAPORE	Singapore	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sx	sxm	534	SINT MAARTEN	Sint Maarten	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sk	svk	703	SLOVAKIA	Slovakia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
si	svn	705	SLOVENIA	Slovenia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sb	slb	090	SOLOMON ISLANDS	Solomon Islands	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
so	som	706	SOMALIA	Somalia	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
za	zaf	710	SOUTH AFRICA	South Africa	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
gs	sgs	239	SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS	South Georgia and the South Sandwich Islands	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
ss	ssd	728	SOUTH SUDAN	South Sudan	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
lk	lka	144	SRI LANKA	Sri Lanka	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sd	sdn	729	SUDAN	Sudan	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sr	sur	740	SURINAME	Suriname	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sj	sjm	744	SVALBARD AND JAN MAYEN	Svalbard and Jan Mayen	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sz	swz	748	SWAZILAND	Swaziland	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
ch	che	756	SWITZERLAND	Switzerland	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
sy	syr	760	SYRIAN ARAB REPUBLIC	Syrian Arab Republic	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
tw	twn	158	TAIWAN, PROVINCE OF CHINA	Taiwan, Province of China	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.181+02	\N
tj	tjk	762	TAJIKISTAN	Tajikistan	\N	\N	2026-04-22 22:35:26.181+02	2026-04-22 22:35:26.182+02	\N
tz	tza	834	TANZANIA, UNITED REPUBLIC OF	Tanzania, United Republic of	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
th	tha	764	THAILAND	Thailand	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tl	tls	626	TIMOR LESTE	Timor Leste	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tg	tgo	768	TOGO	Togo	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tk	tkl	772	TOKELAU	Tokelau	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
to	ton	776	TONGA	Tonga	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tt	tto	780	TRINIDAD AND TOBAGO	Trinidad and Tobago	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tn	tun	788	TUNISIA	Tunisia	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tr	tur	792	TURKEY	Turkey	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tm	tkm	795	TURKMENISTAN	Turkmenistan	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tc	tca	796	TURKS AND CAICOS ISLANDS	Turks and Caicos Islands	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
tv	tuv	798	TUVALU	Tuvalu	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ug	uga	800	UGANDA	Uganda	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ua	ukr	804	UKRAINE	Ukraine	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ae	are	784	UNITED ARAB EMIRATES	United Arab Emirates	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
us	usa	840	UNITED STATES	United States	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
um	umi	581	UNITED STATES MINOR OUTLYING ISLANDS	United States Minor Outlying Islands	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
uy	ury	858	URUGUAY	Uruguay	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
uz	uzb	860	UZBEKISTAN	Uzbekistan	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
vu	vut	548	VANUATU	Vanuatu	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ve	ven	862	VENEZUELA	Venezuela	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
vn	vnm	704	VIET NAM	Viet Nam	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
vg	vgb	092	VIRGIN ISLANDS, BRITISH	Virgin Islands, British	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
vi	vir	850	VIRGIN ISLANDS, U.S.	Virgin Islands, U.S.	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
wf	wlf	876	WALLIS AND FUTUNA	Wallis and Futuna	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
eh	esh	732	WESTERN SAHARA	Western Sahara	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ye	yem	887	YEMEN	Yemen	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
zm	zmb	894	ZAMBIA	Zambia	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
zw	zwe	716	ZIMBABWE	Zimbabwe	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
ax	ala	248	ÅLAND ISLANDS	Åland Islands	\N	\N	2026-04-22 22:35:26.182+02	2026-04-22 22:35:26.182+02	\N
dk	dnk	208	DENMARK	Denmark	\N	\N	2026-04-22 22:35:26.177+02	2026-04-24 15:29:48.268+02	\N
fr	fra	250	FRANCE	France	\N	\N	2026-04-22 22:35:26.178+02	2026-04-24 15:29:48.268+02	\N
de	deu	276	GERMANY	Germany	\N	\N	2026-04-22 22:35:26.178+02	2026-04-24 15:29:48.268+02	\N
it	ita	380	ITALY	Italy	\N	\N	2026-04-22 22:35:26.179+02	2026-04-24 15:29:48.268+02	\N
es	esp	724	SPAIN	Spain	\N	\N	2026-04-22 22:35:26.181+02	2026-04-24 15:29:48.268+02	\N
se	swe	752	SWEDEN	Sweden	\N	\N	2026-04-22 22:35:26.181+02	2026-04-24 15:29:48.268+02	\N
gb	gbr	826	UNITED KINGDOM	United Kingdom	\N	\N	2026-04-22 22:35:26.182+02	2026-04-24 15:29:48.268+02	\N
\.


--
-- Data for Name: region_payment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."region_payment_provider" ("region_id", "payment_provider_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
reg_01KPZA4WP86M2QS4F7YPJY792P	pp_stripe_stripe	regpp_01KPZQKZ74KFM6JRJDSV7DARTQ	2026-04-24 14:32:16.09421+02	2026-04-24 14:32:16.09421+02	\N
reg_01KPZA4WP86M2QS4F7YPJY792P	pp_system_default	regpp_01KPZQKZ7BQHY9MRMGA7EAW651	2026-04-24 14:32:16.09421+02	2026-04-24 14:32:16.09421+02	\N
reg_01KPVEFKYDPAKWC7499ZXE0DY9	pp_stripe_stripe	regpp_01KPXVT0MHJHSHQCZ3TKJBCFSF	2026-04-23 21:06:59.598311+02	2026-04-24 15:29:48.291+02	2026-04-24 15:29:48.288+02
reg_01KPVEFKYDPAKWC7499ZXE0DY9	pp_system_default	regpp_01KPVEFM24HKSHYDFJ7KM358R0	2026-04-22 22:35:38.686154+02	2026-04-24 15:29:48.291+02	2026-04-24 15:29:48.288+02
\.


--
-- Data for Name: reservation_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."reservation_item" ("id", "created_at", "updated_at", "deleted_at", "line_item_id", "location_id", "quantity", "external_id", "description", "created_by", "metadata", "inventory_item_id", "allow_backorder", "raw_quantity") FROM stdin;
resitem_01KPWECVWZCVAZFRHGXSVFFX2D	2026-04-23 07:53:22.854+02	2026-04-24 15:38:37.744+02	2026-04-24 15:38:37.713+02	ordli_01KPWECVRM631BSED4QY9H1P8V	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1	\N	\N	\N	\N	iitem_01KPVEFMKS3XS0V9HWQS8R8GE7	f	{"value": "1", "precision": 20}
resitem_01KPWECVWZ0REGNYQB5ABN4Z7N	2026-04-23 07:53:22.854+02	2026-04-24 15:38:37.744+02	2026-04-24 15:38:37.713+02	ordli_01KPWECVRMEM3WEM6VW45WG6AN	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	1	\N	\N	\N	\N	iitem_01KPVEFMKPAZEYXJDKZHAPD0CS	f	{"value": "1", "precision": 20}
\.


--
-- Data for Name: return; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."return" ("id", "order_id", "claim_id", "exchange_id", "order_version", "display_id", "status", "no_notification", "refund_amount", "raw_refund_amount", "metadata", "created_at", "updated_at", "deleted_at", "received_at", "canceled_at", "location_id", "requested_at", "created_by") FROM stdin;
\.


--
-- Data for Name: return_fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."return_fulfillment" ("return_id", "fulfillment_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: return_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."return_item" ("id", "return_id", "reason_id", "item_id", "quantity", "raw_quantity", "received_quantity", "raw_received_quantity", "note", "metadata", "created_at", "updated_at", "deleted_at", "damaged_quantity", "raw_damaged_quantity") FROM stdin;
\.


--
-- Data for Name: return_reason; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."return_reason" ("id", "value", "label", "description", "metadata", "parent_return_reason_id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."sales_channel" ("id", "name", "description", "is_disabled", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
sc_01KPVEFEV595D4YCDP15QR7DDX	Default Sales Channel		f	\N	2026-04-22 22:35:33.349+02	2026-04-24 15:35:00.375+02	\N
\.


--
-- Data for Name: sales_channel_stock_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."sales_channel_stock_location" ("sales_channel_id", "stock_location_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
sc_01KPVEFEV595D4YCDP15QR7DDX	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	scloc_01KPVEFMC85F2N6KGZJXY6TA71	2026-04-22 22:35:39.015682+02	2026-04-22 22:35:39.015682+02	\N
\.


--
-- Data for Name: script_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."script_migrations" ("id", "script_name", "created_at", "finished_at") FROM stdin;
1	migrate-product-shipping-profile.js	2026-04-22 22:35:27.861648+02	2026-04-22 22:35:27.907652+02
2	migrate-tax-region-provider.js	2026-04-22 22:35:27.912464+02	2026-04-22 22:35:27.92497+02
\.


--
-- Data for Name: service_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."service_zone" ("id", "name", "metadata", "fulfillment_set_id", "created_at", "updated_at", "deleted_at") FROM stdin;
serzo_01KPZA60BXGBWBP6ESN93YCCRF	Malaysia	\N	fuset_01KPVEFM5MNMDSQ40ZRWHV0C3G	2026-04-24 10:37:27.037+02	2026-04-24 10:37:27.037+02	\N
serzo_01KPVEFM5MC5CT712T6KM95QZ9	Europe	\N	fuset_01KPVEFM5MNMDSQ40ZRWHV0C3G	2026-04-22 22:35:38.805+02	2026-04-24 15:31:36.028+02	2026-04-24 15:31:36.027+02
\.


--
-- Data for Name: shipping_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."shipping_option" ("id", "name", "price_type", "service_zone_id", "shipping_profile_id", "provider_id", "data", "metadata", "shipping_option_type_id", "created_at", "updated_at", "deleted_at") FROM stdin;
so_01KPZA60PMAKG1123G09884N1V	Standard Delivery (MY)	flat	serzo_01KPZA60BXGBWBP6ESN93YCCRF	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	manual_manual	\N	\N	sotype_01KPZA60PKV6B6WXJVNH4GNMQR	2026-04-24 10:37:27.38+02	2026-04-24 10:37:27.38+02	\N
so_01KPVEFM8VS58X5XS6Z6PA0X3S	Standard Shipping	flat	serzo_01KPVEFM5MC5CT712T6KM95QZ9	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	manual_manual	\N	\N	sotype_01KPVEFM8S3VNN8HT1HDNE1JAD	2026-04-22 22:35:38.908+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
so_01KPVEFM8VXQXQ9TV5DECNE6FE	Express Shipping	flat	serzo_01KPVEFM5MC5CT712T6KM95QZ9	sp_01KPVEF9GRG5TZYZBKN2ZMGT84	manual_manual	\N	\N	sotype_01KPVEFM8VAGNZRWAFZYRF8T4A	2026-04-22 22:35:38.908+02	2026-04-24 15:31:36.056+02	2026-04-24 15:31:36.027+02
\.


--
-- Data for Name: shipping_option_price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."shipping_option_price_set" ("shipping_option_id", "price_set_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
so_01KPZA60PMAKG1123G09884N1V	pset_01KPZA60QF4EAP72MB72P97EEP	sops_01KPZA60RQ87RCHQPNM50ZJXM5	2026-04-24 10:37:27.446555+02	2026-04-24 10:37:27.446555+02	\N
so_01KPVEFM8VS58X5XS6Z6PA0X3S	pset_01KPVEFM9TY6FMDJZ0GYQH912P	sops_01KPVEFMBPY3F0G2Y7NV99XFBC	2026-04-22 22:35:38.99802+02	2026-04-24 15:31:19.504+02	2026-04-24 15:31:19.502+02
so_01KPVEFM8VXQXQ9TV5DECNE6FE	pset_01KPVEFM9VV72RGDK9J8DAKT4J	sops_01KPVEFMBQ0P2TE5Q0WKXX3CMV	2026-04-22 22:35:38.99802+02	2026-04-24 15:31:29.689+02	2026-04-24 15:31:29.688+02
\.


--
-- Data for Name: shipping_option_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."shipping_option_rule" ("id", "attribute", "operator", "value", "shipping_option_id", "created_at", "updated_at", "deleted_at") FROM stdin;
sorul_01KPZA60PK27CYK69RKTWN0M4G	is_return	eq	"false"	so_01KPZA60PMAKG1123G09884N1V	2026-04-24 10:37:27.381+02	2026-04-24 10:37:27.381+02	\N
sorul_01KPZA60PK3SKQRVNFZG197GAH	enabled_in_store	eq	"true"	so_01KPZA60PMAKG1123G09884N1V	2026-04-24 10:37:27.381+02	2026-04-24 10:37:27.381+02	\N
sorul_01KPVEFM8THNMTPVSFNBC8R96E	enabled_in_store	eq	"true"	so_01KPVEFM8VS58X5XS6Z6PA0X3S	2026-04-22 22:35:38.909+02	2026-04-24 15:31:36.11+02	2026-04-24 15:31:36.027+02
sorul_01KPVEFM8T6BG5A1BMH3BG48BQ	is_return	eq	"false"	so_01KPVEFM8VS58X5XS6Z6PA0X3S	2026-04-22 22:35:38.909+02	2026-04-24 15:31:36.11+02	2026-04-24 15:31:36.027+02
sorul_01KPVEFM8VVEZQRZ1NR2ZEWAYH	enabled_in_store	eq	"true"	so_01KPVEFM8VXQXQ9TV5DECNE6FE	2026-04-22 22:35:38.909+02	2026-04-24 15:31:36.11+02	2026-04-24 15:31:36.027+02
sorul_01KPVEFM8V8G6ZD8BHPA5RT46A	is_return	eq	"false"	so_01KPVEFM8VXQXQ9TV5DECNE6FE	2026-04-22 22:35:38.909+02	2026-04-24 15:31:36.11+02	2026-04-24 15:31:36.027+02
\.


--
-- Data for Name: shipping_option_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."shipping_option_type" ("id", "label", "description", "code", "created_at", "updated_at", "deleted_at") FROM stdin;
sotype_01KPVEFM8S3VNN8HT1HDNE1JAD	Standard	Ship in 2-3 days.	standard	2026-04-22 22:35:38.908+02	2026-04-22 22:35:38.908+02	\N
sotype_01KPVEFM8VAGNZRWAFZYRF8T4A	Express	Ship in 24 hours.	express	2026-04-22 22:35:38.908+02	2026-04-22 22:35:38.908+02	\N
sotype_01KPZA60PKV6B6WXJVNH4GNMQR	Standard	Ships within 2-3 business days	standard	2026-04-24 10:37:27.38+02	2026-04-24 10:37:27.38+02	\N
\.


--
-- Data for Name: shipping_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."shipping_profile" ("id", "name", "type", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
sp_01KPVEF9GRG5TZYZBKN2ZMGT84	Default Shipping Profile	default	\N	2026-04-22 22:35:27.896+02	2026-04-22 22:35:27.896+02	\N
\.


--
-- Data for Name: site_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."site_config" ("id", "key", "value", "label", "description", "group", "is_public", "created_at", "updated_at", "deleted_at") FROM stdin;
01KQ2GD92MM4BHN3915515DMSR	site_logo_url	/assets/images/logo.svg	\N	\N	identity	t	2026-04-25 16:24:00.084+02	2026-04-25 16:24:00.084+02	\N
01KQ2GD93QFQQ1549524BWV3TB	site_logo_width	95	\N	\N	identity	t	2026-04-25 16:24:00.12+02	2026-04-25 16:24:00.12+02	\N
01KQ2GD93Z8J58XW7VPDNPT391	site_logo_height	30	\N	\N	identity	t	2026-04-25 16:24:00.127+02	2026-04-25 16:24:00.127+02	\N
\.


--
-- Data for Name: stock_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."stock_location" ("id", "created_at", "updated_at", "deleted_at", "name", "address_id", "metadata") FROM stdin;
sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	2026-04-22 22:35:38.755+02	2026-04-24 15:32:28.388+02	\N	Warehouse	laddr_01KPVEFM42Z38NASVA8C9VZ79K	\N
\.


--
-- Data for Name: stock_location_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."stock_location_address" ("id", "created_at", "updated_at", "deleted_at", "address_1", "address_2", "company", "city", "country_code", "phone", "province", "postal_code", "metadata") FROM stdin;
laddr_01KPVEFM42Z38NASVA8C9VZ79K	2026-04-22 22:35:38.755+02	2026-04-24 15:32:28.368+02	\N	Malaysia				my				\N
\.


--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."store" ("id", "name", "default_sales_channel_id", "default_region_id", "default_location_id", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
store_01KPVEFEW2QW8RAKY0RP750AT7	WStore	sc_01KPVEFEV595D4YCDP15QR7DDX	\N	sloc_01KPVEFM42ZJTNM67Y2CX3R9X7	\N	2026-04-22 22:35:33.376315+02	2026-04-22 22:35:33.376315+02	\N
\.


--
-- Data for Name: store_currency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."store_currency" ("id", "currency_code", "is_default", "store_id", "created_at", "updated_at", "deleted_at") FROM stdin;
stocur_01KPZVG250HDMD95QKHX7QPYG0	myr	t	store_01KPVEFEW2QW8RAKY0RP750AT7	2026-04-24 15:40:02.328263+02	2026-04-24 15:40:02.328263+02	\N
stocur_01KPZVG25104NW32X28C0T1EW9	usd	f	store_01KPVEFEW2QW8RAKY0RP750AT7	2026-04-24 15:40:02.328263+02	2026-04-24 15:40:02.328263+02	\N
\.


--
-- Data for Name: store_locale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."store_locale" ("id", "locale_code", "store_id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: tax_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."tax_provider" ("id", "is_enabled", "created_at", "updated_at", "deleted_at") FROM stdin;
tp_system	t	2026-04-22 22:35:26.308+02	2026-04-22 22:35:26.308+02	\N
\.


--
-- Data for Name: tax_rate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."tax_rate" ("id", "rate", "code", "name", "is_default", "is_combinable", "tax_region_id", "metadata", "created_at", "updated_at", "created_by", "deleted_at") FROM stdin;
\.


--
-- Data for Name: tax_rate_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."tax_rate_rule" ("id", "tax_rate_id", "reference_id", "reference", "metadata", "created_at", "updated_at", "created_by", "deleted_at") FROM stdin;
\.


--
-- Data for Name: tax_region; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."tax_region" ("id", "provider_id", "country_code", "province_code", "parent_id", "metadata", "created_at", "updated_at", "created_by", "deleted_at") FROM stdin;
txreg_01KPVEFM3B05WE161D4EPPQQ4H	tp_system	de	\N	\N	\N	2026-04-22 22:35:38.732+02	2026-04-24 15:32:49.375+02	\N	2026-04-24 15:32:49.374+02
txreg_01KPVEFM3C5YKQ6R48FQZMHCYC	tp_system	es	\N	\N	\N	2026-04-22 22:35:38.733+02	2026-04-24 15:32:58.931+02	\N	2026-04-24 15:32:58.931+02
txreg_01KPVEFM3C4PJ91VRB1HDMG7Y4	tp_system	it	\N	\N	\N	2026-04-22 22:35:38.733+02	2026-04-24 15:33:02.287+02	\N	2026-04-24 15:33:02.286+02
txreg_01KPVEFM3BPVYSY2ZETCFS08N2	tp_system	se	\N	\N	\N	2026-04-22 22:35:38.733+02	2026-04-24 15:33:06.598+02	\N	2026-04-24 15:33:06.597+02
txreg_01KPVEFM3AKD82JEPT4H3TBV6H	tp_system	gb	\N	\N	\N	2026-04-22 22:35:38.732+02	2026-04-24 15:33:09.855+02	\N	2026-04-24 15:33:09.854+02
txreg_01KPVEFM3C4ANFPGN1ZSNXAHMX	tp_system	fr	\N	\N	\N	2026-04-22 22:35:38.733+02	2026-04-24 15:33:13.224+02	\N	2026-04-24 15:33:13.223+02
txreg_01KPVEFM3B86Z62QWBH7RJJ13M	tp_system	dk	\N	\N	\N	2026-04-22 22:35:38.732+02	2026-04-24 15:33:17.396+02	\N	2026-04-24 15:33:17.395+02
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."user" ("id", "first_name", "last_name", "email", "avatar_url", "metadata", "created_at", "updated_at", "deleted_at") FROM stdin;
user_01KPVERWMYC488JMTY56E4HW5C	\N	\N	fate6317@gmail.com	\N	\N	2026-04-22 22:40:42.399+02	2026-04-22 22:40:42.399+02	\N
\.


--
-- Data for Name: user_preference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."user_preference" ("id", "user_id", "key", "value", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: user_rbac_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."user_rbac_role" ("user_id", "rbac_role_id", "id", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: view_configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."view_configuration" ("id", "entity", "name", "user_id", "is_system_default", "configuration", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: workflow_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."workflow_execution" ("id", "workflow_id", "transaction_id", "execution", "context", "state", "created_at", "updated_at", "deleted_at", "retention_time", "run_id") FROM stdin;
wf_exec_01KPWECVMMANFNV0ACQCZC1F02	complete-cart	auto-01KPWECVM6J7SD3T17Q0M1R9V3	{"_v": 0, "runId": "01KPWECVMA0816B52YN10FWSHR", "state": "done", "steps": {"_root": {"id": "_root", "next": ["_root.acquire-lock-step"]}, "_root.acquire-lock-step": {"_v": 0, "id": "_root.acquire-lock-step", "next": ["_root.acquire-lock-step.use-query-graph-step", "_root.acquire-lock-step.cart-query"], "uuid": "01KPWC66509P2FAC47ZP1WXPJ0", "depth": 1, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602593, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66509P2FAC47ZP1WXPJ0", "store": false, "action": "acquire-lock-step", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602593, "saveResponse": true}, "_root.acquire-lock-step.cart-query": {"_v": 0, "id": "_root.acquire-lock-step.cart-query", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments"], "uuid": "01KPWC6650CPYGNHGYTHV5EYT9", "depth": 2, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602595, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6650CPYGNHGYTHV5EYT9", "async": false, "store": false, "action": "cart-query", "noCompensation": true, "compensateAsync": false}, "stepFailed": false, "lastAttempt": 1776923602595, "saveResponse": true}, "_root.acquire-lock-step.use-query-graph-step": {"_v": 0, "id": "_root.acquire-lock-step.use-query-graph-step", "next": [], "uuid": "01KPWC66501TSTN8ES6RM5YXCN", "depth": 2, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602594, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66501TSTN8ES6RM5YXCN", "store": false, "action": "use-query-graph-step", "noCompensation": true}, "stepFailed": false, "lastAttempt": 1776923602594, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed"], "uuid": "01KPWC6650W24Y1EVZPJKHRBY7", "depth": 3, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602661, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6650W24Y1EVZPJKHRBY7", "store": false, "action": "validate-cart-payments", "noCompensation": true}, "stepFailed": false, "lastAttempt": 1776923602661, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate"], "uuid": "01KPWC665082R9P6CTR9RBA9BY", "depth": 4, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602666, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC665082R9P6CTR9RBA9BY", "store": false, "action": "compensate-payment-if-needed", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602666, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query"], "uuid": "01KPWC6650P5WB3JBW8QX6NKCM", "depth": 5, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602669, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6650P5WB3JBW8QX6NKCM", "store": false, "action": "validate", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602669, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping"], "uuid": "01KPWC66511DFGZYRJJY97K9JE", "depth": 6, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602675, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66511DFGZYRJJY97K9JE", "async": false, "store": false, "action": "shipping-options-query", "noCompensation": true, "compensateAsync": false}, "stepFailed": false, "lastAttempt": 1776923602675, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders"], "uuid": "01KPWC6651F4Q9JF9QCDY5AA93", "depth": 7, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602685, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6651F4Q9JF9QCDY5AA93", "store": false, "action": "validate-shipping", "noCompensation": true}, "stepFailed": false, "lastAttempt": 1776923602685, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.create-remote-links", "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.update-carts", "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.reserve-inventory-step", "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.register-usage", "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step"], "uuid": "01KPWC66511HGG9SV1T620SKM4", "depth": 8, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602690, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66511HGG9SV1T620SKM4", "store": false, "action": "create-orders", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602690, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.update-carts": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.update-carts", "next": [], "uuid": "01KPWC6652S4WX0EGBDFQ2JZ18", "depth": 9, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602820, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6652S4WX0EGBDFQ2JZ18", "store": false, "action": "update-carts", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602820, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.register-usage": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.register-usage", "next": [], "uuid": "01KPWC665214JR9V70EMSXMZ1H", "depth": 9, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602820, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC665214JR9V70EMSXMZ1H", "store": false, "action": "register-usage", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602820, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization"], "uuid": "01KPWC66523P0CNN53MRXWHM7E", "depth": 9, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602820, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66523P0CNN53MRXWHM7E", "store": false, "action": "emit-event-step", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602820, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.create-remote-links": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.create-remote-links", "next": [], "uuid": "01KPWC6652JKGW05G81KEKPS67", "depth": 9, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602820, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6652JKGW05G81KEKPS67", "store": false, "action": "create-remote-links", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602820, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.reserve-inventory-step": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.reserve-inventory-step", "next": [], "uuid": "01KPWC66529YC5GPJQRNT4DCGK", "depth": 9, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602820, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66529YC5GPJQRNT4DCGK", "store": false, "action": "reserve-inventory-step", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602820, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step"], "uuid": "01KPWC66527ZWXBPRBB6YDNKKG", "depth": 10, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602880, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66527ZWXBPRBB6YDNKKG", "store": false, "action": "beforePaymentAuthorization", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602880, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction"], "uuid": "01KPWC6652D10EJT9DY1P5HMNG", "depth": 11, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602883, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6652D10EJT9DY1P5HMNG", "store": false, "action": "authorize-payment-session-step", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602883, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated"], "uuid": "01KPWC6652PH57VGZS9PMRS2N3", "depth": 12, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602952, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6652PH57VGZS9PMRS2N3", "store": false, "action": "add-order-transaction", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602952, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order"], "uuid": "01KPWC6652ZAYSH1KABP6CZYM7", "depth": 13, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602957, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6652ZAYSH1KABP6CZYM7", "store": false, "action": "orderCreated", "noCompensation": false}, "stepFailed": false, "lastAttempt": 1776923602957, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order", "next": ["_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order.release-lock-step"], "uuid": "01KPWC6653R9G5QX3K2312XK91", "depth": 14, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602962, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC6653R9G5QX3K2312XK91", "store": false, "action": "create-order", "noCompensation": true}, "stepFailed": false, "lastAttempt": 1776923602962, "saveResponse": true}, "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order.release-lock-step": {"_v": 0, "id": "_root.acquire-lock-step.cart-query.validate-cart-payments.compensate-payment-if-needed.validate.shipping-options-query.validate-shipping.create-orders.emit-event-step.beforePaymentAuthorization.authorize-payment-session-step.add-order-transaction.orderCreated.create-order.release-lock-step", "next": [], "uuid": "01KPWC66532V7T1J0DEYKYXMM0", "depth": 15, "invoke": {"state": "done", "status": "ok"}, "attempts": 1, "failures": 0, "startedAt": 1776923602969, "compensate": {"state": "dormant", "status": "idle"}, "definition": {"uuid": "01KPWC66532V7T1J0DEYKYXMM0", "store": false, "action": "release-lock-step", "noCompensation": true}, "stepFailed": false, "lastAttempt": 1776923602969, "saveResponse": true}}, "modelId": "complete-cart", "options": {"name": "complete-cart", "store": true, "idempotent": false, "retentionTime": 259200}, "metadata": {"sourcePath": "/home/ubuntu/www/what/node_modules/@medusajs/core-flows/dist/cart/workflows/complete-cart.js", "eventGroupId": "01KPWECVM716QAAFVB5KQCF9W1", "preventReleaseEvents": false}, "startedAt": 1776923602592, "definition": {"next": [{"uuid": "01KPWC66501TSTN8ES6RM5YXCN", "action": "use-query-graph-step", "noCompensation": true}, {"next": {"next": {"next": {"next": {"next": {"next": {"next": [{"uuid": "01KPWC6652JKGW05G81KEKPS67", "action": "create-remote-links", "noCompensation": false}, {"uuid": "01KPWC6652S4WX0EGBDFQ2JZ18", "action": "update-carts", "noCompensation": false}, {"uuid": "01KPWC66529YC5GPJQRNT4DCGK", "action": "reserve-inventory-step", "noCompensation": false}, {"uuid": "01KPWC665214JR9V70EMSXMZ1H", "action": "register-usage", "noCompensation": false}, {"next": {"next": {"next": {"next": {"next": {"next": {"uuid": "01KPWC66532V7T1J0DEYKYXMM0", "action": "release-lock-step", "noCompensation": true}, "uuid": "01KPWC6653R9G5QX3K2312XK91", "action": "create-order", "noCompensation": true}, "uuid": "01KPWC6652ZAYSH1KABP6CZYM7", "action": "orderCreated", "noCompensation": false}, "uuid": "01KPWC6652PH57VGZS9PMRS2N3", "action": "add-order-transaction", "noCompensation": false}, "uuid": "01KPWC6652D10EJT9DY1P5HMNG", "action": "authorize-payment-session-step", "noCompensation": false}, "uuid": "01KPWC66527ZWXBPRBB6YDNKKG", "action": "beforePaymentAuthorization", "noCompensation": false}, "uuid": "01KPWC66523P0CNN53MRXWHM7E", "action": "emit-event-step", "noCompensation": false}], "uuid": "01KPWC66511HGG9SV1T620SKM4", "action": "create-orders", "noCompensation": false}, "uuid": "01KPWC6651F4Q9JF9QCDY5AA93", "action": "validate-shipping", "noCompensation": true}, "uuid": "01KPWC66511DFGZYRJJY97K9JE", "async": false, "action": "shipping-options-query", "noCompensation": true, "compensateAsync": false}, "uuid": "01KPWC6650P5WB3JBW8QX6NKCM", "action": "validate", "noCompensation": false}, "uuid": "01KPWC665082R9P6CTR9RBA9BY", "action": "compensate-payment-if-needed", "noCompensation": false}, "uuid": "01KPWC6650W24Y1EVZPJKHRBY7", "action": "validate-cart-payments", "noCompensation": true}, "uuid": "01KPWC6650CPYGNHGYTHV5EYT9", "async": false, "action": "cart-query", "noCompensation": true, "compensateAsync": false}], "uuid": "01KPWC66509P2FAC47ZP1WXPJ0", "action": "acquire-lock-step", "noCompensation": false}, "timedOutAt": null, "hasAsyncSteps": false, "transactionId": "auto-01KPWECVM6J7SD3T17Q0M1R9V3", "hasFailedSteps": false, "hasSkippedSteps": false, "hasWaitingSteps": false, "hasRevertedSteps": false, "hasSkippedOnFailureSteps": false}	{"data": {"invoke": {"validate": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)"}}, "cart-query": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {"data": {"id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "email": "abc@test.com", "items": [{"id": "cali_01KPVFBRW96T4Q1TCVYV1NHCFC", "title": "Medusa Shorts", "total": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "variant": {"id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "product": {"id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "is_giftcard": false, "shipping_profile": {"id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}}, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "allow_backorder": false, "inventory_items": [{"inventory": {"id": "iitem_01KPVEFMKS3XS0V9HWQS8R8GE7", "location_levels": [{"location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "stock_locations": [{"id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "name": "European Warehouse", "sales_channels": [{"id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "name": "Default Sales Channel"}]}], "stocked_quantity": 1000000, "reserved_quantity": 0, "raw_stocked_quantity": {"value": "1000000", "precision": 20}, "raw_reserved_quantity": {"value": "0", "precision": 20}}], "requires_shipping": true}, "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "inventory_item_id": "iitem_01KPVEFMKS3XS0V9HWQS8R8GE7", "required_quantity": 1}], "manage_inventory": true}, "metadata": {}, "quantity": 1, "subtitle": "L", "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png", "created_at": "2026-04-22T20:51:01.129Z", "deleted_at": null, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "unit_price": 10, "updated_at": "2026-04-22T20:51:01.129Z", "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "adjustments": [], "is_giftcard": false, "variant_sku": "SHORTS-L", "product_type": null, "raw_subtotal": {"value": "10", "precision": 20}, "product_title": "Medusa Shorts", "raw_tax_total": {"value": "0", "precision": 20}, "variant_title": "L", "discount_total": 0, "original_total": 10, "product_handle": "shorts", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "discount_subtotal": 0, "original_subtotal": 10, "requires_shipping": true, "discount_tax_total": 0, "original_tax_total": 0, "product_collection": null, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "product_description": "Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "variant_option_values": null, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_compare_at_unit_price": null}, {"id": "cali_01KPWEAH4PJEA7BWWECMNW95GK", "title": "Medusa T-Shirt", "total": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "variant": {"id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "product": {"id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "is_giftcard": false, "shipping_profile": {"id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}}, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "allow_backorder": false, "inventory_items": [{"inventory": {"id": "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS", "location_levels": [{"location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "stock_locations": [{"id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "name": "European Warehouse", "sales_channels": [{"id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "name": "Default Sales Channel"}]}], "stocked_quantity": 1000000, "reserved_quantity": 0, "raw_stocked_quantity": {"value": "1000000", "precision": 20}, "raw_reserved_quantity": {"value": "0", "precision": 20}}], "requires_shipping": true}, "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "inventory_item_id": "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS", "required_quantity": 1}], "manage_inventory": true}, "metadata": {}, "quantity": 1, "subtitle": "M / Black", "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png", "created_at": "2026-04-23T05:52:06.294Z", "deleted_at": null, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "unit_price": 10, "updated_at": "2026-04-23T05:52:06.294Z", "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "adjustments": [], "is_giftcard": false, "variant_sku": "SHIRT-M-BLACK", "product_type": null, "raw_subtotal": {"value": "10", "precision": 20}, "product_title": "Medusa T-Shirt", "raw_tax_total": {"value": "0", "precision": 20}, "variant_title": "M / Black", "discount_total": 0, "original_total": 10, "product_handle": "t-shirt", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "discount_subtotal": 0, "original_subtotal": 10, "requires_shipping": true, "discount_tax_total": 0, "original_tax_total": 0, "product_collection": null, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "product_description": "Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "variant_option_values": null, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_compare_at_unit_price": null}], "total": 30, "locale": null, "region": {"id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "name": "Europe", "metadata": null, "created_at": "2026-04-22T20:35:38.597Z", "deleted_at": null, "updated_at": "2026-04-22T20:35:38.597Z", "currency_code": "eur", "automatic_taxes": true}, "customer": {"id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "email": "abc@test.com", "phone": null, "metadata": null, "last_name": null, "created_at": "2026-04-23T05:53:21.215Z", "created_by": null, "deleted_at": null, "first_name": null, "updated_at": "2026-04-23T05:53:21.215Z", "has_account": false, "company_name": null}, "metadata": null, "subtotal": 30, "raw_total": {"value": "30", "precision": 20}, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "tax_total": 0, "created_at": "2026-04-22T20:51:00.700Z", "item_total": 20, "promotions": [], "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "completed_at": null, "credit_lines": [], "raw_subtotal": {"value": "30", "precision": 20}, "currency_code": "eur", "item_subtotal": 20, "raw_tax_total": {"value": "0", "precision": 20}, "discount_total": 0, "item_tax_total": 0, "original_total": 30, "raw_item_total": {"value": "20", "precision": 20}, "shipping_total": 10, "billing_address": {"id": "caaddr_01KPWECTB5EWABMKQHQ68ZZMVW", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.254Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.254Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "caaddr_01KPWECTB6A4308W48ET511SKW", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.255Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "shipping_methods": [{"id": "casm_01KPWECTYXBKEC32BDFAYHM36B", "data": {}, "name": "Standard Shipping", "total": 10, "amount": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "metadata": null, "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "created_at": "2026-04-23T05:53:21.886Z", "deleted_at": null, "raw_amount": {"value": "10", "precision": 20}, "updated_at": "2026-04-23T05:53:21.886Z", "adjustments": [], "description": null, "raw_subtotal": {"value": "10", "precision": 20}, "raw_tax_total": {"value": "0", "precision": 20}, "discount_total": 0, "original_total": 10, "is_tax_inclusive": false, "discount_subtotal": 0, "original_subtotal": 10, "discount_tax_total": 0, "original_tax_total": 0, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "shipping_option_id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S", "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}}], "raw_item_subtotal": {"value": "20", "precision": 20}, "shipping_subtotal": 10, "discount_tax_total": 0, "original_tax_total": 0, "payment_collection": {"id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2", "amount": 30, "status": "not_paid", "metadata": null, "created_at": "2026-04-23T05:53:22.449Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.449Z", "completed_at": null, "currency_code": "eur", "captured_amount": null, "refunded_amount": null, "payment_sessions": [{"id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "data": {}, "amount": 30, "status": "pending", "context": {}, "metadata": {}, "created_at": "2026-04-23T05:53:22.524Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.524Z", "provider_id": "pp_system_default", "authorized_at": null, "currency_code": "eur", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}], "authorized_amount": null, "raw_captured_amount": null, "raw_refunded_amount": null, "raw_authorized_amount": null}, "raw_discount_total": {"value": "0", "precision": 20}, "raw_item_tax_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "30", "precision": 20}, "raw_shipping_total": {"value": "10", "precision": 20}, "shipping_tax_total": 0, "original_item_total": 20, "raw_shipping_subtotal": {"value": "10", "precision": 20}, "original_item_subtotal": 20, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_shipping_tax_total": {"value": "0", "precision": 20}, "original_item_tax_total": 0, "original_shipping_total": 10, "raw_original_item_total": {"value": "20", "precision": 20}, "original_shipping_subtotal": 10, "raw_original_item_subtotal": {"value": "20", "precision": 20}, "original_shipping_tax_total": 0, "raw_original_item_tax_total": {"value": "0", "precision": 20}, "raw_original_shipping_total": {"value": "10", "precision": 20}, "raw_original_shipping_subtotal": {"value": "10", "precision": 20}, "raw_original_shipping_tax_total": {"value": "0", "precision": 20}}}, "compensateInput": {"data": {"id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "email": "abc@test.com", "items": [{"id": "cali_01KPVFBRW96T4Q1TCVYV1NHCFC", "title": "Medusa Shorts", "total": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "variant": {"id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "product": {"id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "is_giftcard": false, "shipping_profile": {"id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}}, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "allow_backorder": false, "inventory_items": [{"inventory": {"id": "iitem_01KPVEFMKS3XS0V9HWQS8R8GE7", "location_levels": [{"location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "stock_locations": [{"id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "name": "European Warehouse", "sales_channels": [{"id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "name": "Default Sales Channel"}]}], "stocked_quantity": 1000000, "reserved_quantity": 0, "raw_stocked_quantity": {"value": "1000000", "precision": 20}, "raw_reserved_quantity": {"value": "0", "precision": 20}}], "requires_shipping": true}, "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "inventory_item_id": "iitem_01KPVEFMKS3XS0V9HWQS8R8GE7", "required_quantity": 1}], "manage_inventory": true}, "metadata": {}, "quantity": 1, "subtitle": "L", "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png", "created_at": "2026-04-22T20:51:01.129Z", "deleted_at": null, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "unit_price": 10, "updated_at": "2026-04-22T20:51:01.129Z", "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "adjustments": [], "is_giftcard": false, "variant_sku": "SHORTS-L", "product_type": null, "raw_subtotal": {"value": "10", "precision": 20}, "product_title": "Medusa Shorts", "raw_tax_total": {"value": "0", "precision": 20}, "variant_title": "L", "discount_total": 0, "original_total": 10, "product_handle": "shorts", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "discount_subtotal": 0, "original_subtotal": 10, "requires_shipping": true, "discount_tax_total": 0, "original_tax_total": 0, "product_collection": null, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "product_description": "Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "variant_option_values": null, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_compare_at_unit_price": null}, {"id": "cali_01KPWEAH4PJEA7BWWECMNW95GK", "title": "Medusa T-Shirt", "total": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "variant": {"id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "product": {"id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "is_giftcard": false, "shipping_profile": {"id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}}, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "allow_backorder": false, "inventory_items": [{"inventory": {"id": "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS", "location_levels": [{"location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "stock_locations": [{"id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "name": "European Warehouse", "sales_channels": [{"id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "name": "Default Sales Channel"}]}], "stocked_quantity": 1000000, "reserved_quantity": 0, "raw_stocked_quantity": {"value": "1000000", "precision": 20}, "raw_reserved_quantity": {"value": "0", "precision": 20}}], "requires_shipping": true}, "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "inventory_item_id": "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS", "required_quantity": 1}], "manage_inventory": true}, "metadata": {}, "quantity": 1, "subtitle": "M / Black", "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png", "created_at": "2026-04-23T05:52:06.294Z", "deleted_at": null, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "unit_price": 10, "updated_at": "2026-04-23T05:52:06.294Z", "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "adjustments": [], "is_giftcard": false, "variant_sku": "SHIRT-M-BLACK", "product_type": null, "raw_subtotal": {"value": "10", "precision": 20}, "product_title": "Medusa T-Shirt", "raw_tax_total": {"value": "0", "precision": 20}, "variant_title": "M / Black", "discount_total": 0, "original_total": 10, "product_handle": "t-shirt", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "discount_subtotal": 0, "original_subtotal": 10, "requires_shipping": true, "discount_tax_total": 0, "original_tax_total": 0, "product_collection": null, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "product_description": "Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "variant_option_values": null, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_compare_at_unit_price": null}], "total": 30, "locale": null, "region": {"id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "name": "Europe", "metadata": null, "created_at": "2026-04-22T20:35:38.597Z", "deleted_at": null, "updated_at": "2026-04-22T20:35:38.597Z", "currency_code": "eur", "automatic_taxes": true}, "customer": {"id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "email": "abc@test.com", "phone": null, "metadata": null, "last_name": null, "created_at": "2026-04-23T05:53:21.215Z", "created_by": null, "deleted_at": null, "first_name": null, "updated_at": "2026-04-23T05:53:21.215Z", "has_account": false, "company_name": null}, "metadata": null, "subtotal": 30, "raw_total": {"value": "30", "precision": 20}, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "tax_total": 0, "created_at": "2026-04-22T20:51:00.700Z", "item_total": 20, "promotions": [], "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "completed_at": null, "credit_lines": [], "raw_subtotal": {"value": "30", "precision": 20}, "currency_code": "eur", "item_subtotal": 20, "raw_tax_total": {"value": "0", "precision": 20}, "discount_total": 0, "item_tax_total": 0, "original_total": 30, "raw_item_total": {"value": "20", "precision": 20}, "shipping_total": 10, "billing_address": {"id": "caaddr_01KPWECTB5EWABMKQHQ68ZZMVW", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.254Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.254Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "caaddr_01KPWECTB6A4308W48ET511SKW", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.255Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "shipping_methods": [{"id": "casm_01KPWECTYXBKEC32BDFAYHM36B", "data": {}, "name": "Standard Shipping", "total": 10, "amount": 10, "cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "metadata": null, "subtotal": 10, "raw_total": {"value": "10", "precision": 20}, "tax_lines": [], "tax_total": 0, "created_at": "2026-04-23T05:53:21.886Z", "deleted_at": null, "raw_amount": {"value": "10", "precision": 20}, "updated_at": "2026-04-23T05:53:21.886Z", "adjustments": [], "description": null, "raw_subtotal": {"value": "10", "precision": 20}, "raw_tax_total": {"value": "0", "precision": 20}, "discount_total": 0, "original_total": 10, "is_tax_inclusive": false, "discount_subtotal": 0, "original_subtotal": 10, "discount_tax_total": 0, "original_tax_total": 0, "raw_discount_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "10", "precision": 20}, "shipping_option_id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S", "raw_discount_subtotal": {"value": "0", "precision": 20}, "raw_original_subtotal": {"value": "10", "precision": 20}, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}}], "raw_item_subtotal": {"value": "20", "precision": 20}, "shipping_subtotal": 10, "discount_tax_total": 0, "original_tax_total": 0, "payment_collection": {"id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2", "amount": 30, "status": "not_paid", "metadata": null, "created_at": "2026-04-23T05:53:22.449Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.449Z", "completed_at": null, "currency_code": "eur", "captured_amount": null, "refunded_amount": null, "payment_sessions": [{"id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "data": {}, "amount": 30, "status": "pending", "context": {}, "metadata": {}, "created_at": "2026-04-23T05:53:22.524Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.524Z", "provider_id": "pp_system_default", "authorized_at": null, "currency_code": "eur", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}], "authorized_amount": null, "raw_captured_amount": null, "raw_refunded_amount": null, "raw_authorized_amount": null}, "raw_discount_total": {"value": "0", "precision": 20}, "raw_item_tax_total": {"value": "0", "precision": 20}, "raw_original_total": {"value": "30", "precision": 20}, "raw_shipping_total": {"value": "10", "precision": 20}, "shipping_tax_total": 0, "original_item_total": 20, "raw_shipping_subtotal": {"value": "10", "precision": 20}, "original_item_subtotal": 20, "raw_discount_tax_total": {"value": "0", "precision": 20}, "raw_original_tax_total": {"value": "0", "precision": 20}, "raw_shipping_tax_total": {"value": "0", "precision": 20}, "original_item_tax_total": 0, "original_shipping_total": 10, "raw_original_item_total": {"value": "20", "precision": 20}, "original_shipping_subtotal": 10, "raw_original_item_subtotal": {"value": "20", "precision": 20}, "original_shipping_tax_total": 0, "raw_original_item_tax_total": {"value": "0", "precision": 20}, "raw_original_shipping_total": {"value": "10", "precision": 20}, "raw_original_shipping_subtotal": {"value": "10", "precision": 20}, "raw_original_shipping_tax_total": {"value": "0", "precision": 20}}}}}, "create-order": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {"id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "email": "abc@test.com", "items": [{"id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "title": "Medusa Shorts", "detail": {"id": "orditem_01KPWECVRNC3DH6NSV32MJ3EAM", "item_id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "L", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "adjustments": [], "is_giftcard": false, "variant_sku": "SHORTS-L", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa Shorts", "variant_title": "L", "product_handle": "shorts", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}, {"id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "title": "Medusa T-Shirt", "detail": {"id": "orditem_01KPWECVRPYM0PXNKK5H0P07ZT", "item_id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "M / Black", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "adjustments": [], "is_giftcard": false, "variant_sku": "SHIRT-M-BLACK", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa T-Shirt", "variant_title": "M / Black", "product_handle": "t-shirt", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}], "locale": null, "status": "pending", "summary": {"paid_total": 0, "raw_paid_total": {"value": "0", "precision": 20}, "refunded_total": 0, "accounting_total": 30, "credit_line_total": 0, "transaction_total": 0, "pending_difference": 30, "raw_refunded_total": {"value": "0", "precision": 20}, "current_order_total": 30, "original_order_total": 30, "raw_accounting_total": {"value": "30", "precision": 20}, "raw_credit_line_total": {"value": "0", "precision": 20}, "raw_transaction_total": {"value": "0", "precision": 20}, "raw_pending_difference": {"value": "30", "precision": 20}, "raw_current_order_total": {"value": "30", "precision": 20}, "raw_original_order_total": {"value": "30", "precision": 20}}, "version": 1, "metadata": null, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "created_at": "2026-04-23T05:53:22.711Z", "deleted_at": null, "display_id": 1, "updated_at": "2026-04-23T05:53:22.711Z", "canceled_at": null, "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "credit_lines": [], "transactions": [], "currency_code": "eur", "is_draft_order": false, "billing_address": {"id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.254Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.254Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "no_notification": false, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.255Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "shipping_methods": [{"id": "ordsm_01KPWECVRG62SZ4NV07AF518C6", "data": {}, "name": "Standard Shipping", "amount": 10, "detail": {"id": "ordspmv_01KPWECVRHYSBBJ5SAQR7PPBBF", "version": 1, "claim_id": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "return_id": null, "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "updated_at": "2026-04-23T05:53:22.713Z", "exchange_id": null, "shipping_method_id": "ordsm_01KPWECVRG62SZ4NV07AF518C6"}, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "tax_lines": [], "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "raw_amount": {"value": "10", "precision": 20}, "updated_at": "2026-04-23T05:53:22.713Z", "adjustments": [], "description": null, "is_custom_amount": false, "is_tax_inclusive": false, "shipping_option_id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S"}], "custom_display_id": null, "billing_address_id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "shipping_address_id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD"}, "compensateInput": {"id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "email": "abc@test.com", "items": [{"id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "title": "Medusa Shorts", "detail": {"id": "orditem_01KPWECVRNC3DH6NSV32MJ3EAM", "item_id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "L", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "adjustments": [], "is_giftcard": false, "variant_sku": "SHORTS-L", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa Shorts", "variant_title": "L", "product_handle": "shorts", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}, {"id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "title": "Medusa T-Shirt", "detail": {"id": "orditem_01KPWECVRPYM0PXNKK5H0P07ZT", "item_id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "M / Black", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "adjustments": [], "is_giftcard": false, "variant_sku": "SHIRT-M-BLACK", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa T-Shirt", "variant_title": "M / Black", "product_handle": "t-shirt", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}], "locale": null, "status": "pending", "summary": {"paid_total": 0, "raw_paid_total": {"value": "0", "precision": 20}, "refunded_total": 0, "accounting_total": 30, "credit_line_total": 0, "transaction_total": 0, "pending_difference": 30, "raw_refunded_total": {"value": "0", "precision": 20}, "current_order_total": 30, "original_order_total": 30, "raw_accounting_total": {"value": "30", "precision": 20}, "raw_credit_line_total": {"value": "0", "precision": 20}, "raw_transaction_total": {"value": "0", "precision": 20}, "raw_pending_difference": {"value": "30", "precision": 20}, "raw_current_order_total": {"value": "30", "precision": 20}, "raw_original_order_total": {"value": "30", "precision": 20}}, "version": 1, "metadata": null, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "created_at": "2026-04-23T05:53:22.711Z", "deleted_at": null, "display_id": 1, "updated_at": "2026-04-23T05:53:22.711Z", "canceled_at": null, "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "credit_lines": [], "transactions": [], "currency_code": "eur", "is_draft_order": false, "billing_address": {"id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.254Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.254Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "no_notification": false, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.255Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "shipping_methods": [{"id": "ordsm_01KPWECVRG62SZ4NV07AF518C6", "data": {}, "name": "Standard Shipping", "amount": 10, "detail": {"id": "ordspmv_01KPWECVRHYSBBJ5SAQR7PPBBF", "version": 1, "claim_id": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "return_id": null, "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "updated_at": "2026-04-23T05:53:22.713Z", "exchange_id": null, "shipping_method_id": "ordsm_01KPWECVRG62SZ4NV07AF518C6"}, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "tax_lines": [], "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "raw_amount": {"value": "10", "precision": 20}, "updated_at": "2026-04-23T05:53:22.713Z", "adjustments": [], "description": null, "is_custom_amount": false, "is_tax_inclusive": false, "shipping_option_id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S"}], "custom_display_id": null, "billing_address_id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "shipping_address_id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD"}}}, "orderCreated": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)"}}, "update-carts": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": [{"id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "email": "abc@test.com", "locale": null, "metadata": null, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "created_at": "2026-04-22T20:51:00.700Z", "deleted_at": null, "updated_at": "2026-04-23T05:53:22.864Z", "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "completed_at": "2026-04-23T05:53:22.825Z", "currency_code": "eur", "billing_address": {"id": "caaddr_01KPWECTB5EWABMKQHQ68ZZMVW"}, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "caaddr_01KPWECTB6A4308W48ET511SKW"}, "billing_address_id": "caaddr_01KPWECTB5EWABMKQHQ68ZZMVW", "shipping_address_id": "caaddr_01KPWECTB6A4308W48ET511SKW"}], "compensateInput": {"cartsBeforeUpdate": [{"id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3", "email": "abc@test.com", "metadata": null, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "completed_at": null, "currency_code": "eur", "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX"}], "addressesBeforeUpdate": []}}}, "create-orders": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": [{"id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "email": "abc@test.com", "items": [{"id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "title": "Medusa Shorts", "detail": {"id": "orditem_01KPWECVRNC3DH6NSV32MJ3EAM", "item_id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "L", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/shorts-vintage-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEJJVJAJJ25FQ1CF4QP", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ6HYMRDT21HFF4V4KC", "adjustments": [], "is_giftcard": false, "variant_sku": "SHORTS-L", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa Shorts", "variant_title": "L", "product_handle": "shorts", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of classic shorts. With our cotton shorts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}, {"id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "title": "Medusa T-Shirt", "detail": {"id": "orditem_01KPWECVRPYM0PXNKK5H0P07ZT", "item_id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "version": 1, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "quantity": 1, "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "unit_price": null, "updated_at": "2026-04-23T05:53:22.712Z", "raw_quantity": {"value": "1", "precision": 20}, "raw_unit_price": null, "shipped_quantity": 0, "delivered_quantity": 0, "fulfilled_quantity": 0, "raw_shipped_quantity": {"value": "0", "precision": 20}, "written_off_quantity": 0, "compare_at_unit_price": null, "raw_delivered_quantity": {"value": "0", "precision": 20}, "raw_fulfilled_quantity": {"value": "0", "precision": 20}, "raw_written_off_quantity": {"value": "0", "precision": 20}, "return_received_quantity": 0, "raw_compare_at_unit_price": null, "return_dismissed_quantity": 0, "return_requested_quantity": 0, "raw_return_received_quantity": {"value": "0", "precision": 20}, "raw_return_dismissed_quantity": {"value": "0", "precision": 20}, "raw_return_requested_quantity": {"value": "0", "precision": 20}}, "metadata": {}, "quantity": 1, "subtitle": "M / Black", "tax_lines": [], "thumbnail": "https://medusa-public-images.s3.eu-west-1.amazonaws.com/tee-black-front.png", "created_at": "2026-04-23T05:53:22.712Z", "deleted_at": null, "product_id": "prod_01KPVEFMEHWRKFH07N2Q5W9PF9", "unit_price": 10, "updated_at": "2026-04-23T05:53:22.712Z", "variant_id": "variant_01KPVEFMJ1HNRT3FEDNGXBVEE6", "adjustments": [], "is_giftcard": false, "variant_sku": "SHIRT-M-BLACK", "product_type": null, "raw_quantity": {"value": "1", "precision": 20}, "product_title": "Medusa T-Shirt", "variant_title": "M / Black", "product_handle": "t-shirt", "raw_unit_price": {"value": "10", "precision": 20}, "is_custom_price": false, "is_discountable": true, "product_type_id": null, "variant_barcode": null, "is_tax_inclusive": false, "product_subtitle": null, "requires_shipping": true, "product_collection": null, "product_description": "Reimagine the feeling of a classic T-shirt. With our cotton T-shirts, everyday essentials no longer have to be ordinary.", "compare_at_unit_price": null, "variant_option_values": null, "raw_compare_at_unit_price": null}], "locale": null, "status": "pending", "summary": {"paid_total": 0, "raw_paid_total": {"value": "0", "precision": 20}, "refunded_total": 0, "accounting_total": 30, "credit_line_total": 0, "transaction_total": 0, "pending_difference": 30, "raw_refunded_total": {"value": "0", "precision": 20}, "current_order_total": 30, "original_order_total": 30, "raw_accounting_total": {"value": "30", "precision": 20}, "raw_credit_line_total": {"value": "0", "precision": 20}, "raw_transaction_total": {"value": "0", "precision": 20}, "raw_pending_difference": {"value": "30", "precision": 20}, "raw_current_order_total": {"value": "30", "precision": 20}, "raw_original_order_total": {"value": "30", "precision": 20}}, "version": 1, "metadata": null, "region_id": "reg_01KPVEFKYDPAKWC7499ZXE0DY9", "created_at": "2026-04-23T05:53:22.711Z", "deleted_at": null, "display_id": 1, "updated_at": "2026-04-23T05:53:22.711Z", "canceled_at": null, "customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "credit_lines": [], "transactions": [], "currency_code": "eur", "is_draft_order": false, "billing_address": {"id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.254Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.254Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "no_notification": false, "sales_channel_id": "sc_01KPVEFEV595D4YCDP15QR7DDX", "shipping_address": {"id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD", "city": "Kl", "phone": "", "company": null, "metadata": null, "province": "Kl", "address_1": "Test", "address_2": "", "last_name": "Test", "created_at": "2026-04-23T05:53:21.255Z", "deleted_at": null, "first_name": "Test", "updated_at": "2026-04-23T05:53:21.255Z", "customer_id": null, "postal_code": "56000", "country_code": "dk"}, "shipping_methods": [{"id": "ordsm_01KPWECVRG62SZ4NV07AF518C6", "data": {}, "name": "Standard Shipping", "amount": 10, "detail": {"id": "ordspmv_01KPWECVRHYSBBJ5SAQR7PPBBF", "version": 1, "claim_id": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "return_id": null, "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "updated_at": "2026-04-23T05:53:22.713Z", "exchange_id": null, "shipping_method_id": "ordsm_01KPWECVRG62SZ4NV07AF518C6"}, "metadata": null, "order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0", "tax_lines": [], "created_at": "2026-04-23T05:53:22.713Z", "deleted_at": null, "raw_amount": {"value": "10", "precision": 20}, "updated_at": "2026-04-23T05:53:22.713Z", "adjustments": [], "description": null, "is_custom_amount": false, "is_tax_inclusive": false, "shipping_option_id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S"}], "custom_display_id": null, "billing_address_id": "ordaddr_01KPWECVR8F31RVWQS9T69F2MY", "shipping_address_id": "ordaddr_01KPWECVR8WJ77PPKK5SDGGSVD"}], "compensateInput": ["order_01KPWECVRHA1YDZSXFAMWKRNA0"]}}, "register-usage": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": null, "compensateInput": {"computedActions": [], "registrationContext": {"customer_id": "cus_01KPWECT9YXCHTFC2E10XC38M3", "customer_email": "abc@test.com"}}}}, "emit-event-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {"eventName": "order.placed", "eventGroupId": "01KPWECVM716QAAFVB5KQCF9W1"}, "compensateInput": {"eventName": "order.placed", "eventGroupId": "01KPWECVM716QAAFVB5KQCF9W1"}}}, "acquire-lock-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "compensateInput": {"keys": ["cart_01KPVFBRERNG8Q0RM3RRR1FDS3"]}}}, "release-lock-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": true, "compensateInput": true}}, "validate-shipping": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)"}}, "create-remote-links": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": [{"cart": {"cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3"}, "order": {"order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0"}}, {"order": {"order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0"}, "payment": {"payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}}], "compensateInput": [{"cart": {"cart_id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3"}, "order": {"order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0"}}, {"order": {"order_id": "order_01KPWECVRHA1YDZSXFAMWKRNA0"}, "payment": {"payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}}]}}, "use-query-graph-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {}, "compensateInput": {}}}, "add-order-transaction": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": null, "compensateInput": null}}, "reserve-inventory-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": [{"id": "resitem_01KPWECVWZCVAZFRHGXSVFFX2D", "metadata": null, "quantity": 1, "created_at": "2026-04-23T05:53:22.854Z", "created_by": null, "deleted_at": null, "updated_at": "2026-04-23T05:53:22.854Z", "description": null, "external_id": null, "location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "line_item_id": "ordli_01KPWECVRM631BSED4QY9H1P8V", "raw_quantity": {"value": "1", "precision": 20}, "allow_backorder": false, "inventory_item_id": "iitem_01KPVEFMKS3XS0V9HWQS8R8GE7"}, {"id": "resitem_01KPWECVWZ0REGNYQB5ABN4Z7N", "metadata": null, "quantity": 1, "created_at": "2026-04-23T05:53:22.854Z", "created_by": null, "deleted_at": null, "updated_at": "2026-04-23T05:53:22.854Z", "description": null, "external_id": null, "location_id": "sloc_01KPVEFM42ZJTNM67Y2CX3R9X7", "line_item_id": "ordli_01KPWECVRMEM3WEM6VW45WG6AN", "raw_quantity": {"value": "1", "precision": 20}, "allow_backorder": false, "inventory_item_id": "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS"}], "compensateInput": {"reservations": ["resitem_01KPWECVWZCVAZFRHGXSVFFX2D", "resitem_01KPWECVWZ0REGNYQB5ABN4Z7N"], "inventoryItemIds": ["iitem_01KPVEFMKS3XS0V9HWQS8R8GE7", "iitem_01KPVEFMKPAZEYXJDKZHAPD0CS"]}}}, "shipping-options-query": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {"data": [{"id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S", "shipping_profile_id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}]}, "compensateInput": {"data": [{"id": "so_01KPVEFM8VS58X5XS6Z6PA0X3S", "shipping_profile_id": "sp_01KPVEF9GRG5TZYZBKN2ZMGT84"}]}}}, "validate-cart-payments": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": [{"id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "data": {}, "amount": 30, "status": "pending", "context": {}, "metadata": {}, "created_at": "2026-04-23T05:53:22.524Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.524Z", "provider_id": "pp_system_default", "authorized_at": null, "currency_code": "eur", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}], "compensateInput": [{"id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "data": {}, "amount": 30, "status": "pending", "context": {}, "metadata": {}, "created_at": "2026-04-23T05:53:22.524Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.524Z", "provider_id": "pp_system_default", "authorized_at": null, "currency_code": "eur", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}]}}, "beforePaymentAuthorization": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)"}}, "compensate-payment-if-needed": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "compensateInput": "payses_01KPWECVJWKW3HF9HQQZ25K7RS"}}, "authorize-payment-session-step": {"__type": "Symbol(WorkflowWorkflowData)", "output": {"__type": "Symbol(WorkflowStepResponse)", "output": {"id": "pay_01KPWECVYNNQ39CB87ZBENA1DG", "data": {}, "amount": 30, "captures": [], "metadata": null, "created_at": "2026-04-23T05:53:22.902Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.902Z", "canceled_at": null, "captured_at": null, "provider_id": "pp_system_default", "currency_code": "eur", "payment_collection": {"id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}, "payment_session_id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}, "compensateInput": {"id": "pay_01KPWECVYNNQ39CB87ZBENA1DG", "data": {}, "amount": 30, "captures": [], "metadata": null, "created_at": "2026-04-23T05:53:22.902Z", "deleted_at": null, "raw_amount": {"value": "30", "precision": 20}, "updated_at": "2026-04-23T05:53:22.902Z", "canceled_at": null, "captured_at": null, "provider_id": "pp_system_default", "currency_code": "eur", "payment_collection": {"id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}, "payment_session_id": "payses_01KPWECVJWKW3HF9HQQZ25K7RS", "payment_collection_id": "pay_col_01KPWECVGHJW90KXQ708NJQRS2"}}}}, "payload": {"id": "cart_01KPVFBRERNG8Q0RM3RRR1FDS3"}, "compensate": {}}, "errors": []}	done	2026-04-23 05:53:22.58	2026-04-23 05:53:22.984	\N	259200	01KPWECVMA0816B52YN10FWSHR
\.


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."link_module_migrations_id_seq"', 100, true);


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."mikro_orm_migrations_id_seq"', 167, true);


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_change_action_ordering_seq"', 1, true);


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_claim_display_id_seq"', 1, false);


--
-- Name: order_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_display_id_seq"', 1, true);


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_exchange_display_id_seq"', 1, false);


--
-- Name: return_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."return_display_id_seq"', 1, false);


--
-- Name: script_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."script_migrations_id_seq"', 2, true);


--
-- Name: account_holder account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."account_holder"
    ADD CONSTRAINT "account_holder_pkey" PRIMARY KEY ("id");


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."api_key"
    ADD CONSTRAINT "api_key_pkey" PRIMARY KEY ("id");


--
-- Name: application_method_buy_rules application_method_buy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_buy_rules"
    ADD CONSTRAINT "application_method_buy_rules_pkey" PRIMARY KEY ("application_method_id", "promotion_rule_id");


--
-- Name: application_method_target_rules application_method_target_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_target_rules"
    ADD CONSTRAINT "application_method_target_rules_pkey" PRIMARY KEY ("application_method_id", "promotion_rule_id");


--
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_identity"
    ADD CONSTRAINT "auth_identity_pkey" PRIMARY KEY ("id");


--
-- Name: banner banner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."banner"
    ADD CONSTRAINT "banner_pkey" PRIMARY KEY ("id");


--
-- Name: blog_post blog_post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."blog_post"
    ADD CONSTRAINT "blog_post_pkey" PRIMARY KEY ("id");


--
-- Name: capture capture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."capture"
    ADD CONSTRAINT "capture_pkey" PRIMARY KEY ("id");


--
-- Name: cart_address cart_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_address"
    ADD CONSTRAINT "cart_address_pkey" PRIMARY KEY ("id");


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item_adjustment"
    ADD CONSTRAINT "cart_line_item_adjustment_pkey" PRIMARY KEY ("id");


--
-- Name: cart_line_item cart_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item"
    ADD CONSTRAINT "cart_line_item_pkey" PRIMARY KEY ("id");


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item_tax_line"
    ADD CONSTRAINT "cart_line_item_tax_line_pkey" PRIMARY KEY ("id");


--
-- Name: cart_payment_collection cart_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_payment_collection"
    ADD CONSTRAINT "cart_payment_collection_pkey" PRIMARY KEY ("cart_id", "payment_collection_id");


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart"
    ADD CONSTRAINT "cart_pkey" PRIMARY KEY ("id");


--
-- Name: cart_promotion cart_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_promotion"
    ADD CONSTRAINT "cart_promotion_pkey" PRIMARY KEY ("cart_id", "promotion_id");


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method_adjustment"
    ADD CONSTRAINT "cart_shipping_method_adjustment_pkey" PRIMARY KEY ("id");


--
-- Name: cart_shipping_method cart_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method"
    ADD CONSTRAINT "cart_shipping_method_pkey" PRIMARY KEY ("id");


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method_tax_line"
    ADD CONSTRAINT "cart_shipping_method_tax_line_pkey" PRIMARY KEY ("id");


--
-- Name: credit_line credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."credit_line"
    ADD CONSTRAINT "credit_line_pkey" PRIMARY KEY ("id");


--
-- Name: currency currency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."currency"
    ADD CONSTRAINT "currency_pkey" PRIMARY KEY ("code");


--
-- Name: customer_account_holder customer_account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_account_holder"
    ADD CONSTRAINT "customer_account_holder_pkey" PRIMARY KEY ("customer_id", "account_holder_id");


--
-- Name: customer_address customer_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_address"
    ADD CONSTRAINT "customer_address_pkey" PRIMARY KEY ("id");


--
-- Name: customer_group_customer customer_group_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_group_customer"
    ADD CONSTRAINT "customer_group_customer_pkey" PRIMARY KEY ("id");


--
-- Name: customer_group customer_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_group"
    ADD CONSTRAINT "customer_group_pkey" PRIMARY KEY ("id");


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer"
    ADD CONSTRAINT "customer_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment_address fulfillment_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_address"
    ADD CONSTRAINT "fulfillment_address_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment_item fulfillment_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_item"
    ADD CONSTRAINT "fulfillment_item_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment_label fulfillment_label_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_label"
    ADD CONSTRAINT "fulfillment_label_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment"
    ADD CONSTRAINT "fulfillment_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment_provider fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_provider"
    ADD CONSTRAINT "fulfillment_provider_pkey" PRIMARY KEY ("id");


--
-- Name: fulfillment_set fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_set"
    ADD CONSTRAINT "fulfillment_set_pkey" PRIMARY KEY ("id");


--
-- Name: geo_zone geo_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."geo_zone"
    ADD CONSTRAINT "geo_zone_pkey" PRIMARY KEY ("id");


--
-- Name: image image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."image"
    ADD CONSTRAINT "image_pkey" PRIMARY KEY ("id");


--
-- Name: inventory_item inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."inventory_item"
    ADD CONSTRAINT "inventory_item_pkey" PRIMARY KEY ("id");


--
-- Name: inventory_level inventory_level_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."inventory_level"
    ADD CONSTRAINT "inventory_level_pkey" PRIMARY KEY ("id");


--
-- Name: invite invite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invite"
    ADD CONSTRAINT "invite_pkey" PRIMARY KEY ("id");


--
-- Name: invite_rbac_role invite_rbac_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invite_rbac_role"
    ADD CONSTRAINT "invite_rbac_role_pkey" PRIMARY KEY ("invite_id", "rbac_role_id");


--
-- Name: link_module_migrations link_module_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."link_module_migrations"
    ADD CONSTRAINT "link_module_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: link_module_migrations link_module_migrations_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."link_module_migrations"
    ADD CONSTRAINT "link_module_migrations_table_name_key" UNIQUE ("table_name");


--
-- Name: location_fulfillment_provider location_fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."location_fulfillment_provider"
    ADD CONSTRAINT "location_fulfillment_provider_pkey" PRIMARY KEY ("stock_location_id", "fulfillment_provider_id");


--
-- Name: location_fulfillment_set location_fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."location_fulfillment_set"
    ADD CONSTRAINT "location_fulfillment_set_pkey" PRIMARY KEY ("stock_location_id", "fulfillment_set_id");


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."menu_item"
    ADD CONSTRAINT "menu_item_pkey" PRIMARY KEY ("id");


--
-- Name: mikro_orm_migrations mikro_orm_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."mikro_orm_migrations"
    ADD CONSTRAINT "mikro_orm_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notification"
    ADD CONSTRAINT "notification_pkey" PRIMARY KEY ("id");


--
-- Name: notification_provider notification_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notification_provider"
    ADD CONSTRAINT "notification_provider_pkey" PRIMARY KEY ("id");


--
-- Name: order_address order_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_address"
    ADD CONSTRAINT "order_address_pkey" PRIMARY KEY ("id");


--
-- Name: order_cart order_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_cart"
    ADD CONSTRAINT "order_cart_pkey" PRIMARY KEY ("order_id", "cart_id");


--
-- Name: order_change_action order_change_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_change_action"
    ADD CONSTRAINT "order_change_action_pkey" PRIMARY KEY ("id");


--
-- Name: order_change order_change_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_change"
    ADD CONSTRAINT "order_change_pkey" PRIMARY KEY ("id");


--
-- Name: order_claim_item_image order_claim_item_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_claim_item_image"
    ADD CONSTRAINT "order_claim_item_image_pkey" PRIMARY KEY ("id");


--
-- Name: order_claim_item order_claim_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_claim_item"
    ADD CONSTRAINT "order_claim_item_pkey" PRIMARY KEY ("id");


--
-- Name: order_claim order_claim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_claim"
    ADD CONSTRAINT "order_claim_pkey" PRIMARY KEY ("id");


--
-- Name: order_credit_line order_credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_credit_line"
    ADD CONSTRAINT "order_credit_line_pkey" PRIMARY KEY ("id");


--
-- Name: order_exchange_item order_exchange_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_exchange_item"
    ADD CONSTRAINT "order_exchange_item_pkey" PRIMARY KEY ("id");


--
-- Name: order_exchange order_exchange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_exchange"
    ADD CONSTRAINT "order_exchange_pkey" PRIMARY KEY ("id");


--
-- Name: order_fulfillment order_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_fulfillment"
    ADD CONSTRAINT "order_fulfillment_pkey" PRIMARY KEY ("order_id", "fulfillment_id");


--
-- Name: order_item order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_item"
    ADD CONSTRAINT "order_item_pkey" PRIMARY KEY ("id");


--
-- Name: order_line_item_adjustment order_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item_adjustment"
    ADD CONSTRAINT "order_line_item_adjustment_pkey" PRIMARY KEY ("id");


--
-- Name: order_line_item order_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item"
    ADD CONSTRAINT "order_line_item_pkey" PRIMARY KEY ("id");


--
-- Name: order_line_item_tax_line order_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item_tax_line"
    ADD CONSTRAINT "order_line_item_tax_line_pkey" PRIMARY KEY ("id");


--
-- Name: order_payment_collection order_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_payment_collection"
    ADD CONSTRAINT "order_payment_collection_pkey" PRIMARY KEY ("order_id", "payment_collection_id");


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order"
    ADD CONSTRAINT "order_pkey" PRIMARY KEY ("id");


--
-- Name: order_promotion order_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_promotion"
    ADD CONSTRAINT "order_promotion_pkey" PRIMARY KEY ("order_id", "promotion_id");


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping_method_adjustment"
    ADD CONSTRAINT "order_shipping_method_adjustment_pkey" PRIMARY KEY ("id");


--
-- Name: order_shipping_method order_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping_method"
    ADD CONSTRAINT "order_shipping_method_pkey" PRIMARY KEY ("id");


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping_method_tax_line"
    ADD CONSTRAINT "order_shipping_method_tax_line_pkey" PRIMARY KEY ("id");


--
-- Name: order_shipping order_shipping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping"
    ADD CONSTRAINT "order_shipping_pkey" PRIMARY KEY ("id");


--
-- Name: order_summary order_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_summary"
    ADD CONSTRAINT "order_summary_pkey" PRIMARY KEY ("id");


--
-- Name: order_transaction order_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_transaction"
    ADD CONSTRAINT "order_transaction_pkey" PRIMARY KEY ("id");


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."page"
    ADD CONSTRAINT "page_pkey" PRIMARY KEY ("id");


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_collection_payment_providers"
    ADD CONSTRAINT "payment_collection_payment_providers_pkey" PRIMARY KEY ("payment_collection_id", "payment_provider_id");


--
-- Name: payment_collection payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_collection"
    ADD CONSTRAINT "payment_collection_pkey" PRIMARY KEY ("id");


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment"
    ADD CONSTRAINT "payment_pkey" PRIMARY KEY ("id");


--
-- Name: payment_provider payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_provider"
    ADD CONSTRAINT "payment_provider_pkey" PRIMARY KEY ("id");


--
-- Name: payment_session payment_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_session"
    ADD CONSTRAINT "payment_session_pkey" PRIMARY KEY ("id");


--
-- Name: price_list price_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_list"
    ADD CONSTRAINT "price_list_pkey" PRIMARY KEY ("id");


--
-- Name: price_list_rule price_list_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_list_rule"
    ADD CONSTRAINT "price_list_rule_pkey" PRIMARY KEY ("id");


--
-- Name: price price_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price"
    ADD CONSTRAINT "price_pkey" PRIMARY KEY ("id");


--
-- Name: price_preference price_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_preference"
    ADD CONSTRAINT "price_preference_pkey" PRIMARY KEY ("id");


--
-- Name: price_rule price_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_rule"
    ADD CONSTRAINT "price_rule_pkey" PRIMARY KEY ("id");


--
-- Name: price_set price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_set"
    ADD CONSTRAINT "price_set_pkey" PRIMARY KEY ("id");


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_category"
    ADD CONSTRAINT "product_category_pkey" PRIMARY KEY ("id");


--
-- Name: product_category_product product_category_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_category_product"
    ADD CONSTRAINT "product_category_product_pkey" PRIMARY KEY ("product_id", "product_category_id");


--
-- Name: product_collection product_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_collection"
    ADD CONSTRAINT "product_collection_pkey" PRIMARY KEY ("id");


--
-- Name: product_option product_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_option"
    ADD CONSTRAINT "product_option_pkey" PRIMARY KEY ("id");


--
-- Name: product_option_value product_option_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_option_value"
    ADD CONSTRAINT "product_option_value_pkey" PRIMARY KEY ("id");


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product"
    ADD CONSTRAINT "product_pkey" PRIMARY KEY ("id");


--
-- Name: product_sales_channel product_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_sales_channel"
    ADD CONSTRAINT "product_sales_channel_pkey" PRIMARY KEY ("product_id", "sales_channel_id");


--
-- Name: product_shipping_profile product_shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_shipping_profile"
    ADD CONSTRAINT "product_shipping_profile_pkey" PRIMARY KEY ("product_id", "shipping_profile_id");


--
-- Name: product_tag product_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_tag"
    ADD CONSTRAINT "product_tag_pkey" PRIMARY KEY ("id");


--
-- Name: product_tags product_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_tags"
    ADD CONSTRAINT "product_tags_pkey" PRIMARY KEY ("product_id", "product_tag_id");


--
-- Name: product_type product_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_type"
    ADD CONSTRAINT "product_type_pkey" PRIMARY KEY ("id");


--
-- Name: product_variant_inventory_item product_variant_inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_inventory_item"
    ADD CONSTRAINT "product_variant_inventory_item_pkey" PRIMARY KEY ("variant_id", "inventory_item_id");


--
-- Name: product_variant_option product_variant_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_option"
    ADD CONSTRAINT "product_variant_option_pkey" PRIMARY KEY ("variant_id", "option_value_id");


--
-- Name: product_variant product_variant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant"
    ADD CONSTRAINT "product_variant_pkey" PRIMARY KEY ("id");


--
-- Name: product_variant_price_set product_variant_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_price_set"
    ADD CONSTRAINT "product_variant_price_set_pkey" PRIMARY KEY ("variant_id", "price_set_id");


--
-- Name: product_variant_product_image product_variant_product_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_product_image"
    ADD CONSTRAINT "product_variant_product_image_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_application_method promotion_application_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_application_method"
    ADD CONSTRAINT "promotion_application_method_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_campaign_budget promotion_campaign_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_campaign_budget"
    ADD CONSTRAINT "promotion_campaign_budget_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_campaign_budget_usage promotion_campaign_budget_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_campaign_budget_usage"
    ADD CONSTRAINT "promotion_campaign_budget_usage_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_campaign promotion_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_campaign"
    ADD CONSTRAINT "promotion_campaign_pkey" PRIMARY KEY ("id");


--
-- Name: promotion promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion"
    ADD CONSTRAINT "promotion_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_promotion_rule promotion_promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_promotion_rule"
    ADD CONSTRAINT "promotion_promotion_rule_pkey" PRIMARY KEY ("promotion_id", "promotion_rule_id");


--
-- Name: promotion_rule promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_rule"
    ADD CONSTRAINT "promotion_rule_pkey" PRIMARY KEY ("id");


--
-- Name: promotion_rule_value promotion_rule_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_rule_value"
    ADD CONSTRAINT "promotion_rule_value_pkey" PRIMARY KEY ("id");


--
-- Name: provider_identity provider_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."provider_identity"
    ADD CONSTRAINT "provider_identity_pkey" PRIMARY KEY ("id");


--
-- Name: publishable_api_key_sales_channel publishable_api_key_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."publishable_api_key_sales_channel"
    ADD CONSTRAINT "publishable_api_key_sales_channel_pkey" PRIMARY KEY ("publishable_key_id", "sales_channel_id");


--
-- Name: refund refund_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."refund"
    ADD CONSTRAINT "refund_pkey" PRIMARY KEY ("id");


--
-- Name: refund_reason refund_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."refund_reason"
    ADD CONSTRAINT "refund_reason_pkey" PRIMARY KEY ("id");


--
-- Name: region_country region_country_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."region_country"
    ADD CONSTRAINT "region_country_pkey" PRIMARY KEY ("iso_2");


--
-- Name: region_payment_provider region_payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."region_payment_provider"
    ADD CONSTRAINT "region_payment_provider_pkey" PRIMARY KEY ("region_id", "payment_provider_id");


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."region"
    ADD CONSTRAINT "region_pkey" PRIMARY KEY ("id");


--
-- Name: reservation_item reservation_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservation_item"
    ADD CONSTRAINT "reservation_item_pkey" PRIMARY KEY ("id");


--
-- Name: return_fulfillment return_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return_fulfillment"
    ADD CONSTRAINT "return_fulfillment_pkey" PRIMARY KEY ("return_id", "fulfillment_id");


--
-- Name: return_item return_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return_item"
    ADD CONSTRAINT "return_item_pkey" PRIMARY KEY ("id");


--
-- Name: return return_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return"
    ADD CONSTRAINT "return_pkey" PRIMARY KEY ("id");


--
-- Name: return_reason return_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return_reason"
    ADD CONSTRAINT "return_reason_pkey" PRIMARY KEY ("id");


--
-- Name: sales_channel sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales_channel"
    ADD CONSTRAINT "sales_channel_pkey" PRIMARY KEY ("id");


--
-- Name: sales_channel_stock_location sales_channel_stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales_channel_stock_location"
    ADD CONSTRAINT "sales_channel_stock_location_pkey" PRIMARY KEY ("sales_channel_id", "stock_location_id");


--
-- Name: script_migrations script_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."script_migrations"
    ADD CONSTRAINT "script_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: service_zone service_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."service_zone"
    ADD CONSTRAINT "service_zone_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_option shipping_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option"
    ADD CONSTRAINT "shipping_option_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_option_price_set shipping_option_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option_price_set"
    ADD CONSTRAINT "shipping_option_price_set_pkey" PRIMARY KEY ("shipping_option_id", "price_set_id");


--
-- Name: shipping_option_rule shipping_option_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option_rule"
    ADD CONSTRAINT "shipping_option_rule_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_option_type shipping_option_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option_type"
    ADD CONSTRAINT "shipping_option_type_pkey" PRIMARY KEY ("id");


--
-- Name: shipping_profile shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_profile"
    ADD CONSTRAINT "shipping_profile_pkey" PRIMARY KEY ("id");


--
-- Name: site_config site_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."site_config"
    ADD CONSTRAINT "site_config_pkey" PRIMARY KEY ("id");


--
-- Name: stock_location_address stock_location_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stock_location_address"
    ADD CONSTRAINT "stock_location_address_pkey" PRIMARY KEY ("id");


--
-- Name: stock_location stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stock_location"
    ADD CONSTRAINT "stock_location_pkey" PRIMARY KEY ("id");


--
-- Name: store_currency store_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."store_currency"
    ADD CONSTRAINT "store_currency_pkey" PRIMARY KEY ("id");


--
-- Name: store_locale store_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."store_locale"
    ADD CONSTRAINT "store_locale_pkey" PRIMARY KEY ("id");


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."store"
    ADD CONSTRAINT "store_pkey" PRIMARY KEY ("id");


--
-- Name: tax_provider tax_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_provider"
    ADD CONSTRAINT "tax_provider_pkey" PRIMARY KEY ("id");


--
-- Name: tax_rate tax_rate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_rate"
    ADD CONSTRAINT "tax_rate_pkey" PRIMARY KEY ("id");


--
-- Name: tax_rate_rule tax_rate_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_rate_rule"
    ADD CONSTRAINT "tax_rate_rule_pkey" PRIMARY KEY ("id");


--
-- Name: tax_region tax_region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_region"
    ADD CONSTRAINT "tax_region_pkey" PRIMARY KEY ("id");


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user"
    ADD CONSTRAINT "user_pkey" PRIMARY KEY ("id");


--
-- Name: user_preference user_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user_preference"
    ADD CONSTRAINT "user_preference_pkey" PRIMARY KEY ("id");


--
-- Name: user_rbac_role user_rbac_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user_rbac_role"
    ADD CONSTRAINT "user_rbac_role_pkey" PRIMARY KEY ("user_id", "rbac_role_id");


--
-- Name: view_configuration view_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."view_configuration"
    ADD CONSTRAINT "view_configuration_pkey" PRIMARY KEY ("id");


--
-- Name: workflow_execution workflow_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."workflow_execution"
    ADD CONSTRAINT "workflow_execution_pkey" PRIMARY KEY ("workflow_id", "transaction_id", "run_id");


--
-- Name: IDX_account_holder_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_account_holder_deleted_at" ON "public"."account_holder" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_account_holder_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_account_holder_id_5cb3a0c0" ON "public"."customer_account_holder" USING "btree" ("account_holder_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_account_holder_provider_id_external_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_account_holder_provider_id_external_id_unique" ON "public"."account_holder" USING "btree" ("provider_id", "external_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_api_key_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_deleted_at" ON "public"."api_key" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_api_key_redacted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_redacted" ON "public"."api_key" USING "btree" ("redacted") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_api_key_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_revoked_at" ON "public"."api_key" USING "btree" ("revoked_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_api_key_token_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_api_key_token_unique" ON "public"."api_key" USING "btree" ("token");


--
-- Name: IDX_api_key_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_type" ON "public"."api_key" USING "btree" ("type");


--
-- Name: IDX_application_method_allocation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_allocation" ON "public"."promotion_application_method" USING "btree" ("allocation");


--
-- Name: IDX_application_method_target_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_target_type" ON "public"."promotion_application_method" USING "btree" ("target_type");


--
-- Name: IDX_application_method_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_type" ON "public"."promotion_application_method" USING "btree" ("type");


--
-- Name: IDX_auth_identity_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_identity_deleted_at" ON "public"."auth_identity" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_banner_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_banner_deleted_at" ON "public"."banner" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_blog_post_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_blog_post_deleted_at" ON "public"."blog_post" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_blog_post_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_blog_post_slug_unique" ON "public"."blog_post" USING "btree" ("slug") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_campaign_budget_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_campaign_budget_type" ON "public"."promotion_campaign_budget" USING "btree" ("type");


--
-- Name: IDX_capture_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_capture_deleted_at" ON "public"."capture" USING "btree" ("deleted_at");


--
-- Name: IDX_capture_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_capture_payment_id" ON "public"."capture" USING "btree" ("payment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_address_deleted_at" ON "public"."cart_address" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_billing_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_billing_address_id" ON "public"."cart" USING "btree" ("billing_address_id") WHERE (("deleted_at" IS NULL) AND ("billing_address_id" IS NOT NULL));


--
-- Name: IDX_cart_credit_line_reference_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_credit_line_reference_reference_id" ON "public"."credit_line" USING "btree" ("reference", "reference_id") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_currency_code" ON "public"."cart" USING "btree" ("currency_code");


--
-- Name: IDX_cart_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_customer_id" ON "public"."cart" USING "btree" ("customer_id") WHERE (("deleted_at" IS NULL) AND ("customer_id" IS NOT NULL));


--
-- Name: IDX_cart_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_deleted_at" ON "public"."cart" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-4a39f6c9" ON "public"."cart_payment_collection" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-71069c16" ON "public"."order_cart" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-a9d4a70b" ON "public"."cart_promotion" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_line_item_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_adjustment_deleted_at" ON "public"."cart_line_item_adjustment" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_adjustment_item_id" ON "public"."cart_line_item_adjustment" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_line_item_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_cart_id" ON "public"."cart_line_item" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_line_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_deleted_at" ON "public"."cart_line_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_tax_line_deleted_at" ON "public"."cart_line_item_tax_line" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_tax_line_item_id" ON "public"."cart_line_item_tax_line" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_region_id" ON "public"."cart" USING "btree" ("region_id") WHERE (("deleted_at" IS NULL) AND ("region_id" IS NOT NULL));


--
-- Name: IDX_cart_sales_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_sales_channel_id" ON "public"."cart" USING "btree" ("sales_channel_id") WHERE (("deleted_at" IS NULL) AND ("sales_channel_id" IS NOT NULL));


--
-- Name: IDX_cart_shipping_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_address_id" ON "public"."cart" USING "btree" ("shipping_address_id") WHERE (("deleted_at" IS NULL) AND ("shipping_address_id" IS NOT NULL));


--
-- Name: IDX_cart_shipping_method_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_deleted_at" ON "public"."cart_shipping_method_adjustment" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_shipping_method_id" ON "public"."cart_shipping_method_adjustment" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_shipping_method_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_cart_id" ON "public"."cart_shipping_method" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_cart_shipping_method_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_deleted_at" ON "public"."cart_shipping_method" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_deleted_at" ON "public"."cart_shipping_method_tax_line" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_shipping_method_id" ON "public"."cart_shipping_method_tax_line" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_category_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_category_handle_unique" ON "public"."product_category" USING "btree" ("handle") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_collection_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_collection_handle_unique" ON "public"."product_collection" USING "btree" ("handle") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_credit_line_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_credit_line_cart_id" ON "public"."credit_line" USING "btree" ("cart_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_credit_line_deleted_at" ON "public"."credit_line" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_address_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_address_customer_id" ON "public"."customer_address" USING "btree" ("customer_id");


--
-- Name: IDX_customer_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_address_deleted_at" ON "public"."customer_address" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_address_unique_customer_billing; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_billing" ON "public"."customer_address" USING "btree" ("customer_id") WHERE ("is_default_billing" = true);


--
-- Name: IDX_customer_address_unique_customer_shipping; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_shipping" ON "public"."customer_address" USING "btree" ("customer_id") WHERE ("is_default_shipping" = true);


--
-- Name: IDX_customer_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_deleted_at" ON "public"."customer" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_email_has_account_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_email_has_account_unique" ON "public"."customer" USING "btree" ("email", "has_account") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_group_customer_customer_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_customer_group_id" ON "public"."customer_group_customer" USING "btree" ("customer_group_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_group_customer_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_customer_id" ON "public"."customer_group_customer" USING "btree" ("customer_id");


--
-- Name: IDX_customer_group_customer_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_deleted_at" ON "public"."customer_group_customer" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_group_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_deleted_at" ON "public"."customer_group" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_group_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_group_name_unique" ON "public"."customer_group" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_customer_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_id_5cb3a0c0" ON "public"."customer_account_holder" USING "btree" ("customer_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_deleted_at_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-1e5992737" ON "public"."location_fulfillment_provider" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-31ea43a" ON "public"."return_fulfillment" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-4a39f6c9" ON "public"."cart_payment_collection" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-71069c16" ON "public"."order_cart" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-71518339" ON "public"."order_promotion" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-85069d44" ON "public"."invite_rbac_role" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-a9d4a70b" ON "public"."cart_promotion" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-e88adb96" ON "public"."location_fulfillment_set" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-e8d2543e" ON "public"."order_fulfillment" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_17a262437" ON "public"."product_shipping_profile" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_17b4c4e35" ON "public"."product_variant_inventory_item" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_1c934dab0" ON "public"."region_payment_provider" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_20b454295" ON "public"."product_sales_channel" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_26d06f470" ON "public"."sales_channel_stock_location" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_52b23597" ON "public"."product_variant_price_set" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_5cb3a0c0" ON "public"."customer_account_holder" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_64ff0c4c" ON "public"."user_rbac_role" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_ba32fa9c" ON "public"."shipping_option_price_set" USING "btree" ("deleted_at");


--
-- Name: IDX_deleted_at_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_f42b9949" ON "public"."order_payment_collection" USING "btree" ("deleted_at");


--
-- Name: IDX_fulfillment_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_address_deleted_at" ON "public"."fulfillment_address" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_fulfillment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_deleted_at" ON "public"."fulfillment" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_fulfillment_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_id_-31ea43a" ON "public"."return_fulfillment" USING "btree" ("fulfillment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_id_-e8d2543e" ON "public"."order_fulfillment" USING "btree" ("fulfillment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_deleted_at" ON "public"."fulfillment_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_fulfillment_item_fulfillment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_fulfillment_id" ON "public"."fulfillment_item" USING "btree" ("fulfillment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_item_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_inventory_item_id" ON "public"."fulfillment_item" USING "btree" ("inventory_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_item_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_line_item_id" ON "public"."fulfillment_item" USING "btree" ("line_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_label_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_label_deleted_at" ON "public"."fulfillment_label" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_fulfillment_label_fulfillment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_label_fulfillment_id" ON "public"."fulfillment_label" USING "btree" ("fulfillment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_location_id" ON "public"."fulfillment" USING "btree" ("location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_provider_deleted_at" ON "public"."fulfillment_provider" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_provider_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_provider_id_-1e5992737" ON "public"."location_fulfillment_provider" USING "btree" ("fulfillment_provider_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_set_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_set_deleted_at" ON "public"."fulfillment_set" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_fulfillment_set_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_set_id_-e88adb96" ON "public"."location_fulfillment_set" USING "btree" ("fulfillment_set_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_set_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_fulfillment_set_name_unique" ON "public"."fulfillment_set" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_fulfillment_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_shipping_option_id" ON "public"."fulfillment" USING "btree" ("shipping_option_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_geo_zone_city; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_city" ON "public"."geo_zone" USING "btree" ("city") WHERE (("deleted_at" IS NULL) AND ("city" IS NOT NULL));


--
-- Name: IDX_geo_zone_country_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_country_code" ON "public"."geo_zone" USING "btree" ("country_code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_geo_zone_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_deleted_at" ON "public"."geo_zone" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_geo_zone_province_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_province_code" ON "public"."geo_zone" USING "btree" ("province_code") WHERE (("deleted_at" IS NULL) AND ("province_code" IS NOT NULL));


--
-- Name: IDX_geo_zone_service_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_service_zone_id" ON "public"."geo_zone" USING "btree" ("service_zone_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING "btree" ("id");


--
-- Name: IDX_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-1e5992737" ON "public"."location_fulfillment_provider" USING "btree" ("id");


--
-- Name: IDX_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-31ea43a" ON "public"."return_fulfillment" USING "btree" ("id");


--
-- Name: IDX_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-4a39f6c9" ON "public"."cart_payment_collection" USING "btree" ("id");


--
-- Name: IDX_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-71069c16" ON "public"."order_cart" USING "btree" ("id");


--
-- Name: IDX_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-71518339" ON "public"."order_promotion" USING "btree" ("id");


--
-- Name: IDX_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-85069d44" ON "public"."invite_rbac_role" USING "btree" ("id");


--
-- Name: IDX_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-a9d4a70b" ON "public"."cart_promotion" USING "btree" ("id");


--
-- Name: IDX_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-e88adb96" ON "public"."location_fulfillment_set" USING "btree" ("id");


--
-- Name: IDX_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-e8d2543e" ON "public"."order_fulfillment" USING "btree" ("id");


--
-- Name: IDX_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_17a262437" ON "public"."product_shipping_profile" USING "btree" ("id");


--
-- Name: IDX_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING "btree" ("id");


--
-- Name: IDX_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_1c934dab0" ON "public"."region_payment_provider" USING "btree" ("id");


--
-- Name: IDX_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_20b454295" ON "public"."product_sales_channel" USING "btree" ("id");


--
-- Name: IDX_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_26d06f470" ON "public"."sales_channel_stock_location" USING "btree" ("id");


--
-- Name: IDX_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_52b23597" ON "public"."product_variant_price_set" USING "btree" ("id");


--
-- Name: IDX_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_5cb3a0c0" ON "public"."customer_account_holder" USING "btree" ("id");


--
-- Name: IDX_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_64ff0c4c" ON "public"."user_rbac_role" USING "btree" ("id");


--
-- Name: IDX_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_ba32fa9c" ON "public"."shipping_option_price_set" USING "btree" ("id");


--
-- Name: IDX_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_f42b9949" ON "public"."order_payment_collection" USING "btree" ("id");


--
-- Name: IDX_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_image_deleted_at" ON "public"."image" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_image_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_image_product_id" ON "public"."image" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_inventory_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_item_deleted_at" ON "public"."inventory_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_inventory_item_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_item_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING "btree" ("inventory_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_inventory_item_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_inventory_item_sku" ON "public"."inventory_item" USING "btree" ("sku") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_inventory_level_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_deleted_at" ON "public"."inventory_level" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_inventory_level_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_inventory_item_id" ON "public"."inventory_level" USING "btree" ("inventory_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_inventory_level_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_location_id" ON "public"."inventory_level" USING "btree" ("location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_inventory_level_location_id_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_inventory_level_location_id_inventory_item_id" ON "public"."inventory_level" USING "btree" ("inventory_item_id", "location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_invite_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_deleted_at" ON "public"."invite" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_invite_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_invite_email_unique" ON "public"."invite" USING "btree" ("email") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_invite_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_id_-85069d44" ON "public"."invite_rbac_role" USING "btree" ("invite_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_invite_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_token" ON "public"."invite" USING "btree" ("token") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_line_item_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_adjustment_promotion_id" ON "public"."cart_line_item_adjustment" USING "btree" ("promotion_id") WHERE (("deleted_at" IS NULL) AND ("promotion_id" IS NOT NULL));


--
-- Name: IDX_line_item_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_product_id" ON "public"."cart_line_item" USING "btree" ("product_id") WHERE (("deleted_at" IS NULL) AND ("product_id" IS NOT NULL));


--
-- Name: IDX_line_item_product_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_product_type_id" ON "public"."order_line_item" USING "btree" ("product_type_id") WHERE (("deleted_at" IS NULL) AND ("product_type_id" IS NOT NULL));


--
-- Name: IDX_line_item_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_tax_line_tax_rate_id" ON "public"."cart_line_item_tax_line" USING "btree" ("tax_rate_id") WHERE (("deleted_at" IS NULL) AND ("tax_rate_id" IS NOT NULL));


--
-- Name: IDX_line_item_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_variant_id" ON "public"."cart_line_item" USING "btree" ("variant_id") WHERE (("deleted_at" IS NULL) AND ("variant_id" IS NOT NULL));


--
-- Name: IDX_menu_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_menu_item_deleted_at" ON "public"."menu_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_notification_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_deleted_at" ON "public"."notification" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_notification_idempotency_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_notification_idempotency_key_unique" ON "public"."notification" USING "btree" ("idempotency_key") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_notification_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_provider_deleted_at" ON "public"."notification_provider" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_notification_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_provider_id" ON "public"."notification" USING "btree" ("provider_id");


--
-- Name: IDX_notification_receiver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_receiver_id" ON "public"."notification" USING "btree" ("receiver_id");


--
-- Name: IDX_option_product_id_title_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_option_product_id_title_unique" ON "public"."product_option" USING "btree" ("product_id", "title") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_option_value_option_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_option_value_option_id_unique" ON "public"."product_option_value" USING "btree" ("option_id", "value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_address_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_address_customer_id" ON "public"."order_address" USING "btree" ("customer_id");


--
-- Name: IDX_order_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_address_deleted_at" ON "public"."order_address" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_billing_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_billing_address_id" ON "public"."order" USING "btree" ("billing_address_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_action_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_claim_id" ON "public"."order_change_action" USING "btree" ("claim_id") WHERE (("claim_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_action_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_deleted_at" ON "public"."order_change_action" USING "btree" ("deleted_at");


--
-- Name: IDX_order_change_action_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_exchange_id" ON "public"."order_change_action" USING "btree" ("exchange_id") WHERE (("exchange_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_action_order_change_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_order_change_id" ON "public"."order_change_action" USING "btree" ("order_change_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_action_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_order_id" ON "public"."order_change_action" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_action_ordering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_ordering" ON "public"."order_change_action" USING "btree" ("ordering") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_action_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_return_id" ON "public"."order_change_action" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_change_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_change_type" ON "public"."order_change" USING "btree" ("change_type");


--
-- Name: IDX_order_change_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_claim_id" ON "public"."order_change" USING "btree" ("claim_id") WHERE (("claim_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_deleted_at" ON "public"."order_change" USING "btree" ("deleted_at");


--
-- Name: IDX_order_change_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_exchange_id" ON "public"."order_change" USING "btree" ("exchange_id") WHERE (("exchange_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_order_id" ON "public"."order_change" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_order_id_version" ON "public"."order_change" USING "btree" ("order_id", "version");


--
-- Name: IDX_order_change_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_return_id" ON "public"."order_change" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_change_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_status" ON "public"."order_change" USING "btree" ("status") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_change_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_version" ON "public"."order_change" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_deleted_at" ON "public"."order_claim" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_display_id" ON "public"."order_claim" USING "btree" ("display_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_item_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_claim_id" ON "public"."order_claim_item" USING "btree" ("claim_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_deleted_at" ON "public"."order_claim_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_item_image_claim_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_image_claim_item_id" ON "public"."order_claim_item_image" USING "btree" ("claim_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_item_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_image_deleted_at" ON "public"."order_claim_item_image" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_order_claim_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_item_id" ON "public"."order_claim_item" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_order_id" ON "public"."order_claim" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_claim_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_return_id" ON "public"."order_claim" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_deleted_at" ON "public"."order_credit_line" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_order_credit_line_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_order_id" ON "public"."order_credit_line" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_credit_line_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_order_id_version" ON "public"."order_credit_line" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_currency_code" ON "public"."order" USING "btree" ("currency_code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_custom_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_order_custom_display_id" ON "public"."order" USING "btree" ("custom_display_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_customer_id" ON "public"."order" USING "btree" ("customer_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_deleted_at" ON "public"."order" USING "btree" ("deleted_at");


--
-- Name: IDX_order_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_display_id" ON "public"."order" USING "btree" ("display_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_deleted_at" ON "public"."order_exchange" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_display_id" ON "public"."order_exchange" USING "btree" ("display_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_deleted_at" ON "public"."order_exchange_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_item_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_exchange_id" ON "public"."order_exchange_item" USING "btree" ("exchange_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_item_id" ON "public"."order_exchange_item" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_order_id" ON "public"."order_exchange" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_exchange_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_return_id" ON "public"."order_exchange" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-71069c16" ON "public"."order_cart" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-71518339" ON "public"."order_promotion" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-e8d2543e" ON "public"."order_fulfillment" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_f42b9949" ON "public"."order_payment_collection" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_is_draft_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_is_draft_order" ON "public"."order" USING "btree" ("is_draft_order") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_deleted_at" ON "public"."order_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_order_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_item_id" ON "public"."order_item" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_item_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_order_id" ON "public"."order_item" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_item_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_order_id_version" ON "public"."order_item" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_adjustment_item_id" ON "public"."order_line_item_adjustment" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_line_item_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_product_id" ON "public"."order_line_item" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_tax_line_item_id" ON "public"."order_line_item_tax_line" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_line_item_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_variant_id" ON "public"."order_line_item" USING "btree" ("variant_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_region_id" ON "public"."order" USING "btree" ("region_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_sales_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_sales_channel_id" ON "public"."order" USING "btree" ("sales_channel_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_address_id" ON "public"."order" USING "btree" ("shipping_address_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_claim_id" ON "public"."order_shipping" USING "btree" ("claim_id") WHERE (("claim_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_shipping_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_deleted_at" ON "public"."order_shipping" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_order_shipping_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_exchange_id" ON "public"."order_shipping" USING "btree" ("exchange_id") WHERE (("exchange_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_shipping_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_item_id" ON "public"."order_shipping" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_adjustment_shipping_method_id" ON "public"."order_shipping_method_adjustment" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_method_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_shipping_option_id" ON "public"."order_shipping_method" USING "btree" ("shipping_option_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_tax_line_shipping_method_id" ON "public"."order_shipping_method_tax_line" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_order_id" ON "public"."order_shipping" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_order_id_version" ON "public"."order_shipping" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_shipping_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_return_id" ON "public"."order_shipping" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_shipping_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_shipping_method_id" ON "public"."order_shipping" USING "btree" ("shipping_method_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_summary_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_summary_deleted_at" ON "public"."order_summary" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_order_summary_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_summary_order_id_version" ON "public"."order_summary" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_transaction_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_claim_id" ON "public"."order_transaction" USING "btree" ("claim_id") WHERE (("claim_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_transaction_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_currency_code" ON "public"."order_transaction" USING "btree" ("currency_code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_transaction_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_exchange_id" ON "public"."order_transaction" USING "btree" ("exchange_id") WHERE (("exchange_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_order_transaction_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_order_id" ON "public"."order_transaction" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_transaction_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_order_id_version" ON "public"."order_transaction" USING "btree" ("order_id", "version") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_transaction_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_reference_id" ON "public"."order_transaction" USING "btree" ("reference_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_order_transaction_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_return_id" ON "public"."order_transaction" USING "btree" ("return_id") WHERE (("return_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_page_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_page_deleted_at" ON "public"."page" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_page_slug_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_page_slug_unique" ON "public"."page" USING "btree" ("slug") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_collection_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_deleted_at" ON "public"."payment_collection" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_payment_collection_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_id_-4a39f6c9" ON "public"."cart_payment_collection" USING "btree" ("payment_collection_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_collection_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_id_f42b9949" ON "public"."order_payment_collection" USING "btree" ("payment_collection_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_deleted_at" ON "public"."payment" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_payment_payment_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_payment_collection_id" ON "public"."payment" USING "btree" ("payment_collection_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_payment_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_payment_session_id" ON "public"."payment" USING "btree" ("payment_session_id");


--
-- Name: IDX_payment_payment_session_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_payment_payment_session_id_unique" ON "public"."payment" USING "btree" ("payment_session_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_deleted_at" ON "public"."payment_provider" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_id" ON "public"."payment" USING "btree" ("provider_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_provider_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_id_1c934dab0" ON "public"."region_payment_provider" USING "btree" ("payment_provider_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_payment_session_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_session_deleted_at" ON "public"."payment_session" USING "btree" ("deleted_at");


--
-- Name: IDX_payment_session_payment_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_session_payment_collection_id" ON "public"."payment_session" USING "btree" ("payment_collection_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_currency_code" ON "public"."price" USING "btree" ("currency_code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_deleted_at" ON "public"."price" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_list_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_deleted_at" ON "public"."price_list" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_list_id_status_starts_at_ends_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_id_status_starts_at_ends_at" ON "public"."price_list" USING "btree" ("id", "status", "starts_at", "ends_at") WHERE (("deleted_at" IS NULL) AND ("status" = 'active'::"text"));


--
-- Name: IDX_price_list_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_attribute" ON "public"."price_list_rule" USING "btree" ("attribute") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_list_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_deleted_at" ON "public"."price_list_rule" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_list_rule_price_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_price_list_id" ON "public"."price_list_rule" USING "btree" ("price_list_id") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_list_rule_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_value" ON "public"."price_list_rule" USING "gin" ("value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_preference_attribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_price_preference_attribute_value" ON "public"."price_preference" USING "btree" ("attribute", "value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_preference_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_preference_deleted_at" ON "public"."price_preference" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_price_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_price_list_id" ON "public"."price" USING "btree" ("price_list_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_price_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_price_set_id" ON "public"."price" USING "btree" ("price_set_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute" ON "public"."price_rule" USING "btree" ("attribute") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_attribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute_value" ON "public"."price_rule" USING "btree" ("attribute", "value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_attribute_value_price_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute_value_price_id" ON "public"."price_rule" USING "btree" ("attribute", "value", "price_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_deleted_at" ON "public"."price_rule" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_rule_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_operator" ON "public"."price_rule" USING "btree" ("operator");


--
-- Name: IDX_price_rule_operator_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_operator_value" ON "public"."price_rule" USING "btree" ("operator", "value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_price_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_price_id" ON "public"."price_rule" USING "btree" ("price_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_rule_price_id_attribute_operator_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_price_rule_price_id_attribute_operator_unique" ON "public"."price_rule" USING "btree" ("price_id", "attribute", "operator") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_set_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_deleted_at" ON "public"."price_set" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_price_set_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_id_52b23597" ON "public"."product_variant_price_set" USING "btree" ("price_set_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_price_set_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_id_ba32fa9c" ON "public"."shipping_option_price_set" USING "btree" ("price_set_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_category_parent_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_category_parent_category_id" ON "public"."product_category" USING "btree" ("parent_category_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_category_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_category_path" ON "public"."product_category" USING "btree" ("mpath") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_collection_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_collection_deleted_at" ON "public"."product_collection" USING "btree" ("deleted_at");


--
-- Name: IDX_product_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_collection_id" ON "public"."product" USING "btree" ("collection_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_deleted_at" ON "public"."product" USING "btree" ("deleted_at");


--
-- Name: IDX_product_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_handle_unique" ON "public"."product" USING "btree" ("handle") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_id_17a262437" ON "public"."product_shipping_profile" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_id_20b454295" ON "public"."product_sales_channel" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_image_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_rank" ON "public"."image" USING "btree" ("rank") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_image_rank_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_rank_product_id" ON "public"."image" USING "btree" ("rank", "product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_image_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_url" ON "public"."image" USING "btree" ("url") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_image_url_rank_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_url_rank_product_id" ON "public"."image" USING "btree" ("url", "rank", "product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_option_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_deleted_at" ON "public"."product_option" USING "btree" ("deleted_at");


--
-- Name: IDX_product_option_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_product_id" ON "public"."product_option" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_option_value_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_value_deleted_at" ON "public"."product_option_value" USING "btree" ("deleted_at");


--
-- Name: IDX_product_option_value_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_value_option_id" ON "public"."product_option_value" USING "btree" ("option_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_status" ON "public"."product" USING "btree" ("status") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_tag_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_tag_deleted_at" ON "public"."product_tag" USING "btree" ("deleted_at");


--
-- Name: IDX_product_type_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_type_deleted_at" ON "public"."product_type" USING "btree" ("deleted_at");


--
-- Name: IDX_product_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_type_id" ON "public"."product" USING "btree" ("type_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_barcode_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_barcode_unique" ON "public"."product_variant" USING "btree" ("barcode") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_deleted_at" ON "public"."product_variant" USING "btree" ("deleted_at");


--
-- Name: IDX_product_variant_ean_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_ean_unique" ON "public"."product_variant" USING "btree" ("ean") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_id_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_id_product_id" ON "public"."product_variant" USING "btree" ("id", "product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_id" ON "public"."product_variant" USING "btree" ("product_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_product_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_deleted_at" ON "public"."product_variant_product_image" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_product_image_image_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_image_id" ON "public"."product_variant_product_image" USING "btree" ("image_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_product_image_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_variant_id" ON "public"."product_variant_product_image" USING "btree" ("variant_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_sku_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_sku_unique" ON "public"."product_variant" USING "btree" ("sku") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_product_variant_upc_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_upc_unique" ON "public"."product_variant" USING "btree" ("upc") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_application_method_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_application_method_currency_code" ON "public"."promotion_application_method" USING "btree" ("currency_code") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_promotion_application_method_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_application_method_deleted_at" ON "public"."promotion_application_method" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_application_method_promotion_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_application_method_promotion_id_unique" ON "public"."promotion_application_method" USING "btree" ("promotion_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_budget_campaign_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_budget_campaign_id_unique" ON "public"."promotion_campaign_budget" USING "btree" ("campaign_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_budget_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_deleted_at" ON "public"."promotion_campaign_budget" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_attribute_value_budget_id_u; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_budget_usage_attribute_value_budget_id_u" ON "public"."promotion_campaign_budget_usage" USING "btree" ("attribute_value", "budget_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_budget_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_usage_budget_id" ON "public"."promotion_campaign_budget_usage" USING "btree" ("budget_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_usage_deleted_at" ON "public"."promotion_campaign_budget_usage" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_campaign_identifier_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_campaign_identifier_unique" ON "public"."promotion_campaign" USING "btree" ("campaign_identifier") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_deleted_at" ON "public"."promotion_campaign" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_id" ON "public"."promotion" USING "btree" ("campaign_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_deleted_at" ON "public"."promotion" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_id_-71518339" ON "public"."order_promotion" USING "btree" ("promotion_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_id_-a9d4a70b" ON "public"."cart_promotion" USING "btree" ("promotion_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_is_automatic; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_is_automatic" ON "public"."promotion" USING "btree" ("is_automatic") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute" ON "public"."promotion_rule" USING "btree" ("attribute");


--
-- Name: IDX_promotion_rule_attribute_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute_operator" ON "public"."promotion_rule" USING "btree" ("attribute", "operator") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_attribute_operator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute_operator_id" ON "public"."promotion_rule" USING "btree" ("operator", "attribute", "id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_deleted_at" ON "public"."promotion_rule" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_operator" ON "public"."promotion_rule" USING "btree" ("operator");


--
-- Name: IDX_promotion_rule_value_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_deleted_at" ON "public"."promotion_rule_value" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_value_promotion_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_promotion_rule_id" ON "public"."promotion_rule_value" USING "btree" ("promotion_rule_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_value_rule_id_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_rule_id_value" ON "public"."promotion_rule_value" USING "btree" ("promotion_rule_id", "value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_rule_value_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_value" ON "public"."promotion_rule_value" USING "btree" ("value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_status" ON "public"."promotion" USING "btree" ("status") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_promotion_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_type" ON "public"."promotion" USING "btree" ("type");


--
-- Name: IDX_provider_identity_auth_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_provider_identity_auth_identity_id" ON "public"."provider_identity" USING "btree" ("auth_identity_id");


--
-- Name: IDX_provider_identity_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_provider_identity_deleted_at" ON "public"."provider_identity" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_provider_identity_provider_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_provider_identity_provider_entity_id" ON "public"."provider_identity" USING "btree" ("entity_id", "provider");


--
-- Name: IDX_publishable_key_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_publishable_key_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING "btree" ("publishable_key_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_rbac_role_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_rbac_role_id_-85069d44" ON "public"."invite_rbac_role" USING "btree" ("rbac_role_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_rbac_role_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_rbac_role_id_64ff0c4c" ON "public"."user_rbac_role" USING "btree" ("rbac_role_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_refund_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_deleted_at" ON "public"."refund" USING "btree" ("deleted_at");


--
-- Name: IDX_refund_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_payment_id" ON "public"."refund" USING "btree" ("payment_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_refund_reason_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_reason_deleted_at" ON "public"."refund_reason" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_refund_refund_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_refund_reason_id" ON "public"."refund" USING "btree" ("refund_reason_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_region_country_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_country_deleted_at" ON "public"."region_country" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_region_country_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_country_region_id" ON "public"."region_country" USING "btree" ("region_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_region_country_region_id_iso_2_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_region_country_region_id_iso_2_unique" ON "public"."region_country" USING "btree" ("region_id", "iso_2");


--
-- Name: IDX_region_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_deleted_at" ON "public"."region" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_region_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_id_1c934dab0" ON "public"."region_payment_provider" USING "btree" ("region_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_reservation_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_deleted_at" ON "public"."reservation_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_reservation_item_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_inventory_item_id" ON "public"."reservation_item" USING "btree" ("inventory_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_reservation_item_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_line_item_id" ON "public"."reservation_item" USING "btree" ("line_item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_reservation_item_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_location_id" ON "public"."reservation_item" USING "btree" ("location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_claim_id" ON "public"."return" USING "btree" ("claim_id") WHERE (("claim_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_return_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_display_id" ON "public"."return" USING "btree" ("display_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_exchange_id" ON "public"."return" USING "btree" ("exchange_id") WHERE (("exchange_id" IS NOT NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_return_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_id_-31ea43a" ON "public"."return_fulfillment" USING "btree" ("return_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_deleted_at" ON "public"."return_item" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_item_id" ON "public"."return_item" USING "btree" ("item_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_item_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_reason_id" ON "public"."return_item" USING "btree" ("reason_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_item_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_return_id" ON "public"."return_item" USING "btree" ("return_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_order_id" ON "public"."return" USING "btree" ("order_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_reason_parent_return_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_reason_parent_return_reason_id" ON "public"."return_reason" USING "btree" ("parent_return_reason_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_return_reason_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_reason_value" ON "public"."return_reason" USING "btree" ("value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_sales_channel_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_deleted_at" ON "public"."sales_channel" USING "btree" ("deleted_at");


--
-- Name: IDX_sales_channel_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_-1d67bae40" ON "public"."publishable_api_key_sales_channel" USING "btree" ("sales_channel_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_sales_channel_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_20b454295" ON "public"."product_sales_channel" USING "btree" ("sales_channel_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_sales_channel_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_26d06f470" ON "public"."sales_channel_stock_location" USING "btree" ("sales_channel_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_service_zone_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_service_zone_deleted_at" ON "public"."service_zone" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_service_zone_fulfillment_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_service_zone_fulfillment_set_id" ON "public"."service_zone" USING "btree" ("fulfillment_set_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_service_zone_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_service_zone_name_unique" ON "public"."service_zone" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_method_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_adjustment_promotion_id" ON "public"."cart_shipping_method_adjustment" USING "btree" ("promotion_id") WHERE (("deleted_at" IS NULL) AND ("promotion_id" IS NOT NULL));


--
-- Name: IDX_shipping_method_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_option_id" ON "public"."cart_shipping_method" USING "btree" ("shipping_option_id") WHERE (("deleted_at" IS NULL) AND ("shipping_option_id" IS NOT NULL));


--
-- Name: IDX_shipping_method_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_tax_line_tax_rate_id" ON "public"."cart_shipping_method_tax_line" USING "btree" ("tax_rate_id") WHERE (("deleted_at" IS NULL) AND ("tax_rate_id" IS NOT NULL));


--
-- Name: IDX_shipping_option_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_deleted_at" ON "public"."shipping_option" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_shipping_option_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_id_ba32fa9c" ON "public"."shipping_option_price_set" USING "btree" ("shipping_option_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_provider_id" ON "public"."shipping_option" USING "btree" ("provider_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_rule_deleted_at" ON "public"."shipping_option_rule" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_shipping_option_rule_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_rule_shipping_option_id" ON "public"."shipping_option_rule" USING "btree" ("shipping_option_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_service_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_service_zone_id" ON "public"."shipping_option" USING "btree" ("service_zone_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_shipping_option_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_shipping_option_type_id" ON "public"."shipping_option" USING "btree" ("shipping_option_type_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_shipping_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_shipping_profile_id" ON "public"."shipping_option" USING "btree" ("shipping_profile_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_option_type_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_type_deleted_at" ON "public"."shipping_option_type" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_shipping_profile_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_profile_deleted_at" ON "public"."shipping_profile" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_shipping_profile_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_profile_id_17a262437" ON "public"."product_shipping_profile" USING "btree" ("shipping_profile_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_shipping_profile_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_shipping_profile_name_unique" ON "public"."shipping_profile" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_single_default_region; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_single_default_region" ON "public"."tax_rate" USING "btree" ("tax_region_id") WHERE (("is_default" = true) AND ("deleted_at" IS NULL));


--
-- Name: IDX_site_config_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_site_config_deleted_at" ON "public"."site_config" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_site_config_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_site_config_key_unique" ON "public"."site_config" USING "btree" ("key") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_stock_location_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_address_deleted_at" ON "public"."stock_location_address" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_stock_location_address_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_stock_location_address_id_unique" ON "public"."stock_location" USING "btree" ("address_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_stock_location_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_deleted_at" ON "public"."stock_location" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_stock_location_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_-1e5992737" ON "public"."location_fulfillment_provider" USING "btree" ("stock_location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_stock_location_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_-e88adb96" ON "public"."location_fulfillment_set" USING "btree" ("stock_location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_stock_location_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_26d06f470" ON "public"."sales_channel_stock_location" USING "btree" ("stock_location_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_store_currency_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_currency_deleted_at" ON "public"."store_currency" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_store_currency_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_currency_store_id" ON "public"."store_currency" USING "btree" ("store_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_store_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_deleted_at" ON "public"."store" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_store_locale_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_locale_deleted_at" ON "public"."store_locale" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_store_locale_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_locale_store_id" ON "public"."store_locale" USING "btree" ("store_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tag_value_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tag_value_unique" ON "public"."product_tag" USING "btree" ("value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_provider_deleted_at" ON "public"."tax_provider" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_rate_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_deleted_at" ON "public"."tax_rate" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_deleted_at" ON "public"."tax_rate_rule" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_reference_id" ON "public"."tax_rate_rule" USING "btree" ("reference_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_rate_rule_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_tax_rate_id" ON "public"."tax_rate_rule" USING "btree" ("tax_rate_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_rate_rule_unique_rate_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_rate_rule_unique_rate_reference" ON "public"."tax_rate_rule" USING "btree" ("tax_rate_id", "reference_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_rate_tax_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_tax_region_id" ON "public"."tax_rate" USING "btree" ("tax_region_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_region_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_deleted_at" ON "public"."tax_region" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_tax_region_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_parent_id" ON "public"."tax_region" USING "btree" ("parent_id");


--
-- Name: IDX_tax_region_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_provider_id" ON "public"."tax_region" USING "btree" ("provider_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_tax_region_unique_country_nullable_province; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_nullable_province" ON "public"."tax_region" USING "btree" ("country_code") WHERE (("province_code" IS NULL) AND ("deleted_at" IS NULL));


--
-- Name: IDX_tax_region_unique_country_province; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_province" ON "public"."tax_region" USING "btree" ("country_code", "province_code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_type_value_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_type_value_unique" ON "public"."product_type" USING "btree" ("value") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_unique_promotion_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_unique_promotion_code" ON "public"."promotion" USING "btree" ("code") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_user_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_deleted_at" ON "public"."user" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NOT NULL);


--
-- Name: IDX_user_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_user_email_unique" ON "public"."user" USING "btree" ("email") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_user_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_id_64ff0c4c" ON "public"."user_rbac_role" USING "btree" ("user_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_user_preference_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_preference_deleted_at" ON "public"."user_preference" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_user_preference_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_preference_user_id" ON "public"."user_preference" USING "btree" ("user_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_user_preference_user_id_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_user_preference_user_id_key_unique" ON "public"."user_preference" USING "btree" ("user_id", "key") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_variant_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_variant_id_17b4c4e35" ON "public"."product_variant_inventory_item" USING "btree" ("variant_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_variant_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_variant_id_52b23597" ON "public"."product_variant_price_set" USING "btree" ("variant_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_view_configuration_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_deleted_at" ON "public"."view_configuration" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_view_configuration_entity_is_system_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_entity_is_system_default" ON "public"."view_configuration" USING "btree" ("entity", "is_system_default") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_view_configuration_entity_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_entity_user_id" ON "public"."view_configuration" USING "btree" ("entity", "user_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_view_configuration_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_user_id" ON "public"."view_configuration" USING "btree" ("user_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_deleted_at" ON "public"."workflow_execution" USING "btree" ("deleted_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_id" ON "public"."workflow_execution" USING "btree" ("id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_retention_time_updated_at_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_retention_time_updated_at_state" ON "public"."workflow_execution" USING "btree" ("retention_time", "updated_at", "state") WHERE (("deleted_at" IS NULL) AND ("retention_time" IS NOT NULL));


--
-- Name: IDX_workflow_execution_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_run_id" ON "public"."workflow_execution" USING "btree" ("run_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_state" ON "public"."workflow_execution" USING "btree" ("state") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_state_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_state_updated_at" ON "public"."workflow_execution" USING "btree" ("state", "updated_at") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_transaction_id" ON "public"."workflow_execution" USING "btree" ("transaction_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_updated_at_retention_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_updated_at_retention_time" ON "public"."workflow_execution" USING "btree" ("updated_at", "retention_time") WHERE (("deleted_at" IS NULL) AND ("retention_time" IS NOT NULL) AND (("state")::"text" = ANY ((ARRAY['done'::character varying, 'failed'::character varying, 'reverted'::character varying])::"text"[])));


--
-- Name: IDX_workflow_execution_workflow_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_workflow_id" ON "public"."workflow_execution" USING "btree" ("workflow_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_workflow_id_transaction_id" ON "public"."workflow_execution" USING "btree" ("workflow_id", "transaction_id") WHERE ("deleted_at" IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id_transaction_id_run_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_workflow_execution_workflow_id_transaction_id_run_id_unique" ON "public"."workflow_execution" USING "btree" ("workflow_id", "transaction_id", "run_id") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_script_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "idx_script_name_unique" ON "public"."script_migrations" USING "btree" ("script_name");


--
-- Name: tax_rate_rule FK_tax_rate_rule_tax_rate_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_rate_rule"
    ADD CONSTRAINT "FK_tax_rate_rule_tax_rate_id" FOREIGN KEY ("tax_rate_id") REFERENCES "public"."tax_rate"("id") ON DELETE CASCADE;


--
-- Name: tax_rate FK_tax_rate_tax_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_rate"
    ADD CONSTRAINT "FK_tax_rate_tax_region_id" FOREIGN KEY ("tax_region_id") REFERENCES "public"."tax_region"("id") ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_region"
    ADD CONSTRAINT "FK_tax_region_parent_id" FOREIGN KEY ("parent_id") REFERENCES "public"."tax_region"("id") ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_provider_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."tax_region"
    ADD CONSTRAINT "FK_tax_region_provider_id" FOREIGN KEY ("provider_id") REFERENCES "public"."tax_provider"("id") ON DELETE SET NULL;


--
-- Name: application_method_buy_rules application_method_buy_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_buy_rules"
    ADD CONSTRAINT "application_method_buy_rules_application_method_id_foreign" FOREIGN KEY ("application_method_id") REFERENCES "public"."promotion_application_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_buy_rules application_method_buy_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_buy_rules"
    ADD CONSTRAINT "application_method_buy_rules_promotion_rule_id_foreign" FOREIGN KEY ("promotion_rule_id") REFERENCES "public"."promotion_rule"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_target_rules"
    ADD CONSTRAINT "application_method_target_rules_application_method_id_foreign" FOREIGN KEY ("application_method_id") REFERENCES "public"."promotion_application_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."application_method_target_rules"
    ADD CONSTRAINT "application_method_target_rules_promotion_rule_id_foreign" FOREIGN KEY ("promotion_rule_id") REFERENCES "public"."promotion_rule"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: capture capture_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."capture"
    ADD CONSTRAINT "capture_payment_id_foreign" FOREIGN KEY ("payment_id") REFERENCES "public"."payment"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart"
    ADD CONSTRAINT "cart_billing_address_id_foreign" FOREIGN KEY ("billing_address_id") REFERENCES "public"."cart_address"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item_adjustment"
    ADD CONSTRAINT "cart_line_item_adjustment_item_id_foreign" FOREIGN KEY ("item_id") REFERENCES "public"."cart_line_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item cart_line_item_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item"
    ADD CONSTRAINT "cart_line_item_cart_id_foreign" FOREIGN KEY ("cart_id") REFERENCES "public"."cart"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_line_item_tax_line"
    ADD CONSTRAINT "cart_line_item_tax_line_item_id_foreign" FOREIGN KEY ("item_id") REFERENCES "public"."cart_line_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart"
    ADD CONSTRAINT "cart_shipping_address_id_foreign" FOREIGN KEY ("shipping_address_id") REFERENCES "public"."cart_address"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method_adjustment"
    ADD CONSTRAINT "cart_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY ("shipping_method_id") REFERENCES "public"."cart_shipping_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method cart_shipping_method_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method"
    ADD CONSTRAINT "cart_shipping_method_cart_id_foreign" FOREIGN KEY ("cart_id") REFERENCES "public"."cart"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cart_shipping_method_tax_line"
    ADD CONSTRAINT "cart_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY ("shipping_method_id") REFERENCES "public"."cart_shipping_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_line credit_line_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."credit_line"
    ADD CONSTRAINT "credit_line_cart_id_foreign" FOREIGN KEY ("cart_id") REFERENCES "public"."cart"("id") ON UPDATE CASCADE;


--
-- Name: customer_address customer_address_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_address"
    ADD CONSTRAINT "customer_address_customer_id_foreign" FOREIGN KEY ("customer_id") REFERENCES "public"."customer"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_group_customer"
    ADD CONSTRAINT "customer_group_customer_customer_group_id_foreign" FOREIGN KEY ("customer_group_id") REFERENCES "public"."customer_group"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."customer_group_customer"
    ADD CONSTRAINT "customer_group_customer_customer_id_foreign" FOREIGN KEY ("customer_id") REFERENCES "public"."customer"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_delivery_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment"
    ADD CONSTRAINT "fulfillment_delivery_address_id_foreign" FOREIGN KEY ("delivery_address_id") REFERENCES "public"."fulfillment_address"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment_item fulfillment_item_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_item"
    ADD CONSTRAINT "fulfillment_item_fulfillment_id_foreign" FOREIGN KEY ("fulfillment_id") REFERENCES "public"."fulfillment"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment_label fulfillment_label_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment_label"
    ADD CONSTRAINT "fulfillment_label_fulfillment_id_foreign" FOREIGN KEY ("fulfillment_id") REFERENCES "public"."fulfillment"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment"
    ADD CONSTRAINT "fulfillment_provider_id_foreign" FOREIGN KEY ("provider_id") REFERENCES "public"."fulfillment_provider"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment fulfillment_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."fulfillment"
    ADD CONSTRAINT "fulfillment_shipping_option_id_foreign" FOREIGN KEY ("shipping_option_id") REFERENCES "public"."shipping_option"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: geo_zone geo_zone_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."geo_zone"
    ADD CONSTRAINT "geo_zone_service_zone_id_foreign" FOREIGN KEY ("service_zone_id") REFERENCES "public"."service_zone"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: image image_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."image"
    ADD CONSTRAINT "image_product_id_foreign" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_level inventory_level_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."inventory_level"
    ADD CONSTRAINT "inventory_level_inventory_item_id_foreign" FOREIGN KEY ("inventory_item_id") REFERENCES "public"."inventory_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification notification_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notification"
    ADD CONSTRAINT "notification_provider_id_foreign" FOREIGN KEY ("provider_id") REFERENCES "public"."notification_provider"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order order_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order"
    ADD CONSTRAINT "order_billing_address_id_foreign" FOREIGN KEY ("billing_address_id") REFERENCES "public"."order_address"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order_change_action order_change_action_order_change_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_change_action"
    ADD CONSTRAINT "order_change_action_order_change_id_foreign" FOREIGN KEY ("order_change_id") REFERENCES "public"."order_change"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_change order_change_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_change"
    ADD CONSTRAINT "order_change_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_credit_line order_credit_line_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_credit_line"
    ADD CONSTRAINT "order_credit_line_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_item"
    ADD CONSTRAINT "order_item_item_id_foreign" FOREIGN KEY ("item_id") REFERENCES "public"."order_line_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_item"
    ADD CONSTRAINT "order_item_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_adjustment order_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item_adjustment"
    ADD CONSTRAINT "order_line_item_adjustment_item_id_foreign" FOREIGN KEY ("item_id") REFERENCES "public"."order_line_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_tax_line order_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item_tax_line"
    ADD CONSTRAINT "order_line_item_tax_line_item_id_foreign" FOREIGN KEY ("item_id") REFERENCES "public"."order_line_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item order_line_item_totals_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_line_item"
    ADD CONSTRAINT "order_line_item_totals_id_foreign" FOREIGN KEY ("totals_id") REFERENCES "public"."order_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order order_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order"
    ADD CONSTRAINT "order_shipping_address_id_foreign" FOREIGN KEY ("shipping_address_id") REFERENCES "public"."order_address"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping_method_adjustment"
    ADD CONSTRAINT "order_shipping_method_adjustment_shipping_method_id_foreign" FOREIGN KEY ("shipping_method_id") REFERENCES "public"."order_shipping_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping_method_tax_line"
    ADD CONSTRAINT "order_shipping_method_tax_line_shipping_method_id_foreign" FOREIGN KEY ("shipping_method_id") REFERENCES "public"."order_shipping_method"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping order_shipping_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_shipping"
    ADD CONSTRAINT "order_shipping_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_summary order_summary_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_summary"
    ADD CONSTRAINT "order_summary_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_transaction order_transaction_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."order_transaction"
    ADD CONSTRAINT "order_transaction_order_id_foreign" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_col_aa276_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_collection_payment_providers"
    ADD CONSTRAINT "payment_collection_payment_providers_payment_col_aa276_foreign" FOREIGN KEY ("payment_collection_id") REFERENCES "public"."payment_collection"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_pro_2d555_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_collection_payment_providers"
    ADD CONSTRAINT "payment_collection_payment_providers_payment_pro_2d555_foreign" FOREIGN KEY ("payment_provider_id") REFERENCES "public"."payment_provider"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment payment_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment"
    ADD CONSTRAINT "payment_payment_collection_id_foreign" FOREIGN KEY ("payment_collection_id") REFERENCES "public"."payment_collection"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_session payment_session_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."payment_session"
    ADD CONSTRAINT "payment_session_payment_collection_id_foreign" FOREIGN KEY ("payment_collection_id") REFERENCES "public"."payment_collection"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_list_rule price_list_rule_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_list_rule"
    ADD CONSTRAINT "price_list_rule_price_list_id_foreign" FOREIGN KEY ("price_list_id") REFERENCES "public"."price_list"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price"
    ADD CONSTRAINT "price_price_list_id_foreign" FOREIGN KEY ("price_list_id") REFERENCES "public"."price_list"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price"
    ADD CONSTRAINT "price_price_set_id_foreign" FOREIGN KEY ("price_set_id") REFERENCES "public"."price_set"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_rule price_rule_price_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_rule"
    ADD CONSTRAINT "price_rule_price_id_foreign" FOREIGN KEY ("price_id") REFERENCES "public"."price"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category product_category_parent_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_category"
    ADD CONSTRAINT "product_category_parent_category_id_foreign" FOREIGN KEY ("parent_category_id") REFERENCES "public"."product_category"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_category_product"
    ADD CONSTRAINT "product_category_product_product_category_id_foreign" FOREIGN KEY ("product_category_id") REFERENCES "public"."product_category"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_category_product"
    ADD CONSTRAINT "product_category_product_product_id_foreign" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product"
    ADD CONSTRAINT "product_collection_id_foreign" FOREIGN KEY ("collection_id") REFERENCES "public"."product_collection"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_option product_option_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_option"
    ADD CONSTRAINT "product_option_product_id_foreign" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_option_value product_option_value_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_option_value"
    ADD CONSTRAINT "product_option_value_option_id_foreign" FOREIGN KEY ("option_id") REFERENCES "public"."product_option"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_tags"
    ADD CONSTRAINT "product_tags_product_id_foreign" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_tags"
    ADD CONSTRAINT "product_tags_product_tag_id_foreign" FOREIGN KEY ("product_tag_id") REFERENCES "public"."product_tag"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product"
    ADD CONSTRAINT "product_type_id_foreign" FOREIGN KEY ("type_id") REFERENCES "public"."product_type"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_variant_option product_variant_option_option_value_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_option"
    ADD CONSTRAINT "product_variant_option_option_value_id_foreign" FOREIGN KEY ("option_value_id") REFERENCES "public"."product_option_value"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant_option product_variant_option_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_option"
    ADD CONSTRAINT "product_variant_option_variant_id_foreign" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variant"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant product_variant_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant"
    ADD CONSTRAINT "product_variant_product_id_foreign" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant_product_image product_variant_product_image_image_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."product_variant_product_image"
    ADD CONSTRAINT "product_variant_product_image_image_id_foreign" FOREIGN KEY ("image_id") REFERENCES "public"."image"("id") ON DELETE CASCADE;


--
-- Name: promotion_application_method promotion_application_method_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_application_method"
    ADD CONSTRAINT "promotion_application_method_promotion_id_foreign" FOREIGN KEY ("promotion_id") REFERENCES "public"."promotion"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_campaign_budget promotion_campaign_budget_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_campaign_budget"
    ADD CONSTRAINT "promotion_campaign_budget_campaign_id_foreign" FOREIGN KEY ("campaign_id") REFERENCES "public"."promotion_campaign"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_campaign_budget_usage promotion_campaign_budget_usage_budget_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_campaign_budget_usage"
    ADD CONSTRAINT "promotion_campaign_budget_usage_budget_id_foreign" FOREIGN KEY ("budget_id") REFERENCES "public"."promotion_campaign_budget"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion promotion_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion"
    ADD CONSTRAINT "promotion_campaign_id_foreign" FOREIGN KEY ("campaign_id") REFERENCES "public"."promotion_campaign"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_promotion_rule"
    ADD CONSTRAINT "promotion_promotion_rule_promotion_id_foreign" FOREIGN KEY ("promotion_id") REFERENCES "public"."promotion"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_promotion_rule"
    ADD CONSTRAINT "promotion_promotion_rule_promotion_rule_id_foreign" FOREIGN KEY ("promotion_rule_id") REFERENCES "public"."promotion_rule"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_rule_value promotion_rule_value_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."promotion_rule_value"
    ADD CONSTRAINT "promotion_rule_value_promotion_rule_id_foreign" FOREIGN KEY ("promotion_rule_id") REFERENCES "public"."promotion_rule"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: provider_identity provider_identity_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."provider_identity"
    ADD CONSTRAINT "provider_identity_auth_identity_id_foreign" FOREIGN KEY ("auth_identity_id") REFERENCES "public"."auth_identity"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refund refund_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."refund"
    ADD CONSTRAINT "refund_payment_id_foreign" FOREIGN KEY ("payment_id") REFERENCES "public"."payment"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: region_country region_country_region_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."region_country"
    ADD CONSTRAINT "region_country_region_id_foreign" FOREIGN KEY ("region_id") REFERENCES "public"."region"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reservation_item reservation_item_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservation_item"
    ADD CONSTRAINT "reservation_item_inventory_item_id_foreign" FOREIGN KEY ("inventory_item_id") REFERENCES "public"."inventory_item"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: return_reason return_reason_parent_return_reason_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."return_reason"
    ADD CONSTRAINT "return_reason_parent_return_reason_id_foreign" FOREIGN KEY ("parent_return_reason_id") REFERENCES "public"."return_reason"("id");


--
-- Name: service_zone service_zone_fulfillment_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."service_zone"
    ADD CONSTRAINT "service_zone_fulfillment_set_id_foreign" FOREIGN KEY ("fulfillment_set_id") REFERENCES "public"."fulfillment_set"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option"
    ADD CONSTRAINT "shipping_option_provider_id_foreign" FOREIGN KEY ("provider_id") REFERENCES "public"."fulfillment_provider"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipping_option_rule shipping_option_rule_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option_rule"
    ADD CONSTRAINT "shipping_option_rule_shipping_option_id_foreign" FOREIGN KEY ("shipping_option_id") REFERENCES "public"."shipping_option"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option"
    ADD CONSTRAINT "shipping_option_service_zone_id_foreign" FOREIGN KEY ("service_zone_id") REFERENCES "public"."service_zone"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_option_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option"
    ADD CONSTRAINT "shipping_option_shipping_option_type_id_foreign" FOREIGN KEY ("shipping_option_type_id") REFERENCES "public"."shipping_option_type"("id") ON UPDATE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_profile_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."shipping_option"
    ADD CONSTRAINT "shipping_option_shipping_profile_id_foreign" FOREIGN KEY ("shipping_profile_id") REFERENCES "public"."shipping_profile"("id") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_location stock_location_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stock_location"
    ADD CONSTRAINT "stock_location_address_id_foreign" FOREIGN KEY ("address_id") REFERENCES "public"."stock_location_address"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_currency store_currency_store_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."store_currency"
    ADD CONSTRAINT "store_currency_store_id_foreign" FOREIGN KEY ("store_id") REFERENCES "public"."store"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_locale store_locale_store_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."store_locale"
    ADD CONSTRAINT "store_locale_store_id_foreign" FOREIGN KEY ("store_id") REFERENCES "public"."store"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict eHKRKWtl9FaVB7wSkiMcAhNp6JIsWfboLN3bwGrEXOIxcf7ulVUX4aEVd3HLz9D

